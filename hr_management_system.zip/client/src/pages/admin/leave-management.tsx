import React, { useState } from 'react';
import { Header } from '@/components/layout/header';
import { Sidebar } from '@/components/layout/sidebar';
import { useAuth } from '@/hooks/use-auth';
import { useQuery, useMutation } from '@tanstack/react-query';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';
import { useToast } from '@/hooks/use-toast';
import {
  Calendar,
  CheckCircle2,
  XCircle,
  RefreshCw,
  Search,
  User,
  ThumbsUp,
  ThumbsDown,
  Loader2
} from 'lucide-react';
import { format } from 'date-fns';
import { Input } from '@/components/ui/input';

export default function AdminLeaveManagement() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [activeTab, setActiveTab] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  
  const toggleMobileMenu = () => setIsMobileMenuOpen(!isMobileMenuOpen);
  
  // Fetch all leave requests
  const { data: leaves = [], refetch: refetchLeaves } = useQuery({
    queryKey: ['/api/leave'],
    enabled: !!user && user.role === 'admin',
  });
  
  // Fetch users for names
  const { data: users = [] } = useQuery({
    queryKey: ['/api/users'],
    enabled: !!user && user.role === 'admin',
  });
  
  // Update leave status mutation
  const updateLeaveMutation = useMutation({
    mutationFn: async ({ leaveId, status }: { leaveId: number, status: string }) => {
      const res = await apiRequest("PATCH", `/api/leave/${leaveId}`, { status });
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/leave'] });
      toast({
        title: 'बिदा स्थिति अपडेट भयो',
        description: 'बिदा अनुरोधको स्थिति सफलतापूर्वक अपडेट गरियो।',
      });
    },
    onError: (error: Error) => {
      toast({
        title: 'बिदा स्थिति अपडेट असफल',
        description: error.message,
        variant: 'destructive',
      });
    },
  });
  
  const handleStatusChange = (leaveId: number, status: 'approved' | 'rejected') => {
    updateLeaveMutation.mutate({ leaveId, status });
  };
  
  // Filter leaves based on tab and search query
  const filteredLeaves = leaves.filter((leave: any) => {
    const employeeName = getUserName(leave.userId).toLowerCase();
    const matchesSearch = employeeName.includes(searchQuery.toLowerCase());
    
    if (activeTab === 'all') return matchesSearch;
    return leave.status === activeTab && matchesSearch;
  });
  
  // Get user name by ID
  const getUserName = (userId: number) => {
    const foundUser = users.find((u: any) => u.id === userId);
    return foundUser ? foundUser.name : `User #${userId}`;
  };
  
  // Count leaves by status
  const pendingLeavesCount = leaves.filter((leave: any) => leave.status === 'pending').length;
  const approvedLeavesCount = leaves.filter((leave: any) => leave.status === 'approved').length;
  const rejectedLeavesCount = leaves.filter((leave: any) => leave.status === 'rejected').length;
  
  if (!user || user.role !== 'admin') return null;
  
  return (
    <div className="min-h-screen flex flex-col">
      <Header onMenuToggle={toggleMobileMenu} />
      
      <div className="flex flex-1">
        <Sidebar isMobileOpen={isMobileMenuOpen} onClose={() => setIsMobileMenuOpen(false)} />
        
        <div className="flex-1 md:ml-64 p-4">
          <div className="mb-6">
            <h2 className="text-2xl font-medium text-neutral-500">बिदा व्यवस्थापन</h2>
            <p className="text-neutral-400">कर्मचारीहरूको बिदा अनुरोध व्यवस्थापन गर्नुहोस्</p>
          </div>
          
          {/* Leave Statistics */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            <Card>
              <CardContent className="p-4">
                <div className="flex justify-between items-center">
                  <div>
                    <p className="text-sm text-neutral-500">विचाराधीन</p>
                    <p className="text-2xl font-bold text-yellow-600">{pendingLeavesCount}</p>
                  </div>
                  <div className="h-12 w-12 rounded-full bg-yellow-100 flex items-center justify-center">
                    <Calendar className="h-6 w-6 text-yellow-600" />
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-4">
                <div className="flex justify-between items-center">
                  <div>
                    <p className="text-sm text-neutral-500">स्वीकृत</p>
                    <p className="text-2xl font-bold text-green-600">{approvedLeavesCount}</p>
                  </div>
                  <div className="h-12 w-12 rounded-full bg-green-100 flex items-center justify-center">
                    <CheckCircle2 className="h-6 w-6 text-green-600" />
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-4">
                <div className="flex justify-between items-center">
                  <div>
                    <p className="text-sm text-neutral-500">अस्वीकृत</p>
                    <p className="text-2xl font-bold text-red-600">{rejectedLeavesCount}</p>
                  </div>
                  <div className="h-12 w-12 rounded-full bg-red-100 flex items-center justify-center">
                    <XCircle className="h-6 w-6 text-red-600" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
          
          {/* Search and Filter */}
          <Card className="mb-6">
            <CardContent className="p-4 flex flex-col md:flex-row gap-4">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-neutral-400" />
                <Input
                  placeholder="कर्मचारी नाम खोज्नुहोस्..."
                  className="pl-10"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              <Button 
                variant="outline" 
                className="md:w-auto w-full"
                onClick={() => refetchLeaves()}
              >
                <RefreshCw className="h-4 w-4 mr-2" /> रिफ्रेस
              </Button>
            </CardContent>
          </Card>
          
          {/* Leave Requests Tab */}
          <Card>
            <Tabs value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="w-full grid grid-cols-4">
                <TabsTrigger value="all">सबै</TabsTrigger>
                <TabsTrigger value="pending">विचाराधीन</TabsTrigger>
                <TabsTrigger value="approved">स्वीकृत</TabsTrigger>
                <TabsTrigger value="rejected">अस्वीकृत</TabsTrigger>
              </TabsList>
              
              <CardContent className="p-4">
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>कर्मचारी</TableHead>
                        <TableHead>बिदा प्रकार</TableHead>
                        <TableHead>अवधि</TableHead>
                        <TableHead>कारण</TableHead>
                        <TableHead>स्थिति</TableHead>
                        <TableHead className="text-right">कार्य</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredLeaves.length === 0 ? (
                        <TableRow>
                          <TableCell colSpan={6} className="text-center py-8 text-neutral-400">
                            <Calendar className="h-12 w-12 mx-auto mb-2" />
                            <p>कुनै बिदा अनुरोध फेला परेन</p>
                          </TableCell>
                        </TableRow>
                      ) : (
                        filteredLeaves.map((leave: any) => (
                          <TableRow key={leave.id}>
                            <TableCell>
                              <div className="flex items-center">
                                <User className="h-4 w-4 mr-2 text-neutral-400" />
                                {getUserName(leave.userId)}
                              </div>
                            </TableCell>
                            <TableCell>
                              <Badge variant="outline" className={
                                leave.type === 'sick' ? 'bg-red-100 text-red-800' : 
                                leave.type === 'personal' ? 'bg-blue-100 text-blue-800' : 
                                'bg-purple-100 text-purple-800'
                              }>
                                {leave.type === 'sick' ? 'बिरामी बिदा' : 
                                 leave.type === 'personal' ? 'व्यक्तिगत बिदा' : 'वार्षिक बिदा'}
                              </Badge>
                            </TableCell>
                            <TableCell>
                              <div className="flex items-center">
                                <Calendar className="h-3 w-3 mr-1 text-neutral-400" />
                                <span className="text-sm">
                                  {format(new Date(leave.startDate), 'yyyy/MM/dd')} - {format(new Date(leave.endDate), 'yyyy/MM/dd')}
                                </span>
                              </div>
                            </TableCell>
                            <TableCell>
                              <p className="text-sm truncate max-w-[200px]">
                                {leave.reason}
                              </p>
                            </TableCell>
                            <TableCell>
                              <Badge variant={
                                leave.status === 'approved' ? 'default' : 
                                leave.status === 'rejected' ? 'destructive' : 'outline'
                              } className={
                                leave.status === 'approved' ? 'bg-green-100 text-green-800' : 
                                leave.status === 'rejected' ? 'bg-red-100 text-red-800' : 
                                'bg-yellow-100 text-yellow-800'
                              }>
                                {leave.status === 'approved' ? 'स्वीकृत' : 
                                 leave.status === 'rejected' ? 'अस्वीकृत' : 'विचाराधीन'}
                              </Badge>
                            </TableCell>
                            <TableCell className="text-right">
                              {leave.status === 'pending' ? (
                                <div className="flex justify-end gap-2">
                                  <Button 
                                    variant="outline" 
                                    size="sm"
                                    className="border-green-500 text-green-600 hover:bg-green-50"
                                    onClick={() => handleStatusChange(leave.id, 'approved')}
                                    disabled={updateLeaveMutation.isPending}
                                  >
                                    {updateLeaveMutation.isPending ? (
                                      <Loader2 className="h-4 w-4 animate-spin" />
                                    ) : (
                                      <ThumbsUp className="h-4 w-4" />
                                    )}
                                  </Button>
                                  <Button 
                                    variant="outline" 
                                    size="sm"
                                    className="border-red-500 text-red-600 hover:bg-red-50"
                                    onClick={() => handleStatusChange(leave.id, 'rejected')}
                                    disabled={updateLeaveMutation.isPending}
                                  >
                                    {updateLeaveMutation.isPending ? (
                                      <Loader2 className="h-4 w-4 animate-spin" />
                                    ) : (
                                      <ThumbsDown className="h-4 w-4" />
                                    )}
                                  </Button>
                                </div>
                              ) : (
                                <Badge variant="outline" className="bg-gray-100 text-gray-800">
                                  प्रक्रिया पूरा
                                </Badge>
                              )}
                            </TableCell>
                          </TableRow>
                        ))
                      )}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Tabs>
          </Card>
        </div>
      </div>
    </div>
  );
}
