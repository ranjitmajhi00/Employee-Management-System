import React, { useState, useEffect } from 'react';
import { Header } from '@/components/layout/header';
import { Sidebar } from '@/components/layout/sidebar';
import { useAuth } from '@/hooks/use-auth';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Calendar } from '@/components/ui/calendar';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';
import { useToast } from '@/hooks/use-toast';
import {
  Clock,
  Calendar as CalendarIcon,
  User,
  MapPin,
  ArrowDown,
  RefreshCw,
  QrCode,
  Search
} from 'lucide-react';
import { format } from 'date-fns';
import { Input } from '@/components/ui/input';
import { qrCodeGenerator } from "@/lib/qrCodeGenerator";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

export default function AttendanceManagement() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  const [qrCodeImage, setQrCodeImage] = useState<string | null>(null);
  const [qrType, setQrType] = useState<string>('check_in');
  const [searchQuery, setSearchQuery] = useState('');
  const [exportFormat, setExportFormat] = useState<string>('csv');
  
  const toggleMobileMenu = () => setIsMobileMenuOpen(!isMobileMenuOpen);
  
  // Fetch attendance records for today
  const { data: todayAttendance = [], refetch: refetchAttendance } = useQuery({
    queryKey: ['/api/attendance/all/today'],
    enabled: !!user && user.role === 'admin',
  });
  
  // Fetch users for names
  const { data: users = [] } = useQuery({
    queryKey: ['/api/users'],
    enabled: !!user && user.role === 'admin',
  });
  
  // Fetch QR code
  const { data: qrCodeData, refetch: refetchQrCode } = useQuery({
    queryKey: [`/api/qrcode/${qrType}`],
    enabled: !!user && user.role === 'admin',
  });
  
  // Generate QR code image when data changes
  useEffect(() => {
    if (qrCodeData?.qrCode) {
      qrCodeGenerator(qrCodeData.qrCode)
        .then(dataUrl => setQrCodeImage(dataUrl))
        .catch(err => {
          console.error('Error generating QR code:', err);
          toast({
            title: 'QR कोड जेनेरेट गर्न सकिएन',
            description: 'कृपया पुन: प्रयास गर्नुहोस्',
            variant: 'destructive',
          });
        });
    }
  }, [qrCodeData, toast]);
  
  // Get user name by ID
  const getUserName = (userId: number) => {
    const foundUser = users.find((u: any) => u.id === userId);
    return foundUser ? foundUser.name : `User #${userId}`;
  };
  
  // Filter attendance records by search query
  const filteredAttendance = todayAttendance.filter((record: any) => {
    const employeeName = getUserName(record.userId).toLowerCase();
    return employeeName.includes(searchQuery.toLowerCase());
  });
  
  // Group attendance records by user
  const groupedAttendance = filteredAttendance.reduce((acc: any, record: any) => {
    if (!acc[record.userId]) {
      acc[record.userId] = [];
    }
    acc[record.userId].push(record);
    return acc;
  }, {});
  
  // Determine late check-ins (after 9:00 AM)
  const isLateCheckIn = (timestamp: string) => {
    const checkInTime = new Date(timestamp);
    return checkInTime.getHours() >= 9 && checkInTime.getMinutes() > 0;
  };
  
  // Calculate work duration if both check-in and check-out exist
  const calculateWorkDuration = (records: any[]) => {
    const checkIn = records.find(r => r.type === 'check_in');
    const checkOut = records.find(r => r.type === 'check_out');
    
    if (checkIn && checkOut) {
      const checkInTime = new Date(checkIn.timestamp);
      const checkOutTime = new Date(checkOut.timestamp);
      const diffMs = checkOutTime.getTime() - checkInTime.getTime();
      const diffHrs = Math.floor(diffMs / (1000 * 60 * 60));
      const diffMins = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));
      return `${diffHrs} घ ${diffMins} मि`;
    }
    
    return '-';
  };
  
  // Handle QR code regeneration
  const regenerateQrCode = () => {
    refetchQrCode();
    toast({
      title: 'QR कोड रिफ्रेस भयो',
      description: `नयाँ ${qrType === 'check_in' ? 'चेक-इन' : 'चेक-आउट'} QR कोड जेनेरेट गरियो`,
    });
  };
  
  // Export attendance data
  const exportAttendanceData = () => {
    // Mock export function
    toast({
      title: 'हाजिरी डाटा एक्सपोर्ट गरियो',
      description: `डाटा ${exportFormat.toUpperCase()} फर्म्याटमा एक्सपोर्ट गरियो`,
    });
  };
  
  if (!user || user.role !== 'admin') return null;
  
  return (
    <div className="min-h-screen flex flex-col">
      <Header onMenuToggle={toggleMobileMenu} />
      
      <div className="flex flex-1">
        <Sidebar isMobileOpen={isMobileMenuOpen} onClose={() => setIsMobileMenuOpen(false)} />
        
        <div className="flex-1 md:ml-64 p-4">
          <div className="mb-6">
            <h2 className="text-2xl font-medium text-neutral-500">हाजिरी व्यवस्थापन</h2>
            <p className="text-neutral-400">कर्मचारीहरूको हाजिरी मनिटर गर्नुहोस्</p>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* QR Code Section */}
            <Card className="lg:col-span-1">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <QrCode className="mr-2 h-5 w-5" /> हाजिरी QR कोड
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-col items-center">
                  <div className="w-full mb-4">
                    <Select
                      value={qrType}
                      onValueChange={setQrType}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="QR कोड प्रकार" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="check_in">चेक-इन QR कोड</SelectItem>
                        <SelectItem value="check_out">चेक-आउट QR कोड</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="border p-4 rounded-lg bg-white flex items-center justify-center mb-4 w-full">
                    {qrCodeImage ? (
                      <img 
                        src={qrCodeImage} 
                        alt={`${qrType === 'check_in' ? 'चेक-इन' : 'चेक-आउट'} QR Code`}
                        className="h-48 w-48"
                      />
                    ) : (
                      <div className="h-48 w-48 flex items-center justify-center bg-gray-100 rounded">
                        <span className="text-gray-400">QR कोड लोड हुँदैछ...</span>
                      </div>
                    )}
                  </div>
                  
                  <div className="w-full space-y-2">
                    <Button 
                      className="w-full" 
                      onClick={regenerateQrCode}
                    >
                      <RefreshCw className="mr-2 h-4 w-4" /> QR कोड रिफ्रेस गर्नुहोस्
                    </Button>
                    
                    <p className="text-center text-sm text-neutral-500 mt-2">
                      यो QR कोड कर्मचारीहरूले हाजिरी गर्न स्क्यान गर्न सक्छन्।
                      <br />
                      यो दैनिक रूपमा परिवर्तन हुन्छ।
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            {/* Attendance Records */}
            <Card className="lg:col-span-2">
              <CardHeader>
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                  <CardTitle className="flex items-center">
                    <Clock className="mr-2 h-5 w-5" /> आजको हाजिरी रेकर्ड
                  </CardTitle>
                  
                  <div className="flex flex-col md:flex-row gap-2">
                    <div className="flex gap-2">
                      <Select
                        value={exportFormat}
                        onValueChange={setExportFormat}
                      >
                        <SelectTrigger className="w-[120px]">
                          <SelectValue placeholder="Format" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="csv">CSV</SelectItem>
                          <SelectItem value="excel">Excel</SelectItem>
                          <SelectItem value="pdf">PDF</SelectItem>
                        </SelectContent>
                      </Select>
                      
                      <Button 
                        variant="outline"
                        onClick={exportAttendanceData}
                      >
                        <ArrowDown className="mr-2 h-4 w-4" /> एक्सपोर्ट
                      </Button>
                    </div>
                    
                    <Button 
                      variant="outline"
                      onClick={() => refetchAttendance()}
                    >
                      <RefreshCw className="mr-2 h-4 w-4" /> रिफ्रेस
                    </Button>
                  </div>
                </div>
              </CardHeader>
              
              <CardContent>
                <div className="mb-4">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-neutral-400" />
                    <Input
                      placeholder="कर्मचारी खोज्नुहोस्..."
                      className="pl-10"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                    />
                  </div>
                </div>
                
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="whitespace-nowrap">कर्मचारी</TableHead>
                        <TableHead className="text-center whitespace-nowrap">चेक-इन</TableHead>
                        <TableHead className="text-center whitespace-nowrap">चेक-आउट</TableHead>
                        <TableHead className="text-right whitespace-nowrap">कार्य समय</TableHead>
                        <TableHead className="text-right whitespace-nowrap">स्थिति</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {Object.keys(groupedAttendance).length === 0 ? (
                        <TableRow>
                          <TableCell colSpan={5} className="text-center py-8 text-neutral-400">
                            <Clock className="h-12 w-12 mx-auto mb-2" />
                            <p>आज कुनै पनि हाजिरी रेकर्ड छैन</p>
                          </TableCell>
                        </TableRow>
                      ) : (
                        Object.entries(groupedAttendance).map(([userId, records]: [string, any[]]) => {
                          const userRecords = records as any[];
                          const checkIn = userRecords.find(r => r.type === 'check_in');
                          const checkOut = userRecords.find(r => r.type === 'check_out');
                          const workDuration = calculateWorkDuration(userRecords);
                          const isLate = checkIn && isLateCheckIn(checkIn.timestamp);
                          
                          return (
                            <TableRow key={userId}>
                              <TableCell className="font-medium">
                                <div className="flex items-center">
                                  <User className="h-4 w-4 mr-2 text-neutral-400" />
                                  {getUserName(parseInt(userId))}
                                </div>
                              </TableCell>
                              <TableCell className="text-center">
                                {checkIn ? (
                                  <div>
                                    <span className={isLate ? 'text-yellow-600' : 'text-green-600'}>
                                      {format(new Date(checkIn.timestamp), 'h:mm a')}
                                    </span>
                                    {checkIn.geoLocation && (
                                      <div className="text-xs text-neutral-400 flex items-center justify-center mt-1">
                                        <MapPin className="h-3 w-3 mr-1" />
                                        <span className="truncate max-w-[100px]" title={checkIn.geoLocation}>
                                          {checkIn.geoLocation}
                                        </span>
                                      </div>
                                    )}
                                  </div>
                                ) : '-'}
                              </TableCell>
                              <TableCell className="text-center">
                                {checkOut ? (
                                  <div>
                                    <span className="text-blue-600">
                                      {format(new Date(checkOut.timestamp), 'h:mm a')}
                                    </span>
                                    {checkOut.geoLocation && (
                                      <div className="text-xs text-neutral-400 flex items-center justify-center mt-1">
                                        <MapPin className="h-3 w-3 mr-1" />
                                        <span className="truncate max-w-[100px]" title={checkOut.geoLocation}>
                                          {checkOut.geoLocation}
                                        </span>
                                      </div>
                                    )}
                                  </div>
                                ) : '-'}
                              </TableCell>
                              <TableCell className="text-right">{workDuration}</TableCell>
                              <TableCell className="text-right">
                                {!checkIn ? (
                                  <Badge className="bg-red-100 text-red-800">
                                    अनुपस्थित
                                  </Badge>
                                ) : isLate ? (
                                  <Badge className="bg-yellow-100 text-yellow-800">
                                    ढिलो
                                  </Badge>
                                ) : (
                                  <Badge className="bg-green-100 text-green-800">
                                    समयमै
                                  </Badge>
                                )}
                              </TableCell>
                            </TableRow>
                          );
                        })
                      )}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
