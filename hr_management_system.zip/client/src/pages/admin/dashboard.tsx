import React, { useState } from 'react';
import { Header } from '@/components/layout/header';
import { Sidebar } from '@/components/layout/sidebar';
import { useAuth } from '@/hooks/use-auth';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';
import { format } from 'date-fns';
import {
  User,
  CheckCircle2,
  AlertCircle,
  Calendar,
  Clock,
  RefreshCw,
  MessageSquare,
  CheckCheck,
  XCircle
} from 'lucide-react';

export default function AdminDashboard() {
  const { user } = useAuth();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  
  const toggleMobileMenu = () => setIsMobileMenuOpen(!isMobileMenuOpen);
  
  // Fetch users
  const { data: users = [] } = useQuery({
    queryKey: ['/api/users'],
    enabled: !!user && user.role === 'admin',
  });
  
  // Fetch today's attendance
  const { data: todayAttendance = [], refetch: refetchAttendance } = useQuery({
    queryKey: ['/api/attendance/all/today'],
    enabled: !!user && user.role === 'admin',
  });
  
  // Fetch all tasks
  const { data: tasks = [], refetch: refetchTasks } = useQuery({
    queryKey: ['/api/tasks'],
    enabled: !!user && user.role === 'admin',
  });
  
  // Fetch leave requests
  const { data: leaves = [], refetch: refetchLeaves } = useQuery({
    queryKey: ['/api/leave'],
    enabled: !!user && user.role === 'admin',
  });
  
  // Calculate statistics
  const totalEmployees = users.filter((u: any) => u.role !== 'admin').length;
  const presentToday = new Set(todayAttendance.map((a: any) => a.userId)).size;
  const attendancePercentage = totalEmployees > 0 ? (presentToday / totalEmployees) * 100 : 0;
  
  const completedTasks = tasks.filter((task: any) => task.status === 'completed').length;
  const pendingTasks = tasks.filter((task: any) => task.status !== 'completed').length;
  const taskCompletionRate = tasks.length > 0 ? (completedTasks / tasks.length) * 100 : 0;
  
  const pendingLeaves = leaves.filter((leave: any) => leave.status === 'pending').length;
  
  // Get employees who checked in late (after 9:00 AM)
  const lateEmployees = todayAttendance
    .filter((a: any) => {
      const checkInTime = new Date(a.timestamp);
      return a.type === 'check_in' && checkInTime.getHours() >= 9 && checkInTime.getMinutes() > 0;
    })
    .map((a: any) => a.userId);
  
  const lateEmployeeCount = new Set(lateEmployees).size;
  const latePercentage = totalEmployees > 0 ? (lateEmployeeCount / totalEmployees) * 100 : 0;
  
  // Group daily reports (tasks submitted today)
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  
  const dailyReports = tasks
    .filter((task: any) => {
      if (!task.completedAt) return false;
      const completedDate = new Date(task.completedAt);
      completedDate.setHours(0, 0, 0, 0);
      return completedDate.getTime() === today.getTime();
    })
    .sort((a: any, b: any) => new Date(b.completedAt).getTime() - new Date(a.completedAt).getTime());
  
  // Get user names for display
  const getUserName = (userId: number) => {
    const foundUser = users.find((u: any) => u.id === userId);
    return foundUser ? foundUser.name : `User #${userId}`;
  };
  
  if (!user || user.role !== 'admin') return null;
  
  return (
    <div className="min-h-screen flex flex-col">
      <Header onMenuToggle={toggleMobileMenu} />
      
      <div className="flex flex-1">
        <Sidebar isMobileOpen={isMobileMenuOpen} onClose={() => setIsMobileMenuOpen(false)} />
        
        <div className="flex-1 md:ml-64 p-4">
          <div className="mb-6">
            <h2 className="text-2xl font-medium text-neutral-500">प्रशासक ड्यासबोर्ड</h2>
            <p className="text-neutral-400">आज: {format(new Date(), 'yyyy/MM/dd')}</p>
          </div>
          
          {/* Summary Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 mb-6">
            <Card>
              <CardContent className="p-4">
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <p className="text-neutral-400 text-sm">उपस्थित कर्मचारी</p>
                    <p className="text-2xl font-medium">{presentToday}/{totalEmployees}</p>
                  </div>
                  <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center">
                    <User className="h-6 w-6 text-primary" />
                  </div>
                </div>
                <div className="flex items-center text-xs">
                  <span className={attendancePercentage >= 70 ? "text-success" : "text-warning"}>
                    {attendancePercentage.toFixed(0)}%
                  </span>
                  <span className="ml-1">उपस्थिति दर</span>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-4">
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <p className="text-neutral-400 text-sm">पूरा भएका कार्य</p>
                    <p className="text-2xl font-medium">{completedTasks}/{tasks.length}</p>
                  </div>
                  <div className="h-12 w-12 rounded-full bg-success/10 flex items-center justify-center">
                    <CheckCircle2 className="h-6 w-6 text-success" />
                  </div>
                </div>
                <div className="flex items-center text-xs">
                  <span className="text-success mr-1">{taskCompletionRate.toFixed(0)}%</span>
                  <span>कार्य पूरा दर</span>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-4">
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <p className="text-neutral-400 text-sm">बिदा अनुरोध</p>
                    <p className="text-2xl font-medium">{pendingLeaves}</p>
                  </div>
                  <div className="h-12 w-12 rounded-full bg-warning/10 flex items-center justify-center">
                    <Calendar className="h-6 w-6 text-warning" />
                  </div>
                </div>
                <div className="flex items-center text-xs">
                  <span className="text-warning mr-1">
                    {pendingLeaves > 0 ? `${pendingLeaves} नयाँ` : 'कुनै छैन'}
                  </span>
                  <span>आजको अनुरोध</span>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-4">
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <p className="text-neutral-400 text-sm">ढिलो आएका</p>
                    <p className="text-2xl font-medium">{lateEmployeeCount}</p>
                  </div>
                  <div className="h-12 w-12 rounded-full bg-destructive/10 flex items-center justify-center">
                    <Clock className="h-6 w-6 text-destructive" />
                  </div>
                </div>
                <div className="flex items-center text-xs">
                  <span className="text-destructive mr-1">{latePercentage.toFixed(0)}%</span>
                  <span>ढिलाइ दर</span>
                </div>
              </CardContent>
            </Card>
          </div>
          
          {/* Tasks and Reports Section */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
            {/* Daily Task Reports */}
            <Card className="overflow-hidden">
              <div className="bg-neutral-100 p-4 border-b flex justify-between items-center">
                <h3 className="text-lg font-medium">दैनिक कार्य रिपोर्ट</h3>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  className="text-primary" 
                  onClick={() => refetchTasks()}
                >
                  <RefreshCw className="h-4 w-4 mr-1" /> रिफ्रेस
                </Button>
              </div>
              
              <div className="p-4">
                {dailyReports.length === 0 ? (
                  <div className="text-center py-8 text-neutral-400">
                    <AlertCircle className="h-12 w-12 mx-auto mb-2" />
                    <p>आज कुनै पनि कार्य रिपोर्ट पेश गरिएको छैन</p>
                  </div>
                ) : (
                  dailyReports.slice(0, 5).map((task: any) => (
                    <div key={task.id} className="border-b pb-4 mb-4 last:border-0 last:pb-0 last:mb-0">
                      <div className="flex justify-between items-start mb-2">
                        <div className="flex items-start gap-2">
                          <div className="h-10 w-10 rounded-full bg-neutral-100 flex items-center justify-center mt-1">
                            <User className="h-6 w-6 text-neutral-400" />
                          </div>
                          <div>
                            <p className="font-medium">{getUserName(task.assignedTo)}</p>
                            <p className="text-sm text-neutral-400">{task.title}</p>
                            <p className="text-xs text-neutral-300">
                              पेश गरिएको: {format(new Date(task.completedAt), 'h:mm a')}
                            </p>
                          </div>
                        </div>
                        <span className="bg-success/20 text-success text-xs px-2 py-1 rounded-full">
                          पूरा
                        </span>
                      </div>
                      
                      <div className="flex gap-2 mt-3">
                        <Button size="sm" className="flex-1">
                          <CheckCheck className="h-4 w-4 mr-1" /> स्वीकृत
                        </Button>
                        <Button size="sm" variant="outline" className="flex-1">
                          <XCircle className="h-4 w-4 mr-1" /> सुधार
                        </Button>
                        <Button size="sm" variant="outline" className="flex-1">
                          <MessageSquare className="h-4 w-4 mr-1" /> टिप्पणी
                        </Button>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </Card>
            
            {/* Attendance Summary */}
            <Card className="overflow-hidden">
              <div className="bg-neutral-100 p-4 border-b flex justify-between items-center">
                <h3 className="text-lg font-medium">हाजिरी सारांश</h3>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  className="text-primary"
                  onClick={() => refetchAttendance()}
                >
                  <RefreshCw className="h-4 w-4 mr-1" /> रिफ्रेस
                </Button>
              </div>
              
              <div className="p-4 overflow-x-auto">
                {todayAttendance.length === 0 ? (
                  <div className="text-center py-8 text-neutral-400">
                    <AlertCircle className="h-12 w-12 mx-auto mb-2" />
                    <p>आज कुनै पनि हाजिरी रेकर्ड छैन</p>
                  </div>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="whitespace-nowrap">कर्मचारी</TableHead>
                        <TableHead className="text-center whitespace-nowrap">चेक-इन</TableHead>
                        <TableHead className="text-center whitespace-nowrap">चेक-आउट</TableHead>
                        <TableHead className="text-right whitespace-nowrap">कार्य समय</TableHead>
                        <TableHead className="text-right whitespace-nowrap">स्थिति</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {Array.from(new Set(todayAttendance.map((a: any) => a.userId))).map((userId: any) => {
                        const employeeRecords = todayAttendance.filter((a: any) => a.userId === userId);
                        const checkIn = employeeRecords.find((a: any) => a.type === 'check_in');
                        const checkOut = employeeRecords.find((a: any) => a.type === 'check_out');
                        
                        let workHours = '-';
                        if (checkIn && checkOut) {
                          const checkInTime = new Date(checkIn.timestamp);
                          const checkOutTime = new Date(checkOut.timestamp);
                          const diffMs = checkOutTime.getTime() - checkInTime.getTime();
                          const diffHrs = Math.floor(diffMs / (1000 * 60 * 60));
                          const diffMins = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));
                          workHours = `${diffHrs} घ ${diffMins} मि`;
                        }
                        
                        const isLate = checkIn && new Date(checkIn.timestamp).getHours() >= 9 && 
                                      new Date(checkIn.timestamp).getMinutes() > 0;
                        
                        return (
                          <TableRow key={userId}>
                            <TableCell className="font-medium">
                              {getUserName(userId)}
                            </TableCell>
                            <TableCell className="text-center">
                              {checkIn ? format(new Date(checkIn.timestamp), 'h:mm a') : '-'}
                            </TableCell>
                            <TableCell className="text-center">
                              {checkOut ? format(new Date(checkOut.timestamp), 'h:mm a') : '-'}
                            </TableCell>
                            <TableCell className="text-right">{workHours}</TableCell>
                            <TableCell className="text-right">
                              {!checkIn ? (
                                <span className="bg-destructive/20 text-destructive text-xs px-2 py-1 rounded-full">
                                  अनुपस्थित
                                </span>
                              ) : isLate ? (
                                <span className="bg-warning/20 text-warning text-xs px-2 py-1 rounded-full">
                                  ढिलो
                                </span>
                              ) : (
                                <span className="bg-success/20 text-success text-xs px-2 py-1 rounded-full">
                                  समयमै
                                </span>
                              )}
                            </TableCell>
                          </TableRow>
                        );
                      })}
                    </TableBody>
                  </Table>
                )}
              </div>
            </Card>
          </div>
          
          {/* Employee Performance and Leave Requests */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Employee Performance */}
            <Card className="overflow-hidden">
              <div className="bg-neutral-100 p-4 border-b">
                <h3 className="text-lg font-medium">कर्मचारी प्रदर्शन</h3>
              </div>
              <div className="p-4">
                {users.filter((u: any) => u.role !== 'admin').length === 0 ? (
                  <div className="text-center py-8 text-neutral-400">
                    <AlertCircle className="h-12 w-12 mx-auto mb-2" />
                    <p>कुनै कर्मचारी डाटा उपलब्ध छैन</p>
                  </div>
                ) : (
                  users.filter((u: any) => u.role !== 'admin').slice(0, 5).map((employee: any) => {
                    // Calculate mock performance metrics for demo
                    const employeeTasks = tasks.filter((t: any) => t.assignedTo === employee.id);
                    const completed = employeeTasks.filter((t: any) => t.status === 'completed').length;
                    const total = employeeTasks.length || 1; // Avoid division by zero
                    
                    const taskCompletionScore = Math.round((completed / total) * 100);
                    const timelinessScore = Math.round(Math.random() * 30 + 70); // Mock score for demo
                    const qualityScore = Math.round(Math.random() * 20 + 80); // Mock score for demo
                    const overallScore = Math.round((taskCompletionScore + timelinessScore + qualityScore) / 3);
                    
                    return (
                      <div key={employee.id} className="mb-4 last:mb-0">
                        <div className="flex justify-between items-center mb-1">
                          <p className="text-sm font-medium">{employee.name}</p>
                          <p className="text-sm text-primary font-medium">{overallScore}%</p>
                        </div>
                        <div className="w-full bg-neutral-200 rounded-full h-2 mb-3">
                          <div 
                            className="bg-primary rounded-full h-2" 
                            style={{ width: `${overallScore}%` }}
                          ></div>
                        </div>
                        
                        <div className="grid grid-cols-3 gap-2 text-xs text-center">
                          <div>
                            <p className="text-neutral-400">कार्य पूरा</p>
                            <p className="font-medium">{taskCompletionScore}%</p>
                          </div>
                          <div>
                            <p className="text-neutral-400">समय पालना</p>
                            <p className="font-medium">{timelinessScore}%</p>
                          </div>
                          <div>
                            <p className="text-neutral-400">गुणस्तर</p>
                            <p className="font-medium">{qualityScore}%</p>
                          </div>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>
            </Card>
            
            {/* Leave Requests */}
            <Card className="overflow-hidden">
              <div className="bg-neutral-100 p-4 border-b flex justify-between items-center">
                <h3 className="text-lg font-medium">बिदा अनुरोधहरू</h3>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  className="text-primary"
                  onClick={() => refetchLeaves()}
                >
                  <RefreshCw className="h-4 w-4 mr-1" /> रिफ्रेस
                </Button>
              </div>
              <div className="p-4">
                {pendingLeaves === 0 ? (
                  <div className="text-center py-8 text-neutral-400">
                    <AlertCircle className="h-12 w-12 mx-auto mb-2" />
                    <p>कुनै विचाराधीन बिदा अनुरोध छैन</p>
                  </div>
                ) : (
                  leaves
                    .filter((leave: any) => leave.status === 'pending')
                    .slice(0, 5)
                    .map((leave: any) => (
                      <div key={leave.id} className="border-b pb-4 mb-4 last:border-0 last:pb-0 last:mb-0">
                        <div className="flex justify-between items-start mb-2">
                          <div>
                            <div className="flex items-center">
                              <p className="font-medium">{getUserName(leave.userId)}</p>
                              <span className="ml-2 bg-primary/20 text-primary text-xs px-2 py-0.5 rounded-full">
                                {leave.type === 'sick' ? 'बिरामी बिदा' : 
                                 leave.type === 'personal' ? 'व्यक्तिगत बिदा' : 'वार्षिक बिदा'}
                              </span>
                            </div>
                            <p className="text-sm text-neutral-400 mt-1">
                              मिति: {format(new Date(leave.startDate), 'yyyy/MM/dd')} - {format(new Date(leave.endDate), 'yyyy/MM/dd')}
                            </p>
                            <p className="text-xs text-neutral-300 mt-1">
                              कारण: {leave.reason}
                            </p>
                          </div>
                          <span className="bg-warning/20 text-warning text-xs px-2 py-1 rounded-full">
                            विचाराधीन
                          </span>
                        </div>
                        
                        <div className="flex gap-2 mt-3">
                          <Button size="sm" className="flex-1 bg-success">
                            <CheckCheck className="h-4 w-4 mr-1" /> स्वीकृत
                          </Button>
                          <Button size="sm" className="flex-1 bg-destructive">
                            <XCircle className="h-4 w-4 mr-1" /> अस्वीकृत
                          </Button>
                        </div>
                      </div>
                    ))
                )}
              </div>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
