import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Header } from '@/components/layout/header';
import { Sidebar } from '@/components/layout/sidebar';
import { useAuth } from '@/hooks/use-auth';
import { useQuery, useMutation } from '@tanstack/react-query';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle,
  CardDescription,
  CardFooter
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogFooter 
} from '@/components/ui/dialog';
import { useToast } from '@/hooks/use-toast';
import { 
  User,
  UserPlus,
  Mail,
  Phone,
  MapPin,
  Edit,
  Trash2,
  Search,
  Shield,
  UserCog,
  XCircle,
  Clock,
  FileText
} from 'lucide-react';
import { format } from 'date-fns';

const newEmployeeSchema = z.object({
  username: z.string().min(3, 'Username must be at least 3 characters'),
  password: z.string().min(6, 'Password must be at least 6 characters'),
  name: z.string().min(1, 'Name is required'),
  email: z.string().email('Valid email is required'),
  phone: z.string().optional(),
  address: z.string().optional(),
  role: z.enum(['admin', 'employee']),
});

type NewEmployeeValues = z.infer<typeof newEmployeeSchema>;

export default function EmployeeManagement() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isAddEmployeeOpen, setIsAddEmployeeOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedEmployee, setSelectedEmployee] = useState<any>(null);
  const [selectedTab, setSelectedTab] = useState<string>('basic');
  
  const toggleMobileMenu = () => setIsMobileMenuOpen(!isMobileMenuOpen);
  
  // Fetch users
  const { data: users = [], refetch: refetchUsers } = useQuery({
    queryKey: ['/api/users'],
    enabled: !!user && user.role === 'admin',
  });
  
  // Fetch all tasks for employee report
  const { data: allTasks = [] } = useQuery({
    queryKey: ['/api/tasks'],
    enabled: !!user && user.role === 'admin',
  });
  
  // Fetch all attendance records
  const { data: allAttendance = [] } = useQuery({
    queryKey: ['/api/attendance/all/today'],
    enabled: !!user && user.role === 'admin',
  });
  
  // New employee form
  const form = useForm<NewEmployeeValues>({
    resolver: zodResolver(newEmployeeSchema),
    defaultValues: {
      username: '',
      password: '',
      name: '',
      email: '',
      phone: '',
      address: '',
      role: 'employee',
    },
  });
  
  // Register new employee mutation
  const registerMutation = useMutation({
    mutationFn: async (data: NewEmployeeValues) => {
      const res = await apiRequest("POST", "/api/register", data);
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: 'कर्मचारी थपियो',
        description: 'नयाँ कर्मचारी सफलतापूर्वक थपियो।',
      });
      refetchUsers();
      setIsAddEmployeeOpen(false);
      form.reset();
    },
    onError: (error: Error) => {
      toast({
        title: 'कर्मचारी थप्न असफल',
        description: error.message,
        variant: 'destructive',
      });
    },
  });

  const onSubmit = (data: NewEmployeeValues) => {
    registerMutation.mutate(data);
  };
  
  // Filter employees based on search query
  const filteredEmployees = users.filter((employee: any) => {
    const searchString = searchQuery.toLowerCase();
    return (
      employee.name.toLowerCase().includes(searchString) ||
      employee.username.toLowerCase().includes(searchString) ||
      employee.email.toLowerCase().includes(searchString)
    );
  });
  
  // Get employee tasks
  const getEmployeeTasks = (employeeId: number) => {
    return allTasks.filter((task: any) => task.assignedTo === employeeId);
  };
  
  // Show employee details
  const viewEmployeeDetails = (employee: any) => {
    setSelectedEmployee(employee);
  };
  
  if (!user || user.role !== 'admin') return null;
  
  return (
    <div className="min-h-screen flex flex-col">
      <Header onMenuToggle={toggleMobileMenu} />
      
      <div className="flex flex-1">
        <Sidebar isMobileOpen={isMobileMenuOpen} onClose={() => setIsMobileMenuOpen(false)} />
        
        <div className="flex-1 md:ml-64 p-4">
          <div className="flex justify-between items-center mb-6">
            <div>
              <h2 className="text-2xl font-medium text-neutral-500">कर्मचारी व्यवस्थापन</h2>
              <p className="text-neutral-400">कर्मचारीहरू थप्नुहोस्, हेर्नुहोस् र व्यवस्थापन गर्नुहोस्</p>
            </div>
            <Button onClick={() => setIsAddEmployeeOpen(true)}>
              <UserPlus className="h-4 w-4 mr-2" /> नयाँ कर्मचारी
            </Button>
          </div>
          
          {/* Search and Filter */}
          <Card className="mb-6">
            <CardContent className="p-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-neutral-400" />
                <Input
                  placeholder="कर्मचारी खोज्नुहोस्..."
                  className="pl-10"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
            </CardContent>
          </Card>
          
          {/* Employees Table */}
          <Card>
            <CardHeader>
              <CardTitle>कर्मचारीहरू ({filteredEmployees.length})</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-[50px]">#</TableHead>
                      <TableHead>नाम</TableHead>
                      <TableHead>युजरनेम</TableHead>
                      <TableHead>इमेल</TableHead>
                      <TableHead>भूमिका</TableHead>
                      <TableHead className="text-right">कार्य</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredEmployees.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={6} className="text-center py-8 text-neutral-400">
                          कुनै कर्मचारी फेला परेन
                        </TableCell>
                      </TableRow>
                    ) : (
                      filteredEmployees.map((employee: any, index: number) => (
                        <TableRow key={employee.id}>
                          <TableCell>{index + 1}</TableCell>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <Avatar className="h-8 w-8">
                                <AvatarImage src={employee.profilePhoto} />
                                <AvatarFallback className="bg-primary text-white">
                                  {employee.name.charAt(0).toUpperCase()}
                                </AvatarFallback>
                              </Avatar>
                              <span className="font-medium">{employee.name}</span>
                            </div>
                          </TableCell>
                          <TableCell>{employee.username}</TableCell>
                          <TableCell>{employee.email}</TableCell>
                          <TableCell>
                            <Badge variant="outline" className={
                              employee.role === 'admin' 
                                ? 'bg-purple-100 text-purple-800' 
                                : 'bg-blue-100 text-blue-800'
                            }>
                              {employee.role === 'admin' ? 'प्रशासक' : 'कर्मचारी'}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-right">
                            <Button 
                              variant="ghost" 
                              size="sm" 
                              onClick={() => viewEmployeeDetails(employee)}
                            >
                              <UserCog className="h-4 w-4 mr-1" /> विवरण
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
          
          {/* Add Employee Dialog */}
          <Dialog open={isAddEmployeeOpen} onOpenChange={setIsAddEmployeeOpen}>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>नयाँ कर्मचारी थप्नुहोस्</DialogTitle>
              </DialogHeader>
              
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                  <FormField
                    control={form.control}
                    name="username"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>युजरनेम</FormLabel>
                        <FormControl>
                          <Input placeholder="युजरनेम" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="password"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>पासवर्ड</FormLabel>
                        <FormControl>
                          <Input type="password" placeholder="पासवर्ड" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>पूरा नाम</FormLabel>
                        <FormControl>
                          <Input placeholder="पूरा नाम" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>इमेल</FormLabel>
                        <FormControl>
                          <Input type="email" placeholder="इमेल" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="phone"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>फोन</FormLabel>
                          <FormControl>
                            <Input placeholder="फोन (Optional)" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="address"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>ठेगाना</FormLabel>
                          <FormControl>
                            <Input placeholder="ठेगाना (Optional)" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <FormField
                    control={form.control}
                    name="role"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>भूमिका</FormLabel>
                        <Select 
                          onValueChange={field.onChange} 
                          defaultValue={field.value}
                        >
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="भूमिका छान्नुहोस्" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="admin">प्रशासक</SelectItem>
                            <SelectItem value="employee">कर्मचारी</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <DialogFooter>
                    <Button 
                      type="button" 
                      variant="outline" 
                      onClick={() => setIsAddEmployeeOpen(false)}
                    >
                      रद्द गर्नुहोस्
                    </Button>
                    <Button 
                      type="submit" 
                      disabled={registerMutation.isPending}
                    >
                      {registerMutation.isPending ? 'प्रगतिमा...' : 'कर्मचारी थप्नुहोस्'}
                    </Button>
                  </DialogFooter>
                </form>
              </Form>
            </DialogContent>
          </Dialog>
          
          {/* Employee Details Dialog */}
          {selectedEmployee && (
            <Dialog open={!!selectedEmployee} onOpenChange={() => setSelectedEmployee(null)}>
              <DialogContent className="max-w-3xl">
                <DialogHeader>
                  <DialogTitle>कर्मचारी विवरण</DialogTitle>
                </DialogHeader>
                
                <div className="flex flex-col md:flex-row gap-4">
                  {/* Employee basic info */}
                  <Card className="md:w-1/3">
                    <CardContent className="p-4">
                      <div className="flex flex-col items-center justify-center">
                        <Avatar className="h-24 w-24 my-4">
                          <AvatarImage src={selectedEmployee.profilePhoto} />
                          <AvatarFallback className="bg-primary text-white text-xl">
                            {selectedEmployee.name.charAt(0).toUpperCase()}
                          </AvatarFallback>
                        </Avatar>
                        <h3 className="text-xl font-bold">{selectedEmployee.name}</h3>
                        <Badge variant="outline" className={
                          selectedEmployee.role === 'admin' 
                            ? 'bg-purple-100 text-purple-800 mt-2' 
                            : 'bg-blue-100 text-blue-800 mt-2'
                        }>
                          {selectedEmployee.role === 'admin' ? 'प्रशासक' : 'कर्मचारी'}
                        </Badge>
                      </div>
                      
                      <div className="mt-6 space-y-3">
                        <div className="flex items-center">
                          <User className="h-4 w-4 mr-2 text-neutral-500" />
                          <span className="text-sm">{selectedEmployee.username}</span>
                        </div>
                        <div className="flex items-center">
                          <Mail className="h-4 w-4 mr-2 text-neutral-500" />
                          <span className="text-sm">{selectedEmployee.email}</span>
                        </div>
                        {selectedEmployee.phone && (
                          <div className="flex items-center">
                            <Phone className="h-4 w-4 mr-2 text-neutral-500" />
                            <span className="text-sm">{selectedEmployee.phone}</span>
                          </div>
                        )}
                        {selectedEmployee.address && (
                          <div className="flex items-center">
                            <MapPin className="h-4 w-4 mr-2 text-neutral-500" />
                            <span className="text-sm">{selectedEmployee.address}</span>
                          </div>
                        )}
                        <div className="flex items-center">
                          <Clock className="h-4 w-4 mr-2 text-neutral-500" />
                          <span className="text-sm">
                            जोइन भएको: {format(new Date(selectedEmployee.createdAt), 'yyyy/MM/dd')}
                          </span>
                        </div>
                      </div>
                      
                      <div className="mt-6 flex gap-2">
                        <Button variant="outline" className="flex-1">
                          <Edit className="h-4 w-4 mr-2" /> सम्पादन
                        </Button>
                        <Button variant="destructive" className="flex-1">
                          <Trash2 className="h-4 w-4 mr-2" /> हटाउनुहोस्
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                  
                  {/* Tabs for additional info */}
                  <div className="md:w-2/3">
                    <div className="flex border-b mb-4">
                      <button 
                        className={`flex-1 py-2 px-4 text-center ${selectedTab === 'basic' ? 'border-b-2 border-primary text-primary font-medium' : 'text-neutral-400'}`}
                        onClick={() => setSelectedTab('basic')}
                      >
                        आधारभूत जानकारी
                      </button>
                      <button 
                        className={`flex-1 py-2 px-4 text-center ${selectedTab === 'tasks' ? 'border-b-2 border-primary text-primary font-medium' : 'text-neutral-400'}`}
                        onClick={() => setSelectedTab('tasks')}
                      >
                        कार्यहरू
                      </button>
                      <button 
                        className={`flex-1 py-2 px-4 text-center ${selectedTab === 'attendance' ? 'border-b-2 border-primary text-primary font-medium' : 'text-neutral-400'}`}
                        onClick={() => setSelectedTab('attendance')}
                      >
                        हाजिरी
                      </button>
                    </div>
                    
                    {selectedTab === 'basic' && (
                      <div>
                        <h4 className="font-medium mb-4">कार्य सारांश</h4>
                        
                        <div className="grid grid-cols-2 gap-4 mb-6">
                          <Card>
                            <CardContent className="p-4">
                              <div className="flex justify-between items-center">
                                <div>
                                  <p className="text-sm text-neutral-500">पूरा कार्यहरू</p>
                                  <p className="text-2xl font-bold">
                                    {getEmployeeTasks(selectedEmployee.id).filter((t: any) => t.status === 'completed').length}
                                  </p>
                                </div>
                                <FileText className="h-8 w-8 text-green-500" />
                              </div>
                            </CardContent>
                          </Card>
                          
                          <Card>
                            <CardContent className="p-4">
                              <div className="flex justify-between items-center">
                                <div>
                                  <p className="text-sm text-neutral-500">बाँकी कार्यहरू</p>
                                  <p className="text-2xl font-bold">
                                    {getEmployeeTasks(selectedEmployee.id).filter((t: any) => t.status !== 'completed').length}
                                  </p>
                                </div>
                                <FileText className="h-8 w-8 text-yellow-500" />
                              </div>
                            </CardContent>
                          </Card>
                        </div>
                        
                        <h4 className="font-medium mb-4">प्रदर्शन स्कोर</h4>
                        
                        <Card>
                          <CardContent className="p-4">
                            <div className="space-y-4">
                              <div>
                                <div className="flex justify-between items-center mb-1">
                                  <p className="text-sm">कार्य पूरा</p>
                                  <p className="text-sm font-medium">85%</p>
                                </div>
                                <div className="w-full bg-neutral-200 rounded-full h-2">
                                  <div className="bg-green-500 rounded-full h-2 w-[85%]"></div>
                                </div>
                              </div>
                              
                              <div>
                                <div className="flex justify-between items-center mb-1">
                                  <p className="text-sm">समय पालना</p>
                                  <p className="text-sm font-medium">78%</p>
                                </div>
                                <div className="w-full bg-neutral-200 rounded-full h-2">
                                  <div className="bg-yellow-500 rounded-full h-2 w-[78%]"></div>
                                </div>
                              </div>
                              
                              <div>
                                <div className="flex justify-between items-center mb-1">
                                  <p className="text-sm">गुणस्तर</p>
                                  <p className="text-sm font-medium">90%</p>
                                </div>
                                <div className="w-full bg-neutral-200 rounded-full h-2">
                                  <div className="bg-blue-500 rounded-full h-2 w-[90%]"></div>
                                </div>
                              </div>
                              
                              <div>
                                <div className="flex justify-between items-center mb-1">
                                  <p className="text-sm font-medium">समग्र स्कोर</p>
                                  <p className="text-sm font-medium">84%</p>
                                </div>
                                <div className="w-full bg-neutral-200 rounded-full h-3">
                                  <div className="bg-primary rounded-full h-3 w-[84%]"></div>
                                </div>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      </div>
                    )}
                    
                    {selectedTab === 'tasks' && (
                      <div>
                        <h4 className="font-medium mb-4">कार्यहरू</h4>
                        
                        {getEmployeeTasks(selectedEmployee.id).length === 0 ? (
                          <div className="text-center py-8 text-neutral-400">
                            <FileText className="h-12 w-12 mx-auto mb-2" />
                            <p>यस कर्मचारीलाई कुनै कार्य तोकिएको छैन</p>
                          </div>
                        ) : (
                          <div className="space-y-4">
                            {getEmployeeTasks(selectedEmployee.id).map((task: any) => (
                              <Card key={task.id}>
                                <CardContent className="p-4">
                                  <div className="flex justify-between items-start">
                                    <div>
                                      <h5 className="font-medium">{task.title}</h5>
                                      <p className="text-sm text-neutral-500 mt-1">{task.description}</p>
                                      <div className="flex items-center mt-2">
                                        <Badge variant="outline" className="mr-2">
                                          {task.type === 'daily' ? 'दैनिक' : 
                                           task.type === 'monthly' ? 'मासिक' : 'आकस्मिक'}
                                        </Badge>
                                        {task.deadline && (
                                          <span className="text-xs text-neutral-400">
                                            <Clock className="h-3 w-3 inline mr-1" />
                                            {format(new Date(task.deadline), 'yyyy/MM/dd h:mm a')}
                                          </span>
                                        )}
                                      </div>
                                    </div>
                                    <Badge variant={
                                      task.status === 'completed' ? 'default' : 
                                      task.status === 'in_progress' ? 'secondary' : 'outline'
                                    } className={
                                      task.status === 'completed' ? 'bg-green-100 text-green-800' : 
                                      task.status === 'in_progress' ? 'bg-blue-100 text-blue-800' : 
                                      'bg-yellow-100 text-yellow-800'
                                    }>
                                      {task.status === 'completed' ? 'पूरा भयो' : 
                                       task.status === 'in_progress' ? 'प्रगतिमा' : 'बाँकी'}
                                    </Badge>
                                  </div>
                                </CardContent>
                              </Card>
                            ))}
                          </div>
                        )}
                      </div>
                    )}
                    
                    {selectedTab === 'attendance' && (
                      <div>
                        <h4 className="font-medium mb-4">हाजिरी रेकर्ड</h4>
                        
                        <div className="text-center py-8 text-neutral-400">
                          <Clock className="h-12 w-12 mx-auto mb-2" />
                          <p>हाजिरी विवरण उपलब्ध छैन</p>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
                
                <DialogFooter>
                  <Button 
                    variant="outline" 
                    onClick={() => setSelectedEmployee(null)}
                  >
                    <XCircle className="h-4 w-4 mr-2" /> बन्द गर्नुहोस्
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          )}
        </div>
      </div>
    </div>
  );
}
