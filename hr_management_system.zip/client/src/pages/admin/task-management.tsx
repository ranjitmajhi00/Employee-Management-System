import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Header } from '@/components/layout/header';
import { Sidebar } from '@/components/layout/sidebar';
import { useAuth } from '@/hooks/use-auth';
import { useQuery, useMutation } from '@tanstack/react-query';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { useToast } from '@/hooks/use-toast';
import {
  FileText,
  Plus,
  Calendar,
  RefreshCw,
  CheckCircle2,
  XCircle,
  Search,
  Settings,
  Clock,
  User,
  Loader2
} from 'lucide-react';
import { format } from 'date-fns';

const taskFormSchema = z.object({
  title: z.string().min(3, { message: 'कार्यको शीर्षक कम्तिमा 3 अक्षरको हुनुपर्छ' }),
  description: z.string().min(10, { message: 'कार्यको विवरण कम्तिमा 10 अक्षरको हुनुपर्छ' }),
  type: z.enum(['daily', 'monthly', 'emergency']),
  assignedTo: z.string().min(1, { message: 'कर्मचारी छान्नुहोस्' }),
  deadline: z.string().optional()
});

type TaskFormValues = z.infer<typeof taskFormSchema>;

export default function AdminTaskManagement() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isNewTaskDialogOpen, setIsNewTaskDialogOpen] = useState(false);
  const [activeTab, setActiveTab] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  
  const toggleMobileMenu = () => setIsMobileMenuOpen(!isMobileMenuOpen);
  
  // Fetch all tasks
  const { data: tasks = [], refetch: refetchTasks } = useQuery({
    queryKey: ['/api/tasks'],
    enabled: !!user && user.role === 'admin',
  });
  
  // Fetch users for assignment
  const { data: users = [] } = useQuery({
    queryKey: ['/api/users'],
    enabled: !!user && user.role === 'admin',
  });
  
  const form = useForm<TaskFormValues>({
    resolver: zodResolver(taskFormSchema),
    defaultValues: {
      title: '',
      description: '',
      type: 'daily',
      assignedTo: '',
      deadline: ''
    }
  });
  
  // Create task mutation
  const createTaskMutation = useMutation({
    mutationFn: async (data: any) => {
      const res = await apiRequest("POST", "/api/tasks", data);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/tasks'] });
      toast({
        title: 'कार्य थपियो',
        description: 'नयाँ कार्य सफलतापूर्वक थपियो।',
      });
      setIsNewTaskDialogOpen(false);
      form.reset();
    },
    onError: (error: Error) => {
      toast({
        title: 'कार्य थप्न असफल',
        description: error.message,
        variant: 'destructive',
      });
    },
  });
  
  // Update task mutation
  const updateTaskMutation = useMutation({
    mutationFn: async ({ taskId, status }: { taskId: number, status: string }) => {
      const res = await apiRequest("PATCH", `/api/tasks/${taskId}`, { status });
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/tasks'] });
      toast({
        title: 'कार्य अपडेट भयो',
        description: 'कार्यको स्थिति अपडेट गरियो।',
      });
    },
    onError: (error: Error) => {
      toast({
        title: 'कार्य अपडेट असफल',
        description: error.message,
        variant: 'destructive',
      });
    },
  });
  
  const onSubmit = (data: TaskFormValues) => {
    const taskData = {
      ...data,
      assignedTo: parseInt(data.assignedTo),
      assignedBy: user?.id,
      status: 'pending',
      deadline: data.deadline ? new Date(data.deadline).toISOString() : undefined
    };
    
    createTaskMutation.mutate(taskData);
  };
  
  const handleStatusChange = (taskId: number, status: string) => {
    updateTaskMutation.mutate({ taskId, status });
  };
  
  // Filter tasks based on tab and search query
  const filteredTasks = tasks.filter((task: any) => {
    const matchesSearch = 
      task.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      task.description.toLowerCase().includes(searchQuery.toLowerCase());
    
    if (activeTab === 'all') return matchesSearch;
    return task.type === activeTab && matchesSearch;
  });
  
  // Get user name by ID
  const getUserName = (userId: number) => {
    const foundUser = users.find((u: any) => u.id === userId);
    return foundUser ? foundUser.name : `User #${userId}`;
  };
  
  if (!user || user.role !== 'admin') return null;
  
  return (
    <div className="min-h-screen flex flex-col">
      <Header onMenuToggle={toggleMobileMenu} />
      
      <div className="flex flex-1">
        <Sidebar isMobileOpen={isMobileMenuOpen} onClose={() => setIsMobileMenuOpen(false)} />
        
        <div className="flex-1 md:ml-64 p-4">
          <div className="flex justify-between items-center mb-6">
            <div>
              <h2 className="text-2xl font-medium text-neutral-500">कार्य व्यवस्थापन</h2>
              <p className="text-neutral-400">कर्मचारीहरूको कार्य व्यवस्थापन गर्नुहोस्</p>
            </div>
            <Button onClick={() => setIsNewTaskDialogOpen(true)}>
              <Plus className="h-4 w-4 mr-2" /> नयाँ कार्य
            </Button>
          </div>
          
          {/* Search and Filter */}
          <Card className="mb-6">
            <CardContent className="p-4 flex flex-col md:flex-row gap-4">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-neutral-400" />
                <Input
                  placeholder="कार्य खोज्नुहोस्..."
                  className="pl-10"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              <Button 
                variant="outline" 
                className="md:w-auto w-full"
                onClick={() => refetchTasks()}
              >
                <RefreshCw className="h-4 w-4 mr-2" /> रिफ्रेस
              </Button>
            </CardContent>
          </Card>
          
          {/* Tasks Tab */}
          <Card>
            <Tabs value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="w-full grid grid-cols-4">
                <TabsTrigger value="all">सबै कार्य</TabsTrigger>
                <TabsTrigger value="daily">दैनिक</TabsTrigger>
                <TabsTrigger value="monthly">मासिक</TabsTrigger>
                <TabsTrigger value="emergency">आकस्मिक</TabsTrigger>
              </TabsList>
              
              <CardContent className="p-4">
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>कार्य विवरण</TableHead>
                        <TableHead>प्रकार</TableHead>
                        <TableHead>कर्मचारी</TableHead>
                        <TableHead>समय सीमा</TableHead>
                        <TableHead>स्थिति</TableHead>
                        <TableHead className="text-right">कार्य</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredTasks.length === 0 ? (
                        <TableRow>
                          <TableCell colSpan={6} className="text-center py-8 text-neutral-400">
                            <FileText className="h-12 w-12 mx-auto mb-2" />
                            <p>कुनै कार्य फेला परेन</p>
                          </TableCell>
                        </TableRow>
                      ) : (
                        filteredTasks.map((task: any) => (
                          <TableRow key={task.id}>
                            <TableCell>
                              <div>
                                <p className="font-medium">{task.title}</p>
                                <p className="text-sm text-neutral-500 truncate max-w-[300px]">
                                  {task.description}
                                </p>
                              </div>
                            </TableCell>
                            <TableCell>
                              <Badge variant="outline" className="capitalize">
                                {task.type === 'daily' ? 'दैनिक' : 
                                 task.type === 'monthly' ? 'मासिक' : 'आकस्मिक'}
                              </Badge>
                            </TableCell>
                            <TableCell>
                              <div className="flex items-center">
                                <User className="h-4 w-4 mr-2 text-neutral-400" />
                                {getUserName(task.assignedTo)}
                              </div>
                            </TableCell>
                            <TableCell>
                              {task.deadline ? (
                                <div className="flex items-center text-sm">
                                  <Clock className="h-3 w-3 mr-1 text-neutral-400" />
                                  {format(new Date(task.deadline), 'yyyy/MM/dd')}
                                </div>
                              ) : (
                                <span className="text-neutral-400 text-sm">निर्धारित छैन</span>
                              )}
                            </TableCell>
                            <TableCell>
                              <Badge variant={
                                task.status === 'completed' ? 'default' : 
                                task.status === 'in_progress' ? 'secondary' : 'outline'
                              } className={
                                task.status === 'completed' ? 'bg-green-100 text-green-800' : 
                                task.status === 'in_progress' ? 'bg-blue-100 text-blue-800' : 
                                'bg-yellow-100 text-yellow-800'
                              }>
                                {task.status === 'completed' ? 'पूरा भयो' : 
                                 task.status === 'in_progress' ? 'प्रगतिमा' : 'बाँकी'}
                              </Badge>
                            </TableCell>
                            <TableCell className="text-right">
                              <div className="flex justify-end gap-2">
                                {task.status !== 'completed' && (
                                  <Button 
                                    variant="ghost" 
                                    size="sm"
                                    onClick={() => handleStatusChange(task.id, 'completed')}
                                    className="text-green-600"
                                  >
                                    <CheckCircle2 className="h-4 w-4" />
                                  </Button>
                                )}
                                <Button 
                                  variant="ghost" 
                                  size="sm"
                                >
                                  <Settings className="h-4 w-4" />
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        ))
                      )}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Tabs>
          </Card>
          
          {/* New Task Dialog */}
          <Dialog open={isNewTaskDialogOpen} onOpenChange={setIsNewTaskDialogOpen}>
            <DialogContent className="sm:max-w-[600px]">
              <DialogHeader>
                <DialogTitle>नयाँ कार्य थप्नुहोस्</DialogTitle>
              </DialogHeader>
              
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                  <FormField
                    control={form.control}
                    name="title"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>कार्य शीर्षक</FormLabel>
                        <FormControl>
                          <Input placeholder="कार्य शीर्षक" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="description"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>कार्य विवरण</FormLabel>
                        <FormControl>
                          <Textarea 
                            placeholder="कार्यको विस्तृत विवरण"
                            className="min-h-[100px]"
                            {...field} 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="type"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>कार्य प्रकार</FormLabel>
                          <Select 
                            onValueChange={field.onChange} 
                            defaultValue={field.value}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="कार्य प्रकार छान्नुहोस्" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="daily">दैनिक कार्य</SelectItem>
                              <SelectItem value="monthly">मासिक कार्य</SelectItem>
                              <SelectItem value="emergency">आकस्मिक कार्य</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="assignedTo"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>तोकिएको कर्मचारी</FormLabel>
                          <Select 
                            onValueChange={field.onChange} 
                            defaultValue={field.value}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="कर्मचारी छान्नुहोस्" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {users
                                .filter((u: any) => u.role !== 'admin')
                                .map((employee: any) => (
                                  <SelectItem 
                                    key={employee.id} 
                                    value={employee.id.toString()}
                                  >
                                    {employee.name}
                                  </SelectItem>
                                ))
                              }
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <FormField
                    control={form.control}
                    name="deadline"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>समय सीमा (Optional)</FormLabel>
                        <FormControl>
                          <Input 
                            type="datetime-local" 
                            {...field} 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <DialogFooter>
                    <Button 
                      type="button" 
                      variant="outline" 
                      onClick={() => setIsNewTaskDialogOpen(false)}
                    >
                      रद्द गर्नुहोस्
                    </Button>
                    <Button 
                      type="submit" 
                      disabled={createTaskMutation.isPending}
                    >
                      {createTaskMutation.isPending ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          थप्दै...
                        </>
                      ) : 'कार्य थप्नुहोस्'}
                    </Button>
                  </DialogFooter>
                </form>
              </Form>
            </DialogContent>
          </Dialog>
        </div>
      </div>
    </div>
  );
}
