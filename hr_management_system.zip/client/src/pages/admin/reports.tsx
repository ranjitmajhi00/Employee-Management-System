import React, { useState } from 'react';
import { Header } from '@/components/layout/header';
import { Sidebar } from '@/components/layout/sidebar';
import { useAuth } from '@/hooks/use-auth';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { PerformanceChart } from '@/components/dashboard/performance-chart';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import {
  BarChart,
  Calendar,
  Download,
  ArrowDown,
  PieChart,
  Users,
  CheckCircle2,
  CalendarOff,
  Loader2
} from 'lucide-react';
import { format } from 'date-fns';

export default function AdminReports() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [activeTab, setActiveTab] = useState('performance');
  const [selectedMonth, setSelectedMonth] = useState('all');
  const [selectedEmployee, setSelectedEmployee] = useState('all');
  const [exportFormat, setExportFormat] = useState('excel');
  const [isGeneratingReport, setIsGeneratingReport] = useState(false);
  
  const toggleMobileMenu = () => setIsMobileMenuOpen(!isMobileMenuOpen);
  
  // Fetch all users
  const { data: users = [] } = useQuery({
    queryKey: ['/api/users'],
    enabled: !!user && user.role === 'admin',
  });
  
  // Fetch all tasks
  const { data: tasks = [] } = useQuery({
    queryKey: ['/api/tasks'],
    enabled: !!user && user.role === 'admin',
  });
  
  // Fetch all attendance records
  const { data: attendance = [] } = useQuery({
    queryKey: ['/api/attendance/all/today'],
    enabled: !!user && user.role === 'admin',
  });
  
  // Fetch all leave records
  const { data: leaves = [] } = useQuery({
    queryKey: ['/api/leave'],
    enabled: !!user && user.role === 'admin',
  });
  
  // Mock evaluation data (since we don't have real evaluations for all employees)
  const generateMockEvaluationData = () => {
    return users
      .filter((u: any) => u.role !== 'admin')
      .map((employee: any) => {
        const months = [1, 2, 3, 4, 5, 6];
        return months.map(month => ({
          id: `${employee.id}-${month}`,
          userId: employee.id,
          month,
          year: 2023,
          taskCompletion: Math.floor(Math.random() * 15 + 85), // 85-100
          timeliness: Math.floor(Math.random() * 20 + 75), // 75-95
          quality: Math.floor(Math.random() * 15 + 80), // 80-95
          overallScore: Math.floor(Math.random() * 10 + 80), // 80-90
          comments: "मासिक मूल्यांकन",
          createdAt: new Date().toISOString()
        }));
      })
      .flat();
  };
  
  const mockEvaluations = generateMockEvaluationData();
  
  // Filter employees (non-admin users)
  const employees = users.filter((u: any) => u.role !== 'admin');
  
  // Calculate statistics
  const totalTasks = tasks.length;
  const completedTasks = tasks.filter((t: any) => t.status === 'completed').length;
  const pendingTasks = totalTasks - completedTasks;
  const taskCompletionRate = totalTasks > 0 ? (completedTasks / totalTasks) * 100 : 0;
  
  const approvedLeaves = leaves.filter((l: any) => l.status === 'approved').length;
  const pendingLeaves = leaves.filter((l: any) => l.status === 'pending').length;
  const totalLeaves = leaves.length;
  
  // Get employee names for display
  const getEmployeeName = (userId: number) => {
    const foundUser = users.find((u: any) => u.id === userId);
    return foundUser ? foundUser.name : `User #${userId}`;
  };
  
  // Get tasks by employee
  const getEmployeeTasks = (userId: number) => {
    return tasks.filter((t: any) => t.assignedTo === userId);
  };
  
  // Generate mock performance chart data
  const generatePerformanceData = () => {
    // Filter by selected employee if needed
    let filteredEvaluations = mockEvaluations;
    if (selectedEmployee !== 'all') {
      filteredEvaluations = mockEvaluations.filter(
        (e: any) => e.userId === parseInt(selectedEmployee)
      );
    }
    
    // Group by month
    const groupedByMonth = filteredEvaluations.reduce((acc: any, evalItem: any) => {
      const monthKey = `${evalItem.month}/${evalItem.year}`;
      if (!acc[monthKey]) {
        acc[monthKey] = {
          month: monthKey,
          taskCompletion: 0,
          timeliness: 0,
          quality: 0,
          overall: 0,
          count: 0
        };
      }
      
      acc[monthKey].taskCompletion += evalItem.taskCompletion;
      acc[monthKey].timeliness += evalItem.timeliness;
      acc[monthKey].quality += evalItem.quality;
      acc[monthKey].overall += evalItem.overallScore;
      acc[monthKey].count++;
      
      return acc;
    }, {});
    
    // Calculate averages
    return Object.values(groupedByMonth).map((group: any) => ({
      month: group.month,
      taskCompletion: Math.round(group.taskCompletion / group.count),
      timeliness: Math.round(group.timeliness / group.count),
      quality: Math.round(group.quality / group.count),
      overall: Math.round(group.overall / group.count)
    }));
  };
  
  const performanceData = generatePerformanceData();
  
  // Handle report export
  const handleExportReport = () => {
    setIsGeneratingReport(true);
    
    // Simulate report generation
    setTimeout(() => {
      setIsGeneratingReport(false);
      toast({
        title: 'रिपोर्ट तयार भयो',
        description: `${exportFormat.toUpperCase()} फर्म्याटमा रिपोर्ट डाउनलोड गर्न तयार छ।`
      });
    }, 1500);
  };
  
  if (!user || user.role !== 'admin') return null;
  
  return (
    <div className="min-h-screen flex flex-col">
      <Header onMenuToggle={toggleMobileMenu} />
      
      <div className="flex flex-1">
        <Sidebar isMobileOpen={isMobileMenuOpen} onClose={() => setIsMobileMenuOpen(false)} />
        
        <div className="flex-1 md:ml-64 p-4">
          <div className="flex justify-between items-center mb-6 flex-wrap gap-4">
            <div>
              <h2 className="text-2xl font-medium text-neutral-500">रिपोर्ट तथा विश्लेषण</h2>
              <p className="text-neutral-400">कर्मचारी प्रदर्शन र हाजिरी विश्लेषण</p>
            </div>
            
            <div className="flex items-center gap-2">
              <Select
                value={exportFormat}
                onValueChange={setExportFormat}
              >
                <SelectTrigger className="w-[100px]">
                  <SelectValue placeholder="Format" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="excel">Excel</SelectItem>
                  <SelectItem value="pdf">PDF</SelectItem>
                  <SelectItem value="csv">CSV</SelectItem>
                </SelectContent>
              </Select>
              
              <Button 
                variant="outline" 
                className="flex items-center gap-2"
                onClick={handleExportReport}
                disabled={isGeneratingReport}
              >
                {isGeneratingReport ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <ArrowDown className="h-4 w-4" />
                )}
                {isGeneratingReport ? 'तयार हुदैछ...' : 'रिपोर्ट डाउनलोड'}
              </Button>
            </div>
          </div>
          
          {/* Summary Cards */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
            <Card>
              <CardContent className="p-4 flex flex-col items-center justify-center">
                <div className="h-16 w-16 rounded-full bg-blue-100 flex items-center justify-center mb-2">
                  <Users className="h-8 w-8 text-blue-700" />
                </div>
                <p className="text-center text-neutral-500">कुल कर्मचारी</p>
                <p className="text-center text-2xl font-bold">{employees.length}</p>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-4 flex flex-col items-center justify-center">
                <div className="h-16 w-16 rounded-full bg-green-100 flex items-center justify-center mb-2">
                  <CheckCircle2 className="h-8 w-8 text-green-700" />
                </div>
                <p className="text-center text-neutral-500">कार्य पूरा दर</p>
                <p className="text-center text-2xl font-bold">{taskCompletionRate.toFixed(0)}%</p>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-4 flex flex-col items-center justify-center">
                <div className="h-16 w-16 rounded-full bg-yellow-100 flex items-center justify-center mb-2">
                  <Calendar className="h-8 w-8 text-yellow-700" />
                </div>
                <p className="text-center text-neutral-500">हाजिरी दर</p>
                <p className="text-center text-2xl font-bold">85%</p>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-4 flex flex-col items-center justify-center">
                <div className="h-16 w-16 rounded-full bg-purple-100 flex items-center justify-center mb-2">
                  <CalendarOff className="h-8 w-8 text-purple-700" />
                </div>
                <p className="text-center text-neutral-500">बिदा स्वीकृत</p>
                <p className="text-center text-2xl font-bold">{approvedLeaves}</p>
              </CardContent>
            </Card>
          </div>
          
          {/* Filter Controls */}
          <Card className="mb-6">
            <CardContent className="p-4">
              <div className="flex flex-col md:flex-row gap-4">
                <div className="flex-1">
                  <Select
                    value={selectedEmployee}
                    onValueChange={setSelectedEmployee}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="कर्मचारी छान्नुहोस्" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">सबै कर्मचारी</SelectItem>
                      {employees.map((emp: any) => (
                        <SelectItem key={emp.id} value={emp.id.toString()}>
                          {emp.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="flex-1">
                  <Select
                    value={selectedMonth}
                    onValueChange={setSelectedMonth}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="महिना छान्नुहोस्" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">सबै महिना</SelectItem>
                      <SelectItem value="1">जनवरी</SelectItem>
                      <SelectItem value="2">फेब्रुअरी</SelectItem>
                      <SelectItem value="3">मार्च</SelectItem>
                      <SelectItem value="4">अप्रिल</SelectItem>
                      <SelectItem value="5">मे</SelectItem>
                      <SelectItem value="6">जून</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardContent>
          </Card>
          
          {/* Report Tabs */}
          <Card>
            <Tabs value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="w-full grid grid-cols-3 p-0">
                <TabsTrigger value="performance" className="flex items-center gap-2">
                  <BarChart className="h-4 w-4" /> प्रदर्शन विश्लेषण
                </TabsTrigger>
                <TabsTrigger value="attendance" className="flex items-center gap-2">
                  <Calendar className="h-4 w-4" /> हाजिरी विश्लेषण
                </TabsTrigger>
                <TabsTrigger value="leave" className="flex items-center gap-2">
                  <CalendarOff className="h-4 w-4" /> बिदा विश्लेषण
                </TabsTrigger>
              </TabsList>
              
              <TabsContent value="performance" className="p-4">
                <div className="mb-6">
                  <CardHeader className="px-0 pt-0">
                    <CardTitle className="text-xl">कर्मचारी प्रदर्शन विश्लेषण</CardTitle>
                  </CardHeader>
                  
                  {performanceData.length > 0 ? (
                    <div className="h-80">
                      <PerformanceChart data={performanceData} />
                    </div>
                  ) : (
                    <div className="text-center py-12">
                      <BarChart className="h-12 w-12 mx-auto mb-2 text-neutral-300" />
                      <p className="text-neutral-500">प्रदर्शन डाटा उपलब्ध छैन</p>
                    </div>
                  )}
                </div>
                
                <CardHeader className="px-0 py-2">
                  <CardTitle className="text-lg">कर्मचारी प्रदर्शन सारांश</CardTitle>
                </CardHeader>
                
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>कर्मचारी</TableHead>
                      <TableHead className="text-center">तोकिएको कार्य</TableHead>
                      <TableHead className="text-center">पूरा कार्य</TableHead>
                      <TableHead className="text-center">कार्य पूरा दर</TableHead>
                      <TableHead className="text-center">समग्र स्कोर</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {employees.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={5} className="text-center py-8 text-neutral-400">
                          <p>कुनै कर्मचारी डाटा उपलब्ध छैन</p>
                        </TableCell>
                      </TableRow>
                    ) : (
                      employees.map((employee: any) => {
                        const employeeTasks = getEmployeeTasks(employee.id);
                        const totalEmpTasks = employeeTasks.length;
                        const completedEmpTasks = employeeTasks.filter((t: any) => t.status === 'completed').length;
                        const completionRate = totalEmpTasks > 0 ? (completedEmpTasks / totalEmpTasks) * 100 : 0;
                        
                        // Get average overall score from evaluations
                        const empEvaluations = mockEvaluations.filter((e: any) => e.userId === employee.id);
                        const avgScore = empEvaluations.length > 0 
                          ? Math.round(empEvaluations.reduce((sum, e) => sum + e.overallScore, 0) / empEvaluations.length)
                          : 0;
                        
                        return (
                          <TableRow key={employee.id}>
                            <TableCell className="font-medium">{employee.name}</TableCell>
                            <TableCell className="text-center">{totalEmpTasks}</TableCell>
                            <TableCell className="text-center">{completedEmpTasks}</TableCell>
                            <TableCell className="text-center">
                              <span className={
                                completionRate >= 80 ? 'text-green-600' : 
                                completionRate >= 60 ? 'text-yellow-600' : 'text-red-600'
                              }>
                                {completionRate.toFixed(0)}%
                              </span>
                            </TableCell>
                            <TableCell className="text-center">
                              <span className={
                                avgScore >= 80 ? 'text-green-600' : 
                                avgScore >= 60 ? 'text-yellow-600' : 'text-red-600'
                              }>
                                {avgScore}%
                              </span>
                            </TableCell>
                          </TableRow>
                        );
                      })
                    )}
                  </TableBody>
                </Table>
              </TabsContent>
              
              <TabsContent value="attendance" className="p-4">
                <div className="mb-6">
                  <CardHeader className="px-0 pt-0">
                    <CardTitle className="text-xl">हाजिरी विश्लेषण</CardTitle>
                  </CardHeader>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                    <Card>
                      <CardContent className="p-4">
                        <CardTitle className="text-lg mb-4">हाजिरी सारांश</CardTitle>
                        <div className="space-y-4">
                          <div>
                            <div className="flex justify-between items-center mb-1">
                              <p className="text-sm font-medium">औसत उपस्थिति दर</p>
                              <p className="text-sm font-medium text-green-600">85%</p>
                            </div>
                            <div className="w-full bg-neutral-200 rounded-full h-2">
                              <div className="bg-green-500 rounded-full h-2 w-[85%]"></div>
                            </div>
                          </div>
                          
                          <div>
                            <div className="flex justify-between items-center mb-1">
                              <p className="text-sm font-medium">समयमै आउने दर</p>
                              <p className="text-sm font-medium text-yellow-600">75%</p>
                            </div>
                            <div className="w-full bg-neutral-200 rounded-full h-2">
                              <div className="bg-yellow-500 rounded-full h-2 w-[75%]"></div>
                            </div>
                          </div>
                          
                          <div>
                            <div className="flex justify-between items-center mb-1">
                              <p className="text-sm font-medium">अनुपस्थिति दर</p>
                              <p className="text-sm font-medium text-red-600">15%</p>
                            </div>
                            <div className="w-full bg-neutral-200 rounded-full h-2">
                              <div className="bg-red-500 rounded-full h-2 w-[15%]"></div>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                    
                    <Card>
                      <CardContent className="p-4 flex items-center justify-center">
                        <PieChart className="h-40 w-40" />
                      </CardContent>
                    </Card>
                  </div>
                </div>
                
                <CardHeader className="px-0 py-2">
                  <CardTitle className="text-lg">कर्मचारी हाजिरी विवरण</CardTitle>
                </CardHeader>
                
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>कर्मचारी</TableHead>
                      <TableHead className="text-center">समयमै आउने</TableHead>
                      <TableHead className="text-center">ढिलो आउने</TableHead>
                      <TableHead className="text-center">अनुपस्थित</TableHead>
                      <TableHead className="text-center">हाजिरी दर</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {employees.map((employee: any) => (
                      <TableRow key={employee.id}>
                        <TableCell className="font-medium">{employee.name}</TableCell>
                        <TableCell className="text-center">{Math.floor(Math.random() * 20 + 10)}</TableCell>
                        <TableCell className="text-center">{Math.floor(Math.random() * 5 + 1)}</TableCell>
                        <TableCell className="text-center">{Math.floor(Math.random() * 3)}</TableCell>
                        <TableCell className="text-center">
                          <span className="text-green-600">
                            {Math.floor(Math.random() * 15 + 85)}%
                          </span>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TabsContent>
              
              <TabsContent value="leave" className="p-4">
                <div className="mb-6">
                  <CardHeader className="px-0 pt-0">
                    <CardTitle className="text-xl">बिदा विश्लेषण</CardTitle>
                  </CardHeader>
                  
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                    <Card>
                      <CardContent className="p-4 text-center">
                        <p className="text-sm text-neutral-500">कुल बिदा अनुरोध</p>
                        <p className="text-3xl font-bold">{totalLeaves}</p>
                      </CardContent>
                    </Card>
                    
                    <Card>
                      <CardContent className="p-4 text-center">
                        <p className="text-sm text-neutral-500">स्वीकृत बिदा</p>
                        <p className="text-3xl font-bold text-green-600">{approvedLeaves}</p>
                      </CardContent>
                    </Card>
                    
                    <Card>
                      <CardContent className="p-4 text-center">
                        <p className="text-sm text-neutral-500">विचाराधीन बिदा</p>
                        <p className="text-3xl font-bold text-yellow-600">{pendingLeaves}</p>
                      </CardContent>
                    </Card>
                  </div>
                </div>
                
                <CardHeader className="px-0 py-2">
                  <CardTitle className="text-lg">बिदा अनुरोध विवरण</CardTitle>
                </CardHeader>
                
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>कर्मचारी</TableHead>
                      <TableHead>बिदा प्रकार</TableHead>
                      <TableHead>अवधि</TableHead>
                      <TableHead>स्थिति</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {leaves.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={4} className="text-center py-8 text-neutral-400">
                          <p>कुनै बिदा अनुरोध डाटा उपलब्ध छैन</p>
                        </TableCell>
                      </TableRow>
                    ) : (
                      leaves.map((leave: any) => (
                        <TableRow key={leave.id}>
                          <TableCell className="font-medium">
                            {getEmployeeName(leave.userId)}
                          </TableCell>
                          <TableCell>
                            {leave.type === 'sick' ? 'बिरामी बिदा' : 
                             leave.type === 'personal' ? 'व्यक्तिगत बिदा' : 'वार्षिक बिदा'}
                          </TableCell>
                          <TableCell>
                            {format(new Date(leave.startDate), 'yyyy/MM/dd')} - {format(new Date(leave.endDate), 'yyyy/MM/dd')}
                          </TableCell>
                          <TableCell>
                            <span className={
                              leave.status === 'approved' ? 'text-green-600' : 
                              leave.status === 'rejected' ? 'text-red-600' : 'text-yellow-600'
                            }>
                              {leave.status === 'approved' ? 'स्वीकृत' : 
                               leave.status === 'rejected' ? 'अस्वीकृत' : 'विचाराधीन'}
                            </span>
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </TabsContent>
            </Tabs>
          </Card>
        </div>
      </div>
    </div>
  );
}
