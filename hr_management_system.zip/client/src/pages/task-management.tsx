import React, { useState } from 'react';
import { Header } from '@/components/layout/header';
import { Sidebar } from '@/components/layout/sidebar';
import { useAuth } from '@/hooks/use-auth';
import { Card } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { TaskList } from '@/components/tasks/task-list';
import { TaskForm } from '@/components/tasks/task-form';

export default function TaskManagement() {
  const { user } = useAuth();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<string>('daily');
  const [selectedTask, setSelectedTask] = useState<any>(null);
  const [isTaskFormOpen, setIsTaskFormOpen] = useState(false);
  
  const toggleMobileMenu = () => setIsMobileMenuOpen(!isMobileMenuOpen);
  
  const handleTaskSelect = (task: any) => {
    setSelectedTask(task);
    setIsTaskFormOpen(true);
  };
  
  return (
    <div className="min-h-screen flex flex-col">
      <Header onMenuToggle={toggleMobileMenu} />
      
      <div className="flex flex-1">
        <Sidebar isMobileOpen={isMobileMenuOpen} onClose={() => setIsMobileMenuOpen(false)} />
        
        <div className="flex-1 md:ml-64 p-4">
          <div className="mb-6">
            <h2 className="text-2xl font-medium text-neutral-500">कार्य व्यवस्थापन</h2>
            <p className="text-neutral-400">तपाईंको कार्यहरू व्यवस्थापन गर्नुहोस्</p>
          </div>
          
          <Card>
            <Tabs value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="w-full grid grid-cols-3">
                <TabsTrigger value="daily">दैनिक कार्य</TabsTrigger>
                <TabsTrigger value="monthly">मासिक कार्य</TabsTrigger>
                <TabsTrigger value="emergency">आकस्मिक कार्य</TabsTrigger>
              </TabsList>
              
              <div className="p-4">
                <TabsContent value="daily" className="mt-0">
                  <TaskList type="daily" onTaskSelect={handleTaskSelect} />
                </TabsContent>
                
                <TabsContent value="monthly" className="mt-0">
                  <TaskList type="monthly" onTaskSelect={handleTaskSelect} />
                </TabsContent>
                
                <TabsContent value="emergency" className="mt-0">
                  <TaskList type="emergency" onTaskSelect={handleTaskSelect} />
                </TabsContent>
              </div>
            </Tabs>
          </Card>
          
          {selectedTask && (
            <TaskForm 
              task={selectedTask} 
              isOpen={isTaskFormOpen} 
              onClose={() => {
                setIsTaskFormOpen(false);
                setSelectedTask(null);
              }} 
            />
          )}
        </div>
      </div>
    </div>
  );
}
