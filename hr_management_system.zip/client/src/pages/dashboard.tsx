import React, { useState } from 'react';
import { Header } from '@/components/layout/header';
import { Sidebar } from '@/components/layout/sidebar';
import { useAuth } from '@/hooks/use-auth';
import { useQrCode } from '@/hooks/use-qr-code';
import { useQuery, useMutation } from '@tanstack/react-query';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { AlertCircle, RefreshCw, Clock, CalendarOff, Bell, LogIn, LogOut } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { format } from 'date-fns';

export default function Dashboard() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const { qrDataUrl: checkinQrUrl, qrCode: checkinCode } = useQrCode('check_in');
  const { qrDataUrl: checkoutQrUrl, qrCode: checkoutCode } = useQrCode('check_out');
  
  const toggleMobileMenu = () => setIsMobileMenuOpen(!isMobileMenuOpen);
  
  // Fetch today's attendance
  const { data: todayAttendance = [] } = useQuery({
    queryKey: ['/api/attendance/today'],
    enabled: !!user,
  });
  
  const hasCheckedIn = todayAttendance.some((a: any) => a.type === 'check_in');
  const hasCheckedOut = todayAttendance.some((a: any) => a.type === 'check_out');
  
  // Fetch notifications
  const { data: notifications = [] } = useQuery({
    queryKey: ['/api/notifications'],
    enabled: !!user,
  });
  
  // Fetch tasks
  const { data: tasks = [], refetch: refetchTasks } = useQuery({
    queryKey: ['/api/tasks/user'],
    enabled: !!user,
  });
  
  // Fetch user's latest evaluation
  const { data: evaluation } = useQuery({
    queryKey: ['/api/evaluation/latest/user', user?.id],
    enabled: !!user,
  });
  
  // Fetch leave balance
  const { data: leaves = [] } = useQuery({
    queryKey: ['/api/leave'],
    enabled: !!user,
  });
  
  // Record attendance mutation
  const recordAttendanceMutation = useMutation({
    mutationFn: async ({ type, qrCode }: { type: string, qrCode: string }) => {
      // Get current location
      const position = await new Promise<GeolocationPosition>((resolve, reject) => {
        navigator.geolocation.getCurrentPosition(resolve, reject);
      });
      
      const geoLocation = `${position.coords.latitude},${position.coords.longitude}`;
      
      const res = await apiRequest("POST", "/api/attendance", {
        type,
        qrCode,
        geoLocation
      });
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/attendance/today'] });
      toast({
        title: 'Attendance Successful',
        description: 'Your attendance has been recorded successfully.',
      });
    },
    onError: (error: Error) => {
      toast({
        title: 'Attendance Failed',
        description: error.message,
        variant: 'destructive',
      });
    },
  });
  
  const handleAttendance = async (type: 'check_in' | 'check_out') => {
    if (!navigator.geolocation) {
      toast({
        title: 'Error',
        description: 'Your browser does not support geolocation.',
        variant: 'destructive',
      });
      return;
    }
    
    try {
      const qrCode = type === 'check_in' ? checkinCode : checkoutCode;
      if (!qrCode) {
        throw new Error('QR Code not found, please try again.');
      }
      
      await recordAttendanceMutation.mutateAsync({ type, qrCode });
    } catch (error) {
      console.error("Attendance error:", error);
    }
  };
  
  // Calculate leave balance
  const totalLeaveAllocation = 18; // Example: 18 days per year
  const usedLeaves = leaves.filter((leave: any) => leave.status === 'approved').length;
  const pendingLeaves = leaves.filter((leave: any) => leave.status === 'pending').length;
  const remainingLeaves = totalLeaveAllocation - usedLeaves;
  
  // Filter tasks
  const pendingTasks = tasks.filter((task: any) => task.status !== 'completed');
  const completedTasks = tasks.filter((task: any) => task.status === 'completed');
  
  // Get check-in time
  const checkInRecord = todayAttendance.find((a: any) => a.type === 'check_in');
  const checkInTime = checkInRecord ? format(new Date(checkInRecord.timestamp), 'h:mm a') : '-';
  
  // Calculate work hours (if checked in and out)
  const checkOutRecord = todayAttendance.find((a: any) => a.type === 'check_out');
  let workHours = '-';
  if (checkInRecord && checkOutRecord) {
    const checkInDate = new Date(checkInRecord.timestamp);
    const checkOutDate = new Date(checkOutRecord.timestamp);
    const diffMs = checkOutDate.getTime() - checkInDate.getTime();
    const diffHrs = Math.floor(diffMs / (1000 * 60 * 60));
    const diffMins = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));
    workHours = `${diffHrs} घण्टा ${diffMins} मिनेट`;
  }

  if (!user) return null;

  return (
    <div className="min-h-screen flex flex-col">
      <Header onMenuToggle={toggleMobileMenu} />
      
      <div className="flex flex-1">
        <Sidebar isMobileOpen={isMobileMenuOpen} onClose={() => setIsMobileMenuOpen(false)} />
        
        <div className="flex-1 md:ml-64 p-4">
          <div className="mb-6">
            <h2 className="text-2xl font-medium text-neutral-500">Dashboard</h2>
            <p className="text-neutral-400">Welcome, {user.name}!</p>
          </div>

          {/* Quick Actions */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            {/* Attendance Card */}
            <Card>
              <CardContent className="p-4">
                <div className="flex justify-between items-center mb-4">
                  <h3 className="text-lg font-medium">Today's Attendance</h3>
                  <Clock className="h-5 w-5 text-neutral-300" />
                </div>
                
                {/* QR Code Section */}
                <div className="mb-4">
                  <div className="h-48 w-full mb-2 flex items-center justify-center border rounded bg-gray-50">
                    {(hasCheckedIn && !hasCheckedOut && checkoutQrUrl) ? (
                      <img src={checkoutQrUrl} alt="Checkout QR Code" className="h-40 w-40" />
                    ) : (!hasCheckedIn && checkinQrUrl) ? (
                      <img src={checkinQrUrl} alt="Checkin QR Code" className="h-40 w-40" />
                    ) : (
                      <div className="bg-white p-2 rounded text-center">
                        <p className="text-sm mb-1">QR कोड {hasCheckedIn && hasCheckedOut ? 'देखिएन' : 'लोड हुँदैछ...'}</p>
                        <p className="text-xs text-neutral-300">हरेक दिन परिवर्तन हुन्छ</p>
                      </div>
                    )}
                  </div>
                  
                  <div className="flex gap-2">
                    <Button 
                      className="flex-1" 
                      disabled={hasCheckedIn || recordAttendanceMutation.isPending} 
                      onClick={() => handleAttendance('check_in')}
                    >
                      <LogIn className="h-4 w-4 mr-1" /> चेक-इन
                    </Button>
                    <Button 
                      className="flex-1" 
                      variant={hasCheckedIn ? "default" : "secondary"} 
                      disabled={!hasCheckedIn || hasCheckedOut || recordAttendanceMutation.isPending}
                      onClick={() => handleAttendance('check_out')}
                    >
                      <LogOut className="h-4 w-4 mr-1" /> चेक-आउट
                    </Button>
                  </div>
                </div>
                
                <div className="text-sm">
                  <p><span className="font-medium">स्थिति:</span> {' '}
                    {hasCheckedIn ? (
                      <span className="text-green-600">चेक-इन ({checkInTime})</span>
                    ) : (
                      <span className="text-neutral-400">अनुपस्थित</span>
                    )}
                  </p>
                  <p><span className="font-medium">कार्य समय:</span> <span>{workHours}</span></p>
                </div>
              </CardContent>
            </Card>
            
            {/* Leave Balance Card */}
            <Card>
              <CardContent className="p-4">
                <div className="flex justify-between items-center mb-4">
                  <h3 className="text-lg font-medium">बिदा ब्यालेन्स</h3>
                  <CalendarOff className="h-5 w-5 text-neutral-300" />
                </div>
                
                <div className="grid grid-cols-2 gap-2 mb-4">
                  <div className="bg-neutral-100 rounded p-3 text-center">
                    <p className="text-2xl font-medium text-primary">{remainingLeaves}</p>
                    <p className="text-sm">बाँकी दिन</p>
                  </div>
                  <div className="bg-neutral-100 rounded p-3 text-center">
                    <p className="text-2xl font-medium text-neutral-400">{usedLeaves}</p>
                    <p className="text-sm">प्रयोग गरिएको</p>
                  </div>
                </div>
                
                <Button 
                  variant="secondary" 
                  className="w-full bg-primary-light text-white mb-2"
                  onClick={() => window.location.href = '/leave'}
                >
                  बिदाको लागि आवेदन दिनुहोस्
                </Button>
                
                <div className="text-sm">
                  <p>
                    <span className="font-medium">पेन्डिंग बिदा:</span> <span>{pendingLeaves} दिन</span>
                  </p>
                  <p>
                    <span className="font-medium">वार्षिक छुट्टी:</span> <span>{totalLeaveAllocation} दिन</span>
                  </p>
                </div>
              </CardContent>
            </Card>
            
            {/* Notifications Card */}
            <Card>
              <CardContent className="p-4">
                <div className="flex justify-between items-center mb-4">
                  <h3 className="text-lg font-medium">सूचना तथा जानकारी</h3>
                  <Bell className="h-5 w-5 text-neutral-300" />
                </div>
                
                <ul className="space-y-3">
                  {notifications.length === 0 ? (
                    <li className="text-center text-neutral-400 py-4">
                      कुनै सूचना छैन
                    </li>
                  ) : (
                    notifications.slice(0, 3).map((notification: any) => (
                      <li key={notification.id} className="flex items-start gap-2">
                        <span className={`${notification.isRead ? 'text-gray-400' : 'text-red-500'}`}>
                          <AlertCircle className="h-4 w-4" />
                        </span>
                        <div>
                          <p className={`text-sm font-medium ${notification.isRead ? 'text-gray-500' : ''}`}>
                            {notification.title}
                          </p>
                          <p className="text-xs text-neutral-300">
                            {notification.message.length > 50 
                              ? `${notification.message.substring(0, 50)}...` 
                              : notification.message}
                          </p>
                        </div>
                      </li>
                    ))
                  )}
                </ul>
                
                <Button 
                  variant="outline" 
                  className="w-full mt-4 border-primary text-primary"
                >
                  सबै हेर्नुहोस्
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Tasks Section */}
          <div className="mb-6">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-xl font-medium">मेरो कार्यहरू</h3>
              <Button 
                variant="ghost" 
                className="text-primary text-sm" 
                onClick={() => refetchTasks()}
              >
                <RefreshCw className="h-4 w-4 mr-1" /> रिफ्रेस गर्नुहोस्
              </Button>
            </div>

            {/* Task Categories Tabs */}
            <Card>
              <div className="flex border-b">
                <button className="flex-1 py-3 px-4 text-center border-b-2 border-primary text-primary font-medium">
                  दैनिक कार्य
                </button>
                <button className="flex-1 py-3 px-4 text-center text-neutral-400 hover:bg-neutral-100">
                  मासिक कार्य
                </button>
                <button className="flex-1 py-3 px-4 text-center text-neutral-400 hover:bg-neutral-100">
                  आकस्मिक कार्य
                </button>
              </div>

              {/* Task List */}
              <div className="p-4">
                {pendingTasks.length === 0 ? (
                  <div className="text-center py-8 text-neutral-400">
                    <p>कुनै बाँकी कार्य छैन</p>
                  </div>
                ) : (
                  pendingTasks.slice(0, 3).map((task: any) => (
                    <div key={task.id} className="border-b pb-4 mb-4 last:border-0 last:mb-0 last:pb-0">
                      <div className="flex justify-between items-start">
                        <div>
                          <h4 className="font-medium">{task.title}</h4>
                          <p className="text-sm text-neutral-400 mt-1">{task.description}</p>
                        </div>
                        <Badge variant="outline" className={`
                          ${task.status === 'pending' ? 'bg-warning/20 text-warning' : 
                            task.status === 'in_progress' ? 'bg-primary/20 text-primary' : 
                            'bg-success/20 text-success'}
                        `}>
                          {task.deadline ? format(new Date(task.deadline), 'yyyy/MM/dd h:mm a') : 'No deadline'}
                        </Badge>
                      </div>
                      
                      <div className="mt-3 flex justify-between items-center">
                        <div className="flex items-center">
                          <Clock className="h-4 w-4 text-neutral-300 mr-1" />
                          <span className="text-xs text-neutral-300">
                            {task.deadline ? 
                              `${Math.floor((new Date(task.deadline).getTime() - new Date().getTime()) / (1000 * 60 * 60))} घण्टा बाँकी` : 
                              'No deadline'}
                          </span>
                        </div>
                        <Button size="sm" onClick={() => window.location.href = '/tasks'}>
                          पेश गर्नुहोस्
                        </Button>
                      </div>
                    </div>
                  ))
                )}
                
                {pendingTasks.length > 3 && (
                  <div className="text-center mt-4">
                    <Button 
                      variant="link" 
                      className="text-primary"
                      onClick={() => window.location.href = '/tasks'}
                    >
                      सबै कार्य हेर्नुहोस्
                    </Button>
                  </div>
                )}
              </div>
            </Card>
          </div>

          {/* Self Evaluation Section */}
          <Card className="mb-6">
            <CardContent className="p-4">
              <h3 className="text-lg font-medium mb-4">स्व-मूल्यांकन</h3>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                <div className="bg-neutral-100 rounded p-3">
                  <div className="flex justify-between items-center mb-1">
                    <p className="text-sm font-medium">कार्य पूरा</p>
                    <p className="text-sm text-green-600 font-medium">
                      {evaluation ? evaluation.taskCompletion : '-'}%
                    </p>
                  </div>
                  <div className="w-full bg-neutral-200 rounded-full h-2">
                    <div 
                      className="bg-green-500 rounded-full h-2" 
                      style={{ width: evaluation ? `${evaluation.taskCompletion}%` : '0%' }}
                    ></div>
                  </div>
                </div>
                
                <div className="bg-neutral-100 rounded p-3">
                  <div className="flex justify-between items-center mb-1">
                    <p className="text-sm font-medium">समय पालना</p>
                    <p className="text-sm text-yellow-600 font-medium">
                      {evaluation ? evaluation.timeliness : '-'}%
                    </p>
                  </div>
                  <div className="w-full bg-neutral-200 rounded-full h-2">
                    <div 
                      className="bg-yellow-500 rounded-full h-2" 
                      style={{ width: evaluation ? `${evaluation.timeliness}%` : '0%' }}
                    ></div>
                  </div>
                </div>
                
                <div className="bg-neutral-100 rounded p-3">
                  <div className="flex justify-between items-center mb-1">
                    <p className="text-sm font-medium">समग्र प्रदर्शन</p>
                    <p className="text-sm text-primary font-medium">
                      {evaluation ? evaluation.overallScore : '-'}%
                    </p>
                  </div>
                  <div className="w-full bg-neutral-200 rounded-full h-2">
                    <div 
                      className="bg-primary rounded-full h-2" 
                      style={{ width: evaluation ? `${evaluation.overallScore}%` : '0%' }}
                    ></div>
                  </div>
                </div>
              </div>
              
              <Button 
                variant="outline" 
                className="w-full border-primary text-primary"
                onClick={() => window.location.href = '/reports'}
              >
                विस्तृत प्रदर्शन रिपोर्ट हेर्नुहोस्
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
