import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Header } from '@/components/layout/header';
import { Sidebar } from '@/components/layout/sidebar';
import { useAuth } from '@/hooks/use-auth';
import { useMutation } from '@tanstack/react-query';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle,
  CardDescription,
  CardFooter
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Separator } from '@/components/ui/separator';
import { useToast } from '@/hooks/use-toast';
import { User, Mail, Phone, MapPin, Camera } from 'lucide-react';

const profileSchema = z.object({
  name: z.string().min(1, 'नाम आवश्यक छ'),
  email: z.string().email('मान्य इमेल ठेगाना हालनुहोस्'),
  phone: z.string().optional(),
  address: z.string().optional(),
  profilePhoto: z.string().optional(),
});

type ProfileValues = z.infer<typeof profileSchema>;

export default function Profile() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [photoPreview, setPhotoPreview] = useState<string | null>(user?.profilePhoto || null);
  
  const toggleMobileMenu = () => setIsMobileMenuOpen(!isMobileMenuOpen);
  
  const form = useForm<ProfileValues>({
    resolver: zodResolver(profileSchema),
    defaultValues: {
      name: user?.name || '',
      email: user?.email || '',
      phone: user?.phone || '',
      address: user?.address || '',
      profilePhoto: user?.profilePhoto || '',
    },
  });
  
  const updateProfileMutation = useMutation({
    mutationFn: async (data: ProfileValues) => {
      const res = await apiRequest("PATCH", `/api/users/${user?.id}`, data);
      return await res.json();
    },
    onSuccess: (updatedUser) => {
      queryClient.setQueryData(['/api/user'], { ...user, ...updatedUser });
      toast({
        title: 'प्रोफाइल अपडेट भयो',
        description: 'तपाईंको प्रोफाइल सफलतापूर्वक अपडेट गरियो',
      });
    },
    onError: (error: Error) => {
      toast({
        title: 'प्रोफाइल अपडेट त्रुटि',
        description: error.message,
        variant: 'destructive',
      });
    },
  });
  
  const handlePhotoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    
    if (file.size > 5 * 1024 * 1024) {
      toast({
        title: 'फाइल अति ठूलो छ',
        description: 'फाइल साइज 5MB भन्दा कम हुनुपर्छ',
        variant: 'destructive',
      });
      return;
    }
    
    const reader = new FileReader();
    reader.onload = (event) => {
      if (event.target?.result) {
        setPhotoPreview(event.target.result as string);
        form.setValue('profilePhoto', event.target.result as string);
      }
    };
    reader.readAsDataURL(file);
  };
  
  const onSubmit = (data: ProfileValues) => {
    updateProfileMutation.mutate(data);
  };
  
  if (!user) return null;
  
  return (
    <div className="min-h-screen flex flex-col">
      <Header onMenuToggle={toggleMobileMenu} />
      
      <div className="flex flex-1">
        <Sidebar isMobileOpen={isMobileMenuOpen} onClose={() => setIsMobileMenuOpen(false)} />
        
        <div className="flex-1 md:ml-64 p-4">
          <div className="mb-6">
            <h2 className="text-2xl font-medium text-neutral-500">प्रोफाइल</h2>
            <p className="text-neutral-400">तपाईंको व्यक्तिगत जानकारी व्यवस्थापन गर्नुहोस्</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Profile Info Card */}
            <Card className="md:col-span-1">
              <CardHeader className="text-center">
                <div className="flex justify-center mb-4">
                  <Avatar className="h-24 w-24 border-2 border-primary">
                    <AvatarImage src={photoPreview || undefined} />
                    <AvatarFallback className="bg-primary text-white text-2xl">
                      {user.name.charAt(0).toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                </div>
                <CardTitle>{user.name}</CardTitle>
                <CardDescription>{user.role === 'admin' ? 'प्रशासक' : 'कर्मचारी'}</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center">
                    <User className="h-4 w-4 mr-2 text-neutral-500" />
                    <span className="text-sm">{user.username}</span>
                  </div>
                  <div className="flex items-center">
                    <Mail className="h-4 w-4 mr-2 text-neutral-500" />
                    <span className="text-sm">{user.email}</span>
                  </div>
                  {user.phone && (
                    <div className="flex items-center">
                      <Phone className="h-4 w-4 mr-2 text-neutral-500" />
                      <span className="text-sm">{user.phone}</span>
                    </div>
                  )}
                  {user.address && (
                    <div className="flex items-center">
                      <MapPin className="h-4 w-4 mr-2 text-neutral-500" />
                      <span className="text-sm">{user.address}</span>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
            
            {/* Edit Profile Form */}
            <Card className="md:col-span-2">
              <CardHeader>
                <CardTitle>प्रोफाइल सम्पादन</CardTitle>
                <CardDescription>
                  तपाईंको व्यक्तिगत जानकारी अपडेट गर्नुहोस्
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                    <div className="space-y-4">
                      <div className="border rounded-md p-4 text-center">
                        <FormLabel className="block mb-2">प्रोफाइल फोटो</FormLabel>
                        {photoPreview ? (
                          <div className="relative inline-block">
                            <img 
                              src={photoPreview} 
                              alt="Profile" 
                              className="h-32 w-32 rounded-full object-cover mx-auto" 
                            />
                            <Input 
                              type="file" 
                              accept="image/*" 
                              className="sr-only" 
                              id="photo-upload"
                              onChange={handlePhotoChange}
                            />
                            <Button 
                              type="button" 
                              variant="outline" 
                              size="icon"
                              className="absolute bottom-0 right-0 rounded-full h-8 w-8"
                              onClick={() => document.getElementById('photo-upload')?.click()}
                            >
                              <Camera className="h-4 w-4" />
                            </Button>
                          </div>
                        ) : (
                          <div className="text-center">
                            <Input 
                              type="file" 
                              accept="image/*" 
                              className="sr-only" 
                              id="photo-upload"
                              onChange={handlePhotoChange}
                            />
                            <Button 
                              type="button" 
                              variant="outline" 
                              onClick={() => document.getElementById('photo-upload')?.click()}
                            >
                              <Camera className="h-4 w-4 mr-2" /> फोटो अपलोड
                            </Button>
                          </div>
                        )}
                      </div>
                      
                      <FormField
                        control={form.control}
                        name="name"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>पूरा नाम</FormLabel>
                            <FormControl>
                              <Input placeholder="पूरा नाम" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="email"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>इमेल ठेगाना</FormLabel>
                            <FormControl>
                              <Input placeholder="इमेल ठेगाना" type="email" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <FormField
                          control={form.control}
                          name="phone"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>फोन नम्बर</FormLabel>
                              <FormControl>
                                <Input placeholder="फोन नम्बर" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="address"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>ठेगाना</FormLabel>
                              <FormControl>
                                <Input placeholder="ठेगाना" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                    </div>
                    
                    <Separator />
                    
                    <Button 
                      type="submit" 
                      disabled={updateProfileMutation.isPending}
                      className="w-full md:w-auto"
                    >
                      {updateProfileMutation.isPending ? 'प्रगतिमा...' : 'प्रोफाइल अपडेट गर्नुहोस्'}
                    </Button>
                  </form>
                </Form>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
