import React, { useState } from 'react';
import { Header } from '@/components/layout/header';
import { Sidebar } from '@/components/layout/sidebar';
import { useAuth } from '@/hooks/use-auth';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { format } from 'date-fns';
import { LeaveForm } from '@/components/leave/leave-form';
import { Calendar, CalendarOff, Clock } from 'lucide-react';

export default function LeaveManagement() {
  const { user } = useAuth();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isLeaveFormOpen, setIsLeaveFormOpen] = useState(false);
  const [activeTab, setActiveTab] = useState('all');
  
  const toggleMobileMenu = () => setIsMobileMenuOpen(!isMobileMenuOpen);
  
  // Fetch leaves
  const { data: leaves = [] } = useQuery({
    queryKey: ['/api/leave'],
    enabled: !!user,
  });
  
  // Filter leaves by status
  const pendingLeaves = leaves.filter((leave: any) => leave.status === 'pending');
  const approvedLeaves = leaves.filter((leave: any) => leave.status === 'approved');
  const rejectedLeaves = leaves.filter((leave: any) => leave.status === 'rejected');
  
  // Calculate leave statistics
  const totalLeaveAllocation = 18; // Example: 18 days per year
  const usedLeaves = approvedLeaves.reduce((total: number, leave: any) => {
    const start = new Date(leave.startDate);
    const end = new Date(leave.endDate);
    const days = Math.ceil((end.getTime() - start.getTime()) / (1000 * 60 * 60 * 24)) + 1;
    return total + days;
  }, 0);
  
  const remainingLeaves = totalLeaveAllocation - usedLeaves;
  
  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'pending':
        return <Badge variant="outline" className="bg-yellow-100 text-yellow-800">विचाराधीन</Badge>;
      case 'approved':
        return <Badge variant="outline" className="bg-green-100 text-green-800">स्वीकृत</Badge>;
      case 'rejected':
        return <Badge variant="outline" className="bg-red-100 text-red-800">अस्वीकृत</Badge>;
      default:
        return null;
    }
  };
  
  const renderLeaveList = (leaveList: any[]) => {
    if (leaveList.length === 0) {
      return (
        <div className="text-center py-8 text-neutral-400">
          <CalendarOff className="h-12 w-12 mx-auto mb-2 text-neutral-300" />
          <p>बिदा रेकर्ड फेला परेन</p>
        </div>
      );
    }
    
    return (
      <div className="space-y-4">
        {leaveList.map((leave: any) => (
          <Card key={leave.id} className="overflow-hidden">
            <CardContent className="p-4">
              <div className="flex justify-between items-start">
                <div>
                  <div className="flex items-center mb-1">
                    <Calendar className="h-4 w-4 mr-2 text-primary" />
                    <h3 className="font-medium">{leave.type === 'sick' ? 'बिरामी बिदा' : leave.type === 'personal' ? 'व्यक्तिगत बिदा' : 'वार्षिक बिदा'}</h3>
                  </div>
                  <p className="text-sm">
                    <span className="font-medium">बिदा मिति:</span> {format(new Date(leave.startDate), 'yyyy/MM/dd')} - {format(new Date(leave.endDate), 'yyyy/MM/dd')}
                  </p>
                  <p className="text-sm text-neutral-500 mt-1">{leave.reason}</p>
                  <p className="text-xs text-neutral-400 mt-2">
                    <Clock className="h-3 w-3 inline mr-1" />
                    पेश गरिएको: {format(new Date(leave.createdAt), 'yyyy/MM/dd h:mm a')}
                  </p>
                </div>
                {getStatusBadge(leave.status)}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  };
  
  return (
    <div className="min-h-screen flex flex-col">
      <Header onMenuToggle={toggleMobileMenu} />
      
      <div className="flex flex-1">
        <Sidebar isMobileOpen={isMobileMenuOpen} onClose={() => setIsMobileMenuOpen(false)} />
        
        <div className="flex-1 md:ml-64 p-4">
          <div className="flex justify-between items-center mb-6">
            <div>
              <h2 className="text-2xl font-medium text-neutral-500">बिदा व्यवस्थापन</h2>
              <p className="text-neutral-400">तपाईंको बिदा अनुरोधहरू व्यवस्थापन गर्नुहोस्</p>
            </div>
            <Button onClick={() => setIsLeaveFormOpen(true)}>
              नयाँ बिदा अनुरोध
            </Button>
          </div>
          
          {/* Leave Statistics */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            <Card>
              <CardContent className="p-4 flex flex-col items-center justify-center">
                <div className="h-16 w-16 rounded-full bg-green-100 flex items-center justify-center mb-2">
                  <span className="text-2xl font-bold text-green-700">{remainingLeaves}</span>
                </div>
                <p className="text-center font-medium">बाँकी बिदा दिनहरू</p>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-4 flex flex-col items-center justify-center">
                <div className="h-16 w-16 rounded-full bg-blue-100 flex items-center justify-center mb-2">
                  <span className="text-2xl font-bold text-blue-700">{usedLeaves}</span>
                </div>
                <p className="text-center font-medium">प्रयोग गरिएको बिदा</p>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-4 flex flex-col items-center justify-center">
                <div className="h-16 w-16 rounded-full bg-yellow-100 flex items-center justify-center mb-2">
                  <span className="text-2xl font-bold text-yellow-700">{pendingLeaves.length}</span>
                </div>
                <p className="text-center font-medium">विचाराधीन बिदा अनुरोध</p>
              </CardContent>
            </Card>
          </div>
          
          {/* Leave Applications */}
          <Card>
            <Tabs value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="w-full grid grid-cols-4">
                <TabsTrigger value="all">सबै</TabsTrigger>
                <TabsTrigger value="pending">विचाराधीन</TabsTrigger>
                <TabsTrigger value="approved">स्वीकृत</TabsTrigger>
                <TabsTrigger value="rejected">अस्वीकृत</TabsTrigger>
              </TabsList>
              
              <div className="p-4">
                <TabsContent value="all" className="mt-0">
                  {renderLeaveList(leaves)}
                </TabsContent>
                
                <TabsContent value="pending" className="mt-0">
                  {renderLeaveList(pendingLeaves)}
                </TabsContent>
                
                <TabsContent value="approved" className="mt-0">
                  {renderLeaveList(approvedLeaves)}
                </TabsContent>
                
                <TabsContent value="rejected" className="mt-0">
                  {renderLeaveList(rejectedLeaves)}
                </TabsContent>
              </div>
            </Tabs>
          </Card>
          
          {/* Leave Application Form */}
          {isLeaveFormOpen && (
            <LeaveForm 
              isOpen={isLeaveFormOpen} 
              onClose={() => setIsLeaveFormOpen(false)} 
            />
          )}
        </div>
      </div>
    </div>
  );
}
