import React, { useState, useEffect } from 'react';
import { Header } from '@/components/layout/header';
import { Sidebar } from '@/components/layout/sidebar';
import { useAuth } from '@/hooks/use-auth';
import { useQrCode } from '@/hooks/use-qr-code';
import { useQuery, useMutation } from '@tanstack/react-query';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { QrScanner } from '@/components/attendance/qr-scanner';
import { Calendar } from '@/components/ui/calendar';
import { format } from 'date-fns';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useToast } from '@/hooks/use-toast';
import { 
  QrCode, 
  LogIn, 
  LogOut, 
  Calendar as CalendarIcon, 
  Clock, 
  MapPin
} from 'lucide-react';

export default function Attendance() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [showQrScanner, setShowQrScanner] = useState(false);
  const [activeTab, setActiveTab] = useState('qr');
  const [date, setDate] = useState<Date>(new Date());
  
  const { qrDataUrl: checkinQrUrl, qrCode: checkinCode } = useQrCode('check_in');
  const { qrDataUrl: checkoutQrUrl, qrCode: checkoutCode } = useQrCode('check_out');
  
  const toggleMobileMenu = () => setIsMobileMenuOpen(!isMobileMenuOpen);
  
  // Fetch all attendance records
  const { data: allAttendance = [] } = useQuery({
    queryKey: ['/api/attendance'],
    enabled: !!user,
  });
  
  // Fetch today's attendance
  const { data: todayAttendance = [] } = useQuery({
    queryKey: ['/api/attendance/today'],
    enabled: !!user,
  });
  
  const hasCheckedIn = todayAttendance.some((a: any) => a.type === 'check_in');
  const hasCheckedOut = todayAttendance.some((a: any) => a.type === 'check_out');
  
  // Record attendance mutation
  const recordAttendanceMutation = useMutation({
    mutationFn: async ({ type, qrCode }: { type: string, qrCode: string }) => {
      // Get current location
      const position = await new Promise<GeolocationPosition>((resolve, reject) => {
        navigator.geolocation.getCurrentPosition(resolve, reject);
      });
      
      const geoLocation = `${position.coords.latitude},${position.coords.longitude}`;
      
      const res = await apiRequest("POST", "/api/attendance", {
        type,
        qrCode,
        geoLocation
      });
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/attendance/today'] });
      queryClient.invalidateQueries({ queryKey: ['/api/attendance'] });
      toast({
        title: 'हाजिरी सफल',
        description: 'तपाईंको हाजिरी सफलतापूर्वक दर्ता भयो।',
      });
      setShowQrScanner(false);
    },
    onError: (error: Error) => {
      toast({
        title: 'हाजिरी असफल',
        description: error.message,
        variant: 'destructive',
      });
    },
  });
  
  const handleAttendance = async (type: 'check_in' | 'check_out') => {
    if (!navigator.geolocation) {
      toast({
        title: 'त्रुटि',
        description: 'तपाईंको ब्राउजरले जियोलोकेशन सपोर्ट गर्दैन।',
        variant: 'destructive',
      });
      return;
    }
    
    try {
      const qrCode = type === 'check_in' ? checkinCode : checkoutCode;
      if (!qrCode) {
        throw new Error('QR कोड पाउन सकिएन, पुन: प्रयास गर्नुहोस्।');
      }
      
      await recordAttendanceMutation.mutateAsync({ type, qrCode });
    } catch (error) {
      console.error("Attendance error:", error);
    }
  };
  
  const handleQrCodeScanned = async (scannedCode: string) => {
    try {
      if (scannedCode === checkinCode && !hasCheckedIn) {
        await recordAttendanceMutation.mutateAsync({ type: 'check_in', qrCode: scannedCode });
      } else if (scannedCode === checkoutCode && hasCheckedIn && !hasCheckedOut) {
        await recordAttendanceMutation.mutateAsync({ type: 'check_out', qrCode: scannedCode });
      } else {
        toast({
          title: 'अमान्य QR कोड',
          description: 'स्क्यान गरिएको QR कोड अमान्य छ वा पहिले नै प्रयोग गरिएको छ।',
          variant: 'destructive',
        });
      }
    } catch (error) {
      console.error("QR scan error:", error);
    }
  };
  
  // Group attendance by date for history view
  const attendanceByDate = allAttendance.reduce((acc: any, record: any) => {
    const dateKey = format(new Date(record.timestamp), 'yyyy-MM-dd');
    if (!acc[dateKey]) {
      acc[dateKey] = [];
    }
    acc[dateKey].push(record);
    return acc;
  }, {});
  
  // Get date keys in descending order
  const dateKeys = Object.keys(attendanceByDate).sort((a, b) => {
    return new Date(b).getTime() - new Date(a).getTime();
  });
  
  // Filter attendance records for selected date
  const selectedDateStr = format(date, 'yyyy-MM-dd');
  const selectedDateAttendance = attendanceByDate[selectedDateStr] || [];
  
  return (
    <div className="min-h-screen flex flex-col">
      <Header onMenuToggle={toggleMobileMenu} />
      
      <div className="flex flex-1">
        <Sidebar isMobileOpen={isMobileMenuOpen} onClose={() => setIsMobileMenuOpen(false)} />
        
        <div className="flex-1 md:ml-64 p-4">
          <div className="mb-6">
            <h2 className="text-2xl font-medium text-neutral-500">हाजिरी</h2>
            <p className="text-neutral-400">तपाईंको हाजिरी रेकर्ड र चेक-इन/चेक-आउट</p>
          </div>
          
          <Tabs value={activeTab} onValueChange={setActiveTab} className="mb-6">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="qr">QR कोड हाजिरी</TabsTrigger>
              <TabsTrigger value="history">हाजिरी इतिहास</TabsTrigger>
            </TabsList>
            
            <TabsContent value="qr" className="mt-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* QR Code Card */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <QrCode className="mr-2 h-5 w-5" /> QR कोड हाजिरी
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="mb-4">
                      <div className="h-64 w-full flex items-center justify-center border rounded bg-gray-50">
                        {showQrScanner ? (
                          <QrScanner 
                            onScan={handleQrCodeScanned} 
                            onClose={() => setShowQrScanner(false)}
                          />
                        ) : (
                          <div className="text-center p-4">
                            <QrCode className="h-12 w-12 mx-auto mb-2 text-primary" />
                            <h3 className="font-medium mb-2">QR कोड स्क्यान गर्नुहोस्</h3>
                            <p className="text-sm text-neutral-500 mb-4">
                              चेक-इन वा चेक-आउट गर्न QR कोड स्क्यान गर्नुहोस्
                            </p>
                            <Button onClick={() => setShowQrScanner(true)}>
                              QR स्क्यानर खोल्नुहोस्
                            </Button>
                          </div>
                        )}
                      </div>
                    </div>
                    
                    <div className="flex gap-2">
                      <Button 
                        className="flex-1" 
                        disabled={hasCheckedIn || recordAttendanceMutation.isPending} 
                        onClick={() => handleAttendance('check_in')}
                      >
                        <LogIn className="mr-2 h-4 w-4" /> चेक-इन
                      </Button>
                      <Button 
                        className="flex-1" 
                        variant={hasCheckedIn ? "default" : "secondary"} 
                        disabled={!hasCheckedIn || hasCheckedOut || recordAttendanceMutation.isPending}
                        onClick={() => handleAttendance('check_out')}
                      >
                        <LogOut className="mr-2 h-4 w-4" /> चेक-आउट
                      </Button>
                    </div>
                  </CardContent>
                </Card>
                
                {/* Today's Attendance Status */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <Clock className="mr-2 h-5 w-5" /> आजको हाजिरी स्थिति
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    {todayAttendance.length === 0 ? (
                      <div className="text-center py-8">
                        <p className="text-neutral-400">आज हाजिरी रेकर्ड छैन</p>
                      </div>
                    ) : (
                      <div className="space-y-6">
                        {todayAttendance.map((record: any) => (
                          <div key={record.id} className="border p-4 rounded-lg">
                            <div className="flex items-center mb-2">
                              {record.type === 'check_in' ? (
                                <LogIn className="mr-2 h-5 w-5 text-green-600" />
                              ) : (
                                <LogOut className="mr-2 h-5 w-5 text-blue-600" />
                              )}
                              <h3 className="font-medium">
                                {record.type === 'check_in' ? 'चेक-इन' : 'चेक-आउट'}
                              </h3>
                            </div>
                            <div className="grid grid-cols-2 gap-2 text-sm">
                              <div>
                                <p className="text-neutral-500">समय</p>
                                <p className="font-medium">
                                  {format(new Date(record.timestamp), 'h:mm a')}
                                </p>
                              </div>
                              <div>
                                <p className="text-neutral-500">मिति</p>
                                <p className="font-medium">
                                  {format(new Date(record.timestamp), 'yyyy/MM/dd')}
                                </p>
                              </div>
                              {record.geoLocation && (
                                <div className="col-span-2 mt-2">
                                  <p className="text-neutral-500 flex items-center">
                                    <MapPin className="h-3 w-3 mr-1" /> स्थान
                                  </p>
                                  <p className="font-medium text-xs">
                                    {record.geoLocation}
                                  </p>
                                </div>
                              )}
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
            
            <TabsContent value="history" className="mt-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <Card className="md:col-span-1">
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <CalendarIcon className="mr-2 h-5 w-5" /> मिति छान्नुहोस्
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <Calendar
                      mode="single"
                      selected={date}
                      onSelect={(date) => date && setDate(date)}
                      className="rounded-md border"
                      disabled={(date) => {
                        return !dateKeys.includes(format(date, 'yyyy-MM-dd'));
                      }}
                      initialFocus
                    />
                  </CardContent>
                </Card>
                
                <Card className="md:col-span-2">
                  <CardHeader>
                    <CardTitle>
                      {format(date, 'yyyy/MM/dd')} को हाजिरी विवरण
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    {selectedDateAttendance.length === 0 ? (
                      <div className="text-center py-8">
                        <p className="text-neutral-400">छानिएको मितिमा हाजिरी रेकर्ड छैन</p>
                      </div>
                    ) : (
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>प्रकार</TableHead>
                            <TableHead>समय</TableHead>
                            <TableHead>स्थान</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {selectedDateAttendance.map((record: any) => (
                            <TableRow key={record.id}>
                              <TableCell className="font-medium">
                                <div className="flex items-center">
                                  {record.type === 'check_in' ? (
                                    <LogIn className="mr-2 h-4 w-4 text-green-600" />
                                  ) : (
                                    <LogOut className="mr-2 h-4 w-4 text-blue-600" />
                                  )}
                                  {record.type === 'check_in' ? 'चेक-इन' : 'चेक-आउट'}
                                </div>
                              </TableCell>
                              <TableCell>
                                {format(new Date(record.timestamp), 'h:mm:ss a')}
                              </TableCell>
                              <TableCell className="text-xs">
                                {record.geoLocation || '-'}
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    )}
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}
