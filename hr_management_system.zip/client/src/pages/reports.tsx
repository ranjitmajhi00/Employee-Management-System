import React, { useState } from 'react';
import { Header } from '@/components/layout/header';
import { Sidebar } from '@/components/layout/sidebar';
import { useAuth } from '@/hooks/use-auth';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { PerformanceChart } from '@/components/dashboard/performance-chart';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { format } from 'date-fns';
import { 
  BarChart, 
  Calendar, 
  Download, 
  FileText, 
  PieChart, 
  Clock,
  CheckCircle2
} from 'lucide-react';

export default function Reports() {
  const { user } = useAuth();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [activeTab, setActiveTab] = useState('performance');
  
  const toggleMobileMenu = () => setIsMobileMenuOpen(!isMobileMenuOpen);
  
  // Fetch evaluation data
  const { data: evaluations = [] } = useQuery({
    queryKey: [`/api/evaluation/user/${user?.id}`],
    enabled: !!user,
  });
  
  // Fetch attendance records
  const { data: attendance = [] } = useQuery({
    queryKey: ['/api/attendance'],
    enabled: !!user,
  });
  
  // Fetch tasks
  const { data: tasks = [] } = useQuery({
    queryKey: ['/api/tasks/user'],
    enabled: !!user,
  });
  
  // Fetch leave records
  const { data: leaves = [] } = useQuery({
    queryKey: ['/api/leave'],
    enabled: !!user,
  });
  
  // Calculate statistics
  const completedTasks = tasks.filter((task: any) => task.status === 'completed').length;
  const totalTasks = tasks.length;
  const completionRate = totalTasks > 0 ? (completedTasks / totalTasks) * 100 : 0;
  
  const checkIns = attendance.filter((record: any) => record.type === 'check_in').length;
  const checkOuts = attendance.filter((record: any) => record.type === 'check_out').length;
  
  const approvedLeaves = leaves.filter((leave: any) => leave.status === 'approved').length;
  const rejectedLeaves = leaves.filter((leave: any) => leave.status === 'rejected').length;
  const pendingLeaves = leaves.filter((leave: any) => leave.status === 'pending').length;
  
  // Sort evaluations by date (newest first)
  const sortedEvaluations = [...evaluations].sort((a: any, b: any) => 
    new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
  );
  
  // Prepare performance data for chart
  const performanceChartData = evaluations.map((evalItem: any) => ({
    month: `${evalItem.month}/${evalItem.year}`,
    taskCompletion: evalItem.taskCompletion,
    timeliness: evalItem.timeliness,
    quality: evalItem.quality,
    overall: evalItem.overallScore,
  }));
  
  return (
    <div className="min-h-screen flex flex-col">
      <Header onMenuToggle={toggleMobileMenu} />
      
      <div className="flex flex-1">
        <Sidebar isMobileOpen={isMobileMenuOpen} onClose={() => setIsMobileMenuOpen(false)} />
        
        <div className="flex-1 md:ml-64 p-4">
          <div className="flex justify-between items-center mb-6">
            <div>
              <h2 className="text-2xl font-medium text-neutral-500">रिपोर्ट</h2>
              <p className="text-neutral-400">तपाईंको कार्य प्रदर्शन र मूल्यांकन</p>
            </div>
            <Button variant="outline" className="flex items-center gap-2">
              <Download className="h-4 w-4" /> रिपोर्ट डाउनलोड
            </Button>
          </div>
          
          {/* Summary Cards */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
            <Card>
              <CardContent className="p-4 flex flex-col items-center justify-center">
                <div className="h-16 w-16 rounded-full bg-blue-100 flex items-center justify-center mb-2">
                  <CheckCircle2 className="h-8 w-8 text-blue-700" />
                </div>
                <p className="text-center text-neutral-500">कार्य पूरा दर</p>
                <p className="text-center text-2xl font-bold">{completionRate.toFixed(0)}%</p>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-4 flex flex-col items-center justify-center">
                <div className="h-16 w-16 rounded-full bg-green-100 flex items-center justify-center mb-2">
                  <FileText className="h-8 w-8 text-green-700" />
                </div>
                <p className="text-center text-neutral-500">पूरा कार्य</p>
                <p className="text-center text-2xl font-bold">{completedTasks}/{totalTasks}</p>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-4 flex flex-col items-center justify-center">
                <div className="h-16 w-16 rounded-full bg-yellow-100 flex items-center justify-center mb-2">
                  <Clock className="h-8 w-8 text-yellow-700" />
                </div>
                <p className="text-center text-neutral-500">हाजिरी रेकर्ड</p>
                <p className="text-center text-2xl font-bold">{checkIns}</p>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-4 flex flex-col items-center justify-center">
                <div className="h-16 w-16 rounded-full bg-purple-100 flex items-center justify-center mb-2">
                  <Calendar className="h-8 w-8 text-purple-700" />
                </div>
                <p className="text-center text-neutral-500">स्वीकृत बिदा</p>
                <p className="text-center text-2xl font-bold">{approvedLeaves}</p>
              </CardContent>
            </Card>
          </div>
          
          {/* Report Tabs */}
          <Card>
            <Tabs value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="w-full grid grid-cols-3 p-0">
                <TabsTrigger value="performance" className="flex items-center gap-2">
                  <BarChart className="h-4 w-4" /> प्रदर्शन विश्लेषण
                </TabsTrigger>
                <TabsTrigger value="attendance" className="flex items-center gap-2">
                  <Clock className="h-4 w-4" /> हाजिरी विश्लेषण
                </TabsTrigger>
                <TabsTrigger value="leave" className="flex items-center gap-2">
                  <Calendar className="h-4 w-4" /> बिदा विश्लेषण
                </TabsTrigger>
              </TabsList>
              
              <TabsContent value="performance" className="p-4">
                <div className="mb-6">
                  <CardHeader className="px-0 pt-0">
                    <CardTitle className="text-xl">प्रदर्शन विश्लेषण</CardTitle>
                  </CardHeader>
                  
                  {performanceChartData.length > 0 ? (
                    <div className="h-80">
                      <PerformanceChart data={performanceChartData} />
                    </div>
                  ) : (
                    <div className="text-center py-12">
                      <BarChart className="h-12 w-12 mx-auto mb-2 text-neutral-300" />
                      <p className="text-neutral-500">प्रदर्शन डाटा उपलब्ध छैन</p>
                    </div>
                  )}
                </div>
                
                <CardHeader className="px-0 py-2">
                  <CardTitle className="text-lg">मूल्यांकन इतिहास</CardTitle>
                </CardHeader>
                
                {sortedEvaluations.length > 0 ? (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>मिति</TableHead>
                        <TableHead>महिना/वर्ष</TableHead>
                        <TableHead className="text-right">कार्य पूरा</TableHead>
                        <TableHead className="text-right">समय पालना</TableHead>
                        <TableHead className="text-right">गुणस्तर</TableHead>
                        <TableHead className="text-right">समग्र स्कोर</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {sortedEvaluations.map((evalItem: any) => (
                        <TableRow key={evalItem.id}>
                          <TableCell className="font-medium">
                            {format(new Date(evalItem.createdAt), 'yyyy/MM/dd')}
                          </TableCell>
                          <TableCell>{evalItem.month}/{evalItem.year}</TableCell>
                          <TableCell className="text-right">{evalItem.taskCompletion}%</TableCell>
                          <TableCell className="text-right">{evalItem.timeliness}%</TableCell>
                          <TableCell className="text-right">{evalItem.quality}%</TableCell>
                          <TableCell className="text-right font-bold">{evalItem.overallScore}%</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                ) : (
                  <div className="text-center py-8">
                    <p className="text-neutral-500">मूल्यांकन इतिहास उपलब्ध छैन</p>
                  </div>
                )}
              </TabsContent>
              
              <TabsContent value="attendance" className="p-4">
                <div className="mb-6">
                  <CardHeader className="px-0 pt-0">
                    <CardTitle className="text-xl">हाजिरी विश्लेषण</CardTitle>
                  </CardHeader>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                    <Card>
                      <CardContent className="p-4">
                        <div className="mb-2">
                          <p className="text-sm text-neutral-500">जम्मा चेक-इन</p>
                          <p className="text-3xl font-bold">{checkIns}</p>
                        </div>
                        
                        <div className="mt-4">
                          <p className="text-sm text-neutral-500">जम्मा चेक-आउट</p>
                          <p className="text-3xl font-bold">{checkOuts}</p>
                        </div>
                      </CardContent>
                    </Card>
                    
                    <Card>
                      <CardContent className="p-4 flex items-center justify-center">
                        {attendance.length > 0 ? (
                          <div className="text-center">
                            <PieChart className="h-20 w-20 mx-auto" />
                            <p className="text-sm mt-2">हाजिरी विश्लेषण</p>
                          </div>
                        ) : (
                          <div className="text-center py-8">
                            <p className="text-neutral-500">हाजिरी डाटा उपलब्ध छैन</p>
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  </div>
                </div>
                
                <CardHeader className="px-0 py-2">
                  <CardTitle className="text-lg">हाणिरी रेकर्ड</CardTitle>
                </CardHeader>
                
                {attendance.length > 0 ? (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>मिति</TableHead>
                        <TableHead>समय</TableHead>
                        <TableHead>प्रकार</TableHead>
                        <TableHead className="text-right">स्थान</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {attendance.slice(0, 10).map((record: any) => (
                        <TableRow key={record.id}>
                          <TableCell className="font-medium">
                            {format(new Date(record.timestamp), 'yyyy/MM/dd')}
                          </TableCell>
                          <TableCell>{format(new Date(record.timestamp), 'h:mm:ss a')}</TableCell>
                          <TableCell>
                            {record.type === 'check_in' ? 'चेक-इन' : 'चेक-आउट'}
                          </TableCell>
                          <TableCell className="text-right text-xs">
                            {record.geoLocation || '-'}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                ) : (
                  <div className="text-center py-8">
                    <p className="text-neutral-500">हाजिरी रेकर्ड उपलब्ध छैन</p>
                  </div>
                )}
              </TabsContent>
              
              <TabsContent value="leave" className="p-4">
                <div className="mb-6">
                  <CardHeader className="px-0 pt-0">
                    <CardTitle className="text-xl">बिदा विश्लेषण</CardTitle>
                  </CardHeader>
                  
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                    <Card>
                      <CardContent className="p-4 text-center">
                        <p className="text-sm text-neutral-500">स्वीकृत बिदा</p>
                        <p className="text-3xl font-bold text-green-600">{approvedLeaves}</p>
                      </CardContent>
                    </Card>
                    
                    <Card>
                      <CardContent className="p-4 text-center">
                        <p className="text-sm text-neutral-500">अस्वीकृत बिदा</p>
                        <p className="text-3xl font-bold text-red-600">{rejectedLeaves}</p>
                      </CardContent>
                    </Card>
                    
                    <Card>
                      <CardContent className="p-4 text-center">
                        <p className="text-sm text-neutral-500">विचाराधीन बिदा</p>
                        <p className="text-3xl font-bold text-yellow-600">{pendingLeaves}</p>
                      </CardContent>
                    </Card>
                  </div>
                </div>
                
                <CardHeader className="px-0 py-2">
                  <CardTitle className="text-lg">बिदा इतिहास</CardTitle>
                </CardHeader>
                
                {leaves.length > 0 ? (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>प्रकार</TableHead>
                        <TableHead>मिति</TableHead>
                        <TableHead>कारण</TableHead>
                        <TableHead className="text-right">स्थिति</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {leaves.map((leave: any) => (
                        <TableRow key={leave.id}>
                          <TableCell className="font-medium">
                            {leave.type === 'sick' ? 'बिरामी बिदा' : 
                             leave.type === 'personal' ? 'व्यक्तिगत बिदा' : 'वार्षिक बिदा'}
                          </TableCell>
                          <TableCell>
                            {format(new Date(leave.startDate), 'yyyy/MM/dd')} - {format(new Date(leave.endDate), 'yyyy/MM/dd')}
                          </TableCell>
                          <TableCell className="max-w-[200px] truncate">
                            {leave.reason}
                          </TableCell>
                          <TableCell className="text-right">
                            <span className={`
                              px-2 py-1 rounded-full text-xs font-medium
                              ${leave.status === 'approved' ? 'bg-green-100 text-green-800' : 
                                leave.status === 'rejected' ? 'bg-red-100 text-red-800' : 
                                'bg-yellow-100 text-yellow-800'}
                            `}>
                              {leave.status === 'approved' ? 'स्वीकृत' :
                               leave.status === 'rejected' ? 'अस्वीकृत' : 'विचाराधीन'}
                            </span>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                ) : (
                  <div className="text-center py-8">
                    <p className="text-neutral-500">बिदा रेकर्ड उपलब्ध छैन</p>
                  </div>
                )}
              </TabsContent>
            </Tabs>
          </Card>
        </div>
      </div>
    </div>
  );
}
