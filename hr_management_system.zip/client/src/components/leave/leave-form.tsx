import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { format } from 'date-fns';
import { useMutation } from '@tanstack/react-query';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { Calendar as CalendarIcon, Loader2 } from 'lucide-react';

import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import { Calendar } from '@/components/ui/calendar';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { cn } from '@/lib/utils';

const leaveFormSchema = z.object({
  type: z.enum(['sick', 'personal', 'vacation']),
  reason: z.string().min(5, {
    message: 'कृपया बिदाको कारण विस्तृत रूपमा लेख्नुहोस्',
  }),
  startDate: z.date({
    required_error: 'बिदाको सुरु मिति छान्नुहोस्',
  }),
  endDate: z.date({
    required_error: 'बिदाको अन्त्य मिति छान्नुहोस्',
  }),
}).refine(data => {
  return data.endDate >= data.startDate;
}, {
  message: 'बिदाको अन्त्य मिति सुरु मिति पछि हुनुपर्छ',
  path: ['endDate'],
});

type LeaveFormValues = z.infer<typeof leaveFormSchema>;

interface LeaveFormProps {
  isOpen: boolean;
  onClose: () => void;
}

export function LeaveForm({ isOpen, onClose }: LeaveFormProps) {
  const { toast } = useToast();
  const [startDate, setStartDate] = useState<Date | undefined>(new Date());
  const [endDate, setEndDate] = useState<Date | undefined>(new Date());

  const form = useForm<LeaveFormValues>({
    resolver: zodResolver(leaveFormSchema),
    defaultValues: {
      type: 'personal',
      reason: '',
      startDate: new Date(),
      endDate: new Date(),
    },
  });

  const leaveRequestMutation = useMutation({
    mutationFn: async (data: LeaveFormValues) => {
      const res = await apiRequest("POST", "/api/leave", data);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/leave'] });
      toast({
        title: 'बिदा अनुरोध सफल',
        description: 'तपाईंको बिदा अनुरोध सफलतापूर्वक पेश गरियो।',
      });
      onClose();
      form.reset();
    },
    onError: (error: Error) => {
      toast({
        title: 'बिदा अनुरोध असफल',
        description: error.message,
        variant: 'destructive',
      });
    },
  });

  const onSubmit = (data: LeaveFormValues) => {
    leaveRequestMutation.mutate(data);
  };

  const handleStartDateChange = (date: Date | undefined) => {
    if (date) {
      setStartDate(date);
      form.setValue('startDate', date);
      
      // If end date is before start date, update end date
      const currentEndDate = form.getValues('endDate');
      if (currentEndDate < date) {
        setEndDate(date);
        form.setValue('endDate', date);
      }
    }
  };

  const handleEndDateChange = (date: Date | undefined) => {
    if (date) {
      setEndDate(date);
      form.setValue('endDate', date);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>बिदा अनुरोध फारम</DialogTitle>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <FormField
              control={form.control}
              name="type"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>बिदाको प्रकार</FormLabel>
                  <Select 
                    onValueChange={field.onChange} 
                    defaultValue={field.value}
                  >
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="बिदाको प्रकार छान्नुहोस्" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="sick">बिरामी बिदा</SelectItem>
                      <SelectItem value="personal">व्यक्तिगत बिदा</SelectItem>
                      <SelectItem value="vacation">वार्षिक बिदा</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="startDate"
                render={({ field }) => (
                  <FormItem className="flex flex-col">
                    <FormLabel>सुरु मिति</FormLabel>
                    <Popover>
                      <PopoverTrigger asChild>
                        <FormControl>
                          <Button
                            variant={"outline"}
                            className={cn(
                              "pl-3 text-left font-normal",
                              !field.value && "text-muted-foreground"
                            )}
                          >
                            {field.value ? (
                              format(field.value, "yyyy/MM/dd")
                            ) : (
                              <span>मिति छान्नुहोस्</span>
                            )}
                            <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                          </Button>
                        </FormControl>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar
                          mode="single"
                          selected={startDate}
                          onSelect={handleStartDateChange}
                          disabled={(date) => date < new Date(new Date().setHours(0, 0, 0, 0))}
                          initialFocus
                        />
                      </PopoverContent>
                    </Popover>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="endDate"
                render={({ field }) => (
                  <FormItem className="flex flex-col">
                    <FormLabel>अन्त्य मिति</FormLabel>
                    <Popover>
                      <PopoverTrigger asChild>
                        <FormControl>
                          <Button
                            variant={"outline"}
                            className={cn(
                              "pl-3 text-left font-normal",
                              !field.value && "text-muted-foreground"
                            )}
                          >
                            {field.value ? (
                              format(field.value, "yyyy/MM/dd")
                            ) : (
                              <span>मिति छान्नुहोस्</span>
                            )}
                            <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                          </Button>
                        </FormControl>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar
                          mode="single"
                          selected={endDate}
                          onSelect={handleEndDateChange}
                          disabled={(date) => 
                            date < new Date(new Date().setHours(0, 0, 0, 0)) || 
                            (startDate ? date < startDate : false)
                          }
                          initialFocus
                        />
                      </PopoverContent>
                    </Popover>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <FormField
              control={form.control}
              name="reason"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>बिदाको कारण</FormLabel>
                  <FormControl>
                    <Textarea 
                      placeholder="बिदाको कारण विस्तृत रूपमा लेख्नुहोस्..." 
                      className="min-h-[120px]" 
                      {...field} 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <DialogFooter>
              <Button 
                type="button" 
                variant="outline" 
                onClick={onClose}
              >
                रद्द गर्नुहोस्
              </Button>
              <Button 
                type="submit" 
                disabled={leaveRequestMutation.isPending}
              >
                {leaveRequestMutation.isPending ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    पेश गर्दै...
                  </>
                ) : 'पेश गर्नुहोस्'}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
