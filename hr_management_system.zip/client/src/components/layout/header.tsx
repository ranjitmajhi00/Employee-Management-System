import React, { useState } from 'react';
import { useAuth } from '@/hooks/use-auth';
import { useLanguage } from '@/hooks/use-language';
import { Bell, Menu, ChevronDown, User, Globe } from 'lucide-react';
import { LanguageToggle } from '@/components/language-toggle';
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuSeparator, 
  DropdownMenuTrigger 
} from '@/components/ui/dropdown-menu';
import { Button } from '@/components/ui/button';
import { useQuery } from '@tanstack/react-query';
import { useLocation } from 'wouter';

interface HeaderProps {
  onMenuToggle: () => void;
}

export function Header({ onMenuToggle }: HeaderProps) {
  const { user, logoutMutation } = useAuth();
  const { t } = useLanguage();
  const [_, navigate] = useLocation();
  
  // Fetch notifications
  const { data: notifications = [] } = useQuery({
    queryKey: ['/api/notifications'],
    enabled: !!user,
  });
  
  const unreadNotifications = notifications.filter((n: any) => !n.isRead);

  if (!user) return null;

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  return (
    <header className="bg-primary shadow-md">
      <div className="container mx-auto px-4 py-3 flex justify-between items-center">
        <div className="flex items-center">
          <button 
            onClick={onMenuToggle}
            className="md:hidden text-white mr-2"
          >
            <Menu className="h-6 w-6" />
          </button>
          <h1 className="text-white text-xl font-medium">
            {t('employee_management_system')} {user.role === 'admin' ? `- ${t('admin')}` : ''}
          </h1>
        </div>
        <div className="flex items-center space-x-2">
          <LanguageToggle />
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="hidden md:flex items-center mr-4 text-white hover:bg-primary-dark">
                <Bell className="h-5 w-5 text-white mr-1" />
                {unreadNotifications.length > 0 && (
                  <span className="bg-secondary text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                    {unreadNotifications.length}
                  </span>
                )}
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent className="w-64">
              <h3 className="px-2 py-1.5 text-sm font-medium">{t('notifications')}</h3>
              <DropdownMenuSeparator />
              {notifications.length === 0 ? (
                <p className="px-2 py-2 text-sm text-center text-muted-foreground">{t('no_notifications')}</p>
              ) : (
                notifications.slice(0, 5).map((notification: any) => (
                  <DropdownMenuItem key={notification.id} className="cursor-pointer flex flex-col items-start">
                    <p className="font-medium text-sm">{notification.title}</p>
                    <p className="text-xs text-muted-foreground">{notification.message}</p>
                  </DropdownMenuItem>
                ))
              )}
              {notifications.length > 0 && (
                <>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem className="cursor-pointer text-primary justify-center text-sm">
                    {t('view_all')}
                  </DropdownMenuItem>
                </>
              )}
            </DropdownMenuContent>
          </DropdownMenu>

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="flex items-center text-white hover:bg-primary-dark">
                <div className="h-8 w-8 rounded-full bg-white/30 flex items-center justify-center text-white mr-2">
                  <User className="h-5 w-5" />
                </div>
                <span className="hidden md:block">{user.name}</span>
                <ChevronDown className="h-4 w-4 text-white ml-1" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent>
              <DropdownMenuItem onClick={() => navigate(user.role === 'admin' ? '/admin' : '/')}>
                {t('dashboard')}
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => navigate('/profile')}>
                {t('profile')}
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={handleLogout}>
                {t('logout')}
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </header>
  );
}
