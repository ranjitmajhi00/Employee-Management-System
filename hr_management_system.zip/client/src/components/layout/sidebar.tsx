import React from 'react';
import { Link, useLocation } from 'wouter';
import { useAuth } from '@/hooks/use-auth';
import { cn } from '@/lib/utils';
import {
  LayoutDashboard,
  Clock,
  FileCheck,
  CalendarOff,
  User,
  BarChart3,
  Settings,
  LogOut,
  Users,
  AlertTriangle
} from 'lucide-react';

interface SidebarProps {
  isMobileOpen: boolean;
  onClose: () => void;
}

export function Sidebar({ isMobileOpen, onClose }: SidebarProps) {
  const { user, logoutMutation } = useAuth();
  const [location] = useLocation();

  if (!user) return null;

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  const isAdmin = user.role === 'admin';

  const employeeNavItems = [
    { icon: LayoutDashboard, label: 'ड्यासबोर्ड', path: '/' },
    { icon: Clock, label: 'हाजिरी', path: '/attendance' },
    { icon: FileCheck, label: 'कार्य व्यवस्थापन', path: '/tasks' },
    { icon: CalendarOff, label: 'बिदा व्यवस्थापन', path: '/leave' },
    { icon: User, label: 'प्रोफाइल', path: '/profile' },
    { icon: BarChart3, label: 'रिपोर्ट', path: '/reports' },
  ];

  const adminNavItems = [
    { icon: LayoutDashboard, label: 'ड्यासबोर्ड', path: '/admin' },
    { icon: Users, label: 'कर्मचारी व्यवस्थापन', path: '/admin/employees' },
    { icon: FileCheck, label: 'कार्य व्यवस्थापन', path: '/admin/tasks' },
    { icon: CalendarOff, label: 'बिदा व्यवस्थापन', path: '/admin/leave' },
    { icon: Clock, label: 'हाजिरी व्यवस्थापन', path: '/admin/attendance' },
    { icon: BarChart3, label: 'रिपोर्ट तथा विश्लेषण', path: '/admin/reports' },
    { icon: Settings, label: 'सेटिङ्स', path: '/admin/settings' },
  ];

  const navItems = isAdmin ? adminNavItems : employeeNavItems;

  return (
    <aside
      className={cn(
        "w-64 bg-white shadow-md fixed h-screen z-10 transform transition-transform duration-300 overflow-y-auto",
        isMobileOpen ? "translate-x-0" : "-translate-x-full md:translate-x-0"
      )}
    >
      <div className="p-4">
        <div className="flex items-center gap-2 mb-6">
          <div className="h-10 w-10 rounded-full bg-primary flex items-center justify-center">
            <User className="h-5 w-5 text-white" />
          </div>
          <div>
            <p className="text-sm font-medium">{user.name}</p>
            <p className="text-xs text-neutral-400">{user.role === 'admin' ? 'प्रशासक' : 'कर्मचारी'}</p>
          </div>
        </div>
        
        <nav>
          <ul>
            {navItems.map((item) => (
              <li key={item.path} className="mb-1">
                <Link href={item.path} onClick={onClose}>
                  <a
                    className={cn(
                      "flex items-center p-2 text-neutral-500 rounded hover:bg-neutral-100",
                      location === item.path && "bg-neutral-100"
                    )}
                  >
                    <item.icon className={cn("mr-3 h-5 w-5", location === item.path ? "text-primary" : "")} />
                    <span>{item.label}</span>
                  </a>
                </Link>
              </li>
            ))}
            <li className="mt-4">
              <button 
                onClick={handleLogout}
                className="flex w-full items-center p-2 text-destructive rounded hover:bg-neutral-100"
              >
                <LogOut className="mr-3 h-5 w-5" />
                <span>लग-आउट</span>
              </button>
            </li>
          </ul>
        </nav>
      </div>
    </aside>
  );
}
