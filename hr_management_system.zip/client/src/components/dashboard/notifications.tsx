import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Bell, AlertCircle } from 'lucide-react';
import { useMutation } from '@tanstack/react-query';
import { apiRequest, queryClient } from '@/lib/queryClient';

interface Notification {
  id: number;
  userId: number;
  title: string;
  message: string;
  isRead: boolean;
  createdAt: string;
}

interface NotificationsProps {
  notifications: Notification[];
  onViewAll: () => void;
}

export function Notifications({ notifications, onViewAll }: NotificationsProps) {
  const markAsReadMutation = useMutation({
    mutationFn: async (notificationId: number) => {
      const res = await apiRequest("PATCH", `/api/notifications/${notificationId}/read`, {});
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/notifications'] });
    }
  });

  const handleNotificationClick = (notification: Notification) => {
    if (!notification.isRead) {
      markAsReadMutation.mutate(notification.id);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <Bell className="mr-2 h-5 w-5" /> सूचना तथा जानकारी
        </CardTitle>
      </CardHeader>
      <CardContent>
        <ul className="space-y-3">
          {notifications.length === 0 ? (
            <li className="text-center text-neutral-400 py-4">
              कुनै सूचना छैन
            </li>
          ) : (
            notifications.slice(0, 3).map((notification) => (
              <li 
                key={notification.id} 
                className="flex items-start gap-2 cursor-pointer hover:bg-gray-50 p-2 rounded-md transition-colors"
                onClick={() => handleNotificationClick(notification)}
              >
                <span className={`${notification.isRead ? 'text-gray-400' : 'text-red-500'}`}>
                  <AlertCircle className="h-4 w-4" />
                </span>
                <div>
                  <p className={`text-sm font-medium ${notification.isRead ? 'text-gray-500' : ''}`}>
                    {notification.title}
                  </p>
                  <p className="text-xs text-neutral-300">
                    {notification.message.length > 50 
                      ? `${notification.message.substring(0, 50)}...` 
                      : notification.message}
                  </p>
                </div>
              </li>
            ))
          )}
        </ul>
        
        {notifications.length > 0 && (
          <Button 
            variant="outline" 
            className="w-full mt-4 border-primary text-primary"
            onClick={onViewAll}
          >
            सबै हेर्नुहोस्
          </Button>
        )}
      </CardContent>
    </Card>
  );
}
