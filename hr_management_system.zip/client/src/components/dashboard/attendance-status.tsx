import React from 'react';
import { format } from 'date-fns';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { 
  Clock, 
  LogIn, 
  LogOut, 
  MapPin 
} from 'lucide-react';

interface AttendanceRecord {
  id: number;
  userId: number;
  type: string;
  timestamp: string;
  geoLocation?: string;
  qrCode: string;
}

interface AttendanceStatusProps {
  todayAttendance: AttendanceRecord[];
  hasCheckedIn: boolean;
  hasCheckedOut: boolean;
  onCheckIn: () => void;
  onCheckOut: () => void;
  isLoading: boolean;
}

export function AttendanceStatus({
  todayAttendance,
  hasCheckedIn,
  hasCheckedOut,
  onCheckIn,
  onCheckOut,
  isLoading
}: AttendanceStatusProps) {
  const checkInRecord = todayAttendance.find((a) => a.type === 'check_in');
  const checkOutRecord = todayAttendance.find((a) => a.type === 'check_out');
  
  // Calculate work hours if checked in and out
  let workHours = '-';
  if (checkInRecord && checkOutRecord) {
    const checkInTime = new Date(checkInRecord.timestamp);
    const checkOutTime = new Date(checkOutRecord.timestamp);
    const diffMs = checkOutTime.getTime() - checkInTime.getTime();
    const diffHrs = Math.floor(diffMs / (1000 * 60 * 60));
    const diffMins = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));
    workHours = `${diffHrs} घण्टा ${diffMins} मिनेट`;
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <Clock className="mr-2 h-5 w-5" /> आजको हाजिरी स्थिति
        </CardTitle>
      </CardHeader>
      <CardContent>
        {todayAttendance.length === 0 ? (
          <div className="text-center py-8">
            <p className="text-neutral-400">आज हाजिरी रेकर्ड छैन</p>
            
            <Button 
              className="mt-4"
              disabled={isLoading}
              onClick={onCheckIn}
            >
              <LogIn className="mr-2 h-4 w-4" /> चेक-इन गर्नुहोस्
            </Button>
          </div>
        ) : (
          <div className="space-y-6">
            {todayAttendance.map((record) => (
              <div key={record.id} className="border p-4 rounded-lg">
                <div className="flex items-center mb-2">
                  {record.type === 'check_in' ? (
                    <LogIn className="mr-2 h-5 w-5 text-green-600" />
                  ) : (
                    <LogOut className="mr-2 h-5 w-5 text-blue-600" />
                  )}
                  <h3 className="font-medium">
                    {record.type === 'check_in' ? 'चेक-इन' : 'चेक-आउट'}
                  </h3>
                </div>
                <div className="grid grid-cols-2 gap-2 text-sm">
                  <div>
                    <p className="text-neutral-500">समय</p>
                    <p className="font-medium">
                      {format(new Date(record.timestamp), 'h:mm a')}
                    </p>
                  </div>
                  <div>
                    <p className="text-neutral-500">मिति</p>
                    <p className="font-medium">
                      {format(new Date(record.timestamp), 'yyyy/MM/dd')}
                    </p>
                  </div>
                  {record.geoLocation && (
                    <div className="col-span-2 mt-2">
                      <p className="text-neutral-500 flex items-center">
                        <MapPin className="h-3 w-3 mr-1" /> स्थान
                      </p>
                      <p className="font-medium text-xs">
                        {record.geoLocation}
                      </p>
                    </div>
                  )}
                </div>
              </div>
            ))}

            {/* Show check-out button if checked in but not checked out */}
            {hasCheckedIn && !hasCheckedOut && (
              <Button
                className="w-full"
                disabled={isLoading}
                onClick={onCheckOut}
              >
                <LogOut className="mr-2 h-4 w-4" /> चेक-आउट गर्नुहोस्
              </Button>
            )}

            {/* Additional status information */}
            {hasCheckedIn && (
              <div className="text-sm border-t pt-4">
                <p>
                  <span className="font-medium">कार्य समय:</span>{' '}
                  <span>{workHours}</span>
                </p>
                <p>
                  <span className="font-medium">स्थिति:</span>{' '}
                  {hasCheckedOut ? (
                    <span className="text-blue-600">कार्य समाप्त</span>
                  ) : (
                    <span className="text-green-600">कार्य जारी</span>
                  )}
                </p>
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
