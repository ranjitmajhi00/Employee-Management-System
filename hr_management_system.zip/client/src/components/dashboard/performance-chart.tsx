import React, { useMemo } from 'react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  TooltipProps
} from 'recharts';
import { 
  NameType, 
  ValueType 
} from 'recharts/types/component/DefaultTooltipContent';

interface PerformanceData {
  month: string;
  taskCompletion: number;
  timeliness: number;
  quality: number;
  overall: number;
}

interface PerformanceChartProps {
  data: PerformanceData[];
}

export function PerformanceChart({ data }: PerformanceChartProps) {
  // Sort data by month chronologically
  const sortedData = useMemo(() => {
    return [...data].sort((a, b) => {
      const [aMonth, aYear] = a.month.split('/').map(Number);
      const [bMonth, bYear] = b.month.split('/').map(Number);
      
      if (aYear !== bYear) return aYear - bYear;
      return aMonth - bMonth;
    });
  }, [data]);

  const CustomTooltip = ({ 
    active, 
    payload, 
    label 
  }: TooltipProps<ValueType, NameType>) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white p-4 border rounded shadow-md">
          <p className="font-bold mb-1">{label}</p>
          {payload.map((entry, index) => (
            <div key={`tooltip-${index}`} className="flex items-center gap-2 text-sm">
              <div 
                className="h-3 w-3 rounded-full" 
                style={{ backgroundColor: entry.color }}
              />
              <span>
                {entry.name === 'taskCompletion' && 'कार्य पूरा: '}
                {entry.name === 'timeliness' && 'समय पालना: '}
                {entry.name === 'quality' && 'गुणस्तर: '}
                {entry.name === 'overall' && 'समग्र स्कोर: '}
                {entry.value}%
              </span>
            </div>
          ))}
        </div>
      );
    }
  
    return null;
  };

  return (
    <ResponsiveContainer width="100%" height="100%">
      <BarChart
        data={sortedData}
        margin={{
          top: 5,
          right: 30,
          left: 20,
          bottom: 5,
        }}
        barSize={20}
      >
        <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
        <XAxis 
          dataKey="month" 
          tickLine={false}
          axisLine={{ stroke: '#e5e7eb' }}
        />
        <YAxis 
          domain={[0, 100]} 
          tickLine={false}
          axisLine={{ stroke: '#e5e7eb' }}
          tickFormatter={(value) => `${value}%`}
        />
        <Tooltip content={<CustomTooltip />} />
        <Legend 
          formatter={(value) => {
            switch (value) {
              case 'taskCompletion': return 'कार्य पूरा';
              case 'timeliness': return 'समय पालना';
              case 'quality': return 'गुणस्तर';
              case 'overall': return 'समग्र स्कोर';
              default: return value;
            }
          }}
        />
        <Bar dataKey="taskCompletion" fill="#10b981" radius={[4, 4, 0, 0]} />
        <Bar dataKey="timeliness" fill="#f59e0b" radius={[4, 4, 0, 0]} />
        <Bar dataKey="quality" fill="#3b82f6" radius={[4, 4, 0, 0]} />
        <Bar dataKey="overall" fill="#1976d2" radius={[4, 4, 0, 0]} />
      </BarChart>
    </ResponsiveContainer>
  );
}
