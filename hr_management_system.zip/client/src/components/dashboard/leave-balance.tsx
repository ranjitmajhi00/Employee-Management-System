import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { CalendarOff } from 'lucide-react';

interface LeaveBalanceProps {
  remainingLeaves: number;
  usedLeaves: number;
  pendingLeaves: number;
  onApplyLeave: () => void;
}

export function LeaveBalance({
  remainingLeaves,
  usedLeaves,
  pendingLeaves,
  onApplyLeave
}: LeaveBalanceProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <CalendarOff className="mr-2 h-5 w-5" /> बिदा ब्यालेन्स
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 gap-2 mb-4">
          <div className="bg-neutral-100 rounded p-3 text-center">
            <p className="text-2xl font-medium text-primary">{remainingLeaves}</p>
            <p className="text-sm">बाँकी दिन</p>
          </div>
          <div className="bg-neutral-100 rounded p-3 text-center">
            <p className="text-2xl font-medium text-neutral-400">{usedLeaves}</p>
            <p className="text-sm">प्रयोग गरिएको</p>
          </div>
        </div>
        
        <Button 
          variant="secondary" 
          className="w-full bg-primary-light text-white mb-2"
          onClick={onApplyLeave}
        >
          बिदाको लागि आवेदन दिनुहोस्
        </Button>
        
        <div className="text-sm">
          <p>
            <span className="font-medium">पेन्डिंग बिदा:</span> <span>{pendingLeaves} दिन</span>
          </p>
          <p>
            <span className="font-medium">वार्षिक छुट्टी:</span> <span>18 दिन</span>
          </p>
        </div>
      </CardContent>
    </Card>
  );
}
