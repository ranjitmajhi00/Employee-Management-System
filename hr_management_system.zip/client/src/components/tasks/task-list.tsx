import React from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { useAuth } from '@/hooks/use-auth';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Clock, RefreshCw, Upload, CheckCircle2 } from 'lucide-react';
import { format } from 'date-fns';
import { useToast } from '@/hooks/use-toast';

interface TaskListProps {
  type: 'daily' | 'monthly' | 'emergency';
  onTaskSelect: (task: any) => void;
}

export function TaskList({ type, onTaskSelect }: TaskListProps) {
  const { user } = useAuth();
  const { toast } = useToast();
  
  const { 
    data: tasks = [], 
    isLoading,
    refetch
  } = useQuery({
    queryKey: [`/api/tasks/type/${type}`],
    enabled: !!user,
  });
  
  const completeTaskMutation = useMutation({
    mutationFn: async (taskId: number) => {
      const res = await apiRequest("PATCH", `/api/tasks/${taskId}`, {
        status: 'completed',
      });
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/tasks/type/${type}`] });
      toast({
        title: 'कार्य सम्पन्न',
        description: 'तपाईंको कार्य सफलतापूर्वक सम्पन्न भयो।',
      });
    },
    onError: (error: Error) => {
      toast({
        title: 'त्रुटि',
        description: error.message,
        variant: 'destructive',
      });
    },
  });
  
  const handleComplete = (taskId: number) => {
    completeTaskMutation.mutate(taskId);
  };
  
  if (isLoading) {
    return <div className="text-center py-8">कार्य लोड हुँदैछ...</div>;
  }
  
  if (tasks.length === 0) {
    return (
      <div className="text-center py-8 text-neutral-400">
        <p>कुनै {type === 'daily' ? 'दैनिक' : type === 'monthly' ? 'मासिक' : 'आकस्मिक'} कार्य छैन</p>
      </div>
    );
  }
  
  const pendingTasks = tasks.filter((task: any) => task.status !== 'completed');
  const completedTasks = tasks.filter((task: any) => task.status === 'completed');
  
  return (
    <div>
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-lg font-medium">
          {type === 'daily' ? 'दैनिक' : type === 'monthly' ? 'मासिक' : 'आकस्मिक'} कार्य
        </h3>
        <Button 
          variant="ghost" 
          className="text-primary text-sm" 
          onClick={() => refetch()}
        >
          <RefreshCw className="h-4 w-4 mr-1" /> रिफ्रेस गर्नुहोस्
        </Button>
      </div>
      
      {pendingTasks.length > 0 && (
        <>
          <h4 className="text-sm font-medium mb-2">बाँकी कार्य</h4>
          {pendingTasks.map((task: any) => (
            <div key={task.id} className="border-b pb-4 mb-4 last:border-0 last:mb-0 last:pb-0">
              <div className="flex justify-between items-start">
                <div>
                  <h4 className="font-medium">{task.title}</h4>
                  <p className="text-sm text-neutral-400 mt-1">{task.description}</p>
                </div>
                <Badge variant="outline" className={`
                  ${task.status === 'pending' ? 'bg-warning/20 text-warning' : 
                    task.status === 'in_progress' ? 'bg-primary/20 text-primary' : 
                    'bg-success/20 text-success'}
                `}>
                  {task.deadline ? format(new Date(task.deadline), 'yyyy/MM/dd h:mm a') : 'No deadline'}
                </Badge>
              </div>
              
              <div className="mt-3 flex justify-between items-center">
                <div className="flex items-center">
                  <Clock className="h-4 w-4 text-neutral-300 mr-1" />
                  <span className="text-xs text-neutral-300">
                    {task.deadline ? 
                      `${Math.floor((new Date(task.deadline).getTime() - new Date().getTime()) / (1000 * 60 * 60))} घण्टा बाँकी` : 
                      'No deadline'}
                  </span>
                </div>
                <div className="flex gap-2">
                  <Button 
                    size="sm" 
                    onClick={() => handleComplete(task.id)}
                    disabled={completeTaskMutation.isPending}
                  >
                    <CheckCircle2 className="h-4 w-4 mr-1" /> पूरा भयो
                  </Button>
                  <Button 
                    size="sm" 
                    variant="outline"
                    onClick={() => onTaskSelect(task)}
                  >
                    <Upload className="h-4 w-4 mr-1" /> अपलोड
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </>
      )}
      
      {completedTasks.length > 0 && (
        <>
          <h4 className="text-sm font-medium mb-2 mt-6">पूरा भएका कार्य</h4>
          {completedTasks.map((task: any) => (
            <div key={task.id} className="border-b pb-4 mb-4 last:border-0 last:mb-0 last:pb-0">
              <div className="flex justify-between items-start">
                <div className="flex items-center gap-2">
                  <h4 className="font-medium line-through text-neutral-300">{task.title}</h4>
                  <CheckCircle2 className="h-4 w-4 text-green-500" />
                </div>
                <Badge variant="outline" className="bg-neutral-200 text-neutral-400">
                  पूरा भयो
                </Badge>
              </div>
              
              <p className="text-sm text-neutral-300 mt-1 line-through">{task.description}</p>
              
              {task.completedAt && (
                <div className="mt-2 text-xs text-neutral-400">
                  पूरा भएको: {format(new Date(task.completedAt), 'yyyy/MM/dd h:mm a')}
                </div>
              )}
            </div>
          ))}
        </>
      )}
    </div>
  );
}
