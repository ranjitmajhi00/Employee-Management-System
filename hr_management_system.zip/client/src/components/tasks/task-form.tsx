import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useMutation } from '@tanstack/react-query';
import { apiRequest, queryClient } from '@/lib/queryClient';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { Upload, X, Loader2 } from 'lucide-react';
import { 
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from '@/components/ui/dialog';

const taskSubmissionSchema = z.object({
  photo: z.string().optional(),
  document: z.string().optional(),
  notes: z.string().optional(),
});

type TaskSubmissionValues = z.infer<typeof taskSubmissionSchema>;

interface TaskFormProps {
  task: any;
  isOpen: boolean;
  onClose: () => void;
}

export function TaskForm({ task, isOpen, onClose }: TaskFormProps) {
  const { toast } = useToast();
  const [photoPreview, setPhotoPreview] = useState<string | null>(null);
  const [documentName, setDocumentName] = useState<string | null>(null);
  
  const form = useForm<TaskSubmissionValues>({
    resolver: zodResolver(taskSubmissionSchema),
    defaultValues: {
      photo: '',
      document: '',
      notes: '',
    },
  });
  
  const updateTaskMutation = useMutation({
    mutationFn: async (data: TaskSubmissionValues) => {
      const taskData = {
        status: 'completed',
        photo: data.photo,
        document: data.document,
        notes: data.notes,
      };
      
      const res = await apiRequest("PATCH", `/api/tasks/${task.id}`, taskData);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/tasks/type/${task.type}`] });
      toast({
        title: 'कार्य पेश भयो',
        description: 'तपाईंको कार्य सफलतापूर्वक पेश भयो।',
      });
      onClose();
    },
    onError: (error: Error) => {
      toast({
        title: 'त्रुटि',
        description: error.message,
        variant: 'destructive',
      });
    },
  });
  
  const handlePhotoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    
    if (file.size > 5 * 1024 * 1024) {
      toast({
        title: 'फाइल अति ठूलो छ',
        description: 'फाइल साइज 5MB भन्दा कम हुनुपर्छ',
        variant: 'destructive',
      });
      return;
    }
    
    const reader = new FileReader();
    reader.onload = (event) => {
      if (event.target?.result) {
        setPhotoPreview(event.target.result as string);
        form.setValue('photo', event.target.result as string);
      }
    };
    reader.readAsDataURL(file);
  };
  
  const handleDocumentChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    
    if (file.size > 10 * 1024 * 1024) {
      toast({
        title: 'फाइल अति ठूलो छ',
        description: 'फाइल साइज 10MB भन्दा कम हुनुपर्छ',
        variant: 'destructive',
      });
      return;
    }
    
    setDocumentName(file.name);
    
    const reader = new FileReader();
    reader.onload = (event) => {
      if (event.target?.result) {
        form.setValue('document', event.target.result as string);
      }
    };
    reader.readAsDataURL(file);
  };
  
  const clearPhoto = () => {
    setPhotoPreview(null);
    form.setValue('photo', '');
  };
  
  const clearDocument = () => {
    setDocumentName(null);
    form.setValue('document', '');
  };
  
  const onSubmit = (data: TaskSubmissionValues) => {
    updateTaskMutation.mutate(data);
  };
  
  if (!task) return null;
  
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>कार्य पेश गर्नुहोस्</DialogTitle>
          <DialogDescription>
            {task.title} - कार्य विवरण र फाइलहरू अपलोड गर्नुहोस्
          </DialogDescription>
        </DialogHeader>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <div className="space-y-4">
              <div className="border rounded-md p-4">
                <FormLabel className="block mb-2">फोटो अपलोड</FormLabel>
                {photoPreview ? (
                  <div className="relative">
                    <img 
                      src={photoPreview} 
                      alt="Task" 
                      className="h-40 w-full object-cover rounded-md" 
                    />
                    <Button 
                      type="button"
                      variant="ghost" 
                      size="icon" 
                      className="absolute top-1 right-1 bg-white rounded-full h-6 w-6 p-1"
                      onClick={clearPhoto}
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                ) : (
                  <div className="border-2 border-dashed border-gray-300 rounded-md p-6 text-center">
                    <Upload className="mx-auto h-8 w-8 text-gray-400" />
                    <p className="mt-1 text-sm text-gray-500">फोटो अपलोड गर्न क्लिक गर्नुहोस् वा यहाँ खिच्नुहोस्</p>
                    <Input 
                      type="file" 
                      accept="image/*" 
                      className="sr-only" 
                      id="photo-upload"
                      onChange={handlePhotoChange}
                    />
                    <Button 
                      type="button" 
                      variant="outline" 
                      className="mt-2"
                      onClick={() => document.getElementById('photo-upload')?.click()}
                    >
                      फोटो अपलोड
                    </Button>
                  </div>
                )}
              </div>
              
              <div className="border rounded-md p-4">
                <FormLabel className="block mb-2">कागजात अपलोड</FormLabel>
                {documentName ? (
                  <div className="flex justify-between items-center p-2 border rounded-md">
                    <span className="text-sm">{documentName}</span>
                    <Button 
                      type="button"
                      variant="ghost" 
                      size="icon" 
                      className="h-6 w-6 p-1"
                      onClick={clearDocument}
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                ) : (
                  <div className="border-2 border-dashed border-gray-300 rounded-md p-4 text-center">
                    <p className="text-sm text-gray-500">कागजात अपलोड गर्न क्लिक गर्नुहोस्</p>
                    <Input 
                      type="file" 
                      className="sr-only" 
                      id="document-upload"
                      onChange={handleDocumentChange}
                    />
                    <Button 
                      type="button" 
                      variant="outline" 
                      className="mt-2"
                      onClick={() => document.getElementById('document-upload')?.click()}
                    >
                      कागजात अपलोड
                    </Button>
                  </div>
                )}
              </div>
              
              <FormField
                control={form.control}
                name="notes"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>कार्य नोट</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="कार्यको बारेमा थप जानकारी दिनुहोस्..."
                        className="min-h-[100px]"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            
            <DialogFooter>
              <Button 
                type="button" 
                variant="secondary" 
                onClick={onClose}
              >
                रद्द गर्नुहोस्
              </Button>
              <Button 
                type="submit" 
                disabled={updateTaskMutation.isPending}
              >
                {updateTaskMutation.isPending ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    पेश गर्दै...
                  </>
                ) : 'पेश गर्नुहोस्'}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
