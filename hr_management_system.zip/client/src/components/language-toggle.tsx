import React from 'react';
import { Button } from '@/components/ui/button';
import { useLanguage } from '@/hooks/use-language';

export function LanguageToggle() {
  const { t } = useLanguage();

  return (
    <div className="flex items-center space-x-2">
      <Button
        variant="default"
        size="sm"
        className="h-8 px-2 text-xs"
      >
        {t('english')}
      </Button>
    </div>
  );
}