import React, { useEffect, useRef, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Loader2, X, QrCode, Info } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface QrScannerProps {
  onScan: (qrCodeContent: string) => void;
  onClose: () => void;
}

export function QrScanner({ onScan, onClose }: QrScannerProps) {
  const [hasCamera, setHasCamera] = useState<boolean>(true);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animationRef = useRef<number>();
  const { toast } = useToast();

  useEffect(() => {
    let stream: MediaStream | null = null;

    const startCamera = async () => {
      setLoading(true);
      try {
        stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: 'environment' }
        });
        
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          setHasCamera(true);
          setLoading(false);
        }
      } catch (err) {
        console.error('Error accessing camera:', err);
        setHasCamera(false);
        setError('क्यामेरा एक्सेस गर्न सकिएन। कृपया अनुमति दिनुहोस्।');
        setLoading(false);
        
        toast({
          title: 'क्यामेरा एक्सेस त्रुटि',
          description: 'QR कोड स्क्यान गर्न क्यामेरा अनुमति आवश्यक छ।',
          variant: 'destructive'
        });
      }
    };

    startCamera();

    return () => {
      if (stream) {
        stream.getTracks().forEach(track => track.stop());
      }
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, [toast]);

  useEffect(() => {
    const scanQRCode = () => {
      if (loading || !hasCamera || error) return;
      
      const video = videoRef.current;
      const canvas = canvasRef.current;
      
      if (!video || !canvas || video.readyState !== video.HAVE_ENOUGH_DATA) {
        animationRef.current = requestAnimationFrame(scanQRCode);
        return;
      }
      
      const context = canvas.getContext('2d');
      if (!context) return;
      
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      context.drawImage(video, 0, 0, canvas.width, canvas.height);
      
      try {
        // Using a dynamic import to load jsQR only when needed
        import('jsqr').then(({ default: jsQR }) => {
          const imageData = context.getImageData(0, 0, canvas.width, canvas.height);
          const code = jsQR(imageData.data, imageData.width, imageData.height, {
            inversionAttempts: 'dontInvert',
          });
          
          if (code) {
            // QR code detected
            onScan(code.data);
            return;
          }
          
          // Continue scanning
          animationRef.current = requestAnimationFrame(scanQRCode);
        }).catch(err => {
          console.error('Error loading jsQR:', err);
          setError('QR कोड स्क्यानर लोड गर्न सकिएन।');
        });
      } catch (err) {
        console.error('Error scanning QR code:', err);
      }
    };

    if (!loading && hasCamera && !error) {
      animationRef.current = requestAnimationFrame(scanQRCode);
    }

    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, [loading, hasCamera, error, onScan]);

  return (
    <div className="relative w-full">
      <div className="absolute top-0 right-0 z-10">
        <Button 
          variant="ghost" 
          size="icon" 
          className="bg-white/80 rounded-full h-8 w-8 text-neutral-700"
          onClick={onClose}
        >
          <X className="h-4 w-4" />
        </Button>
      </div>
      
      {loading ? (
        <div className="flex flex-col items-center justify-center h-64 bg-gray-100">
          <Loader2 className="h-8 w-8 animate-spin mb-2 text-primary" />
          <p className="text-sm text-neutral-500">क्यामेरा लोड हुँदैछ...</p>
        </div>
      ) : error || !hasCamera ? (
        <div className="flex flex-col items-center justify-center h-64 bg-gray-100">
          <Info className="h-8 w-8 mb-2 text-destructive" />
          <p className="text-sm text-neutral-500 mb-2">{error || 'क्यामेरा उपलब्ध छैन'}</p>
          <Button variant="outline" onClick={onClose}>
            बन्द गर्नुहोस्
          </Button>
        </div>
      ) : (
        <div className="relative">
          <video 
            ref={videoRef} 
            autoPlay 
            playsInline 
            muted 
            className="w-full h-64 object-cover"
          />
          <div className="absolute inset-0 pointer-events-none border-2 border-dashed border-primary/50 rounded-lg flex items-center justify-center">
            <QrCode className="h-12 w-12 text-primary/30" />
          </div>
          <canvas ref={canvasRef} className="hidden" />
          <div className="text-center mt-2">
            <p className="text-xs text-neutral-500">QR कोड स्क्यान गर्नुहोस्</p>
          </div>
        </div>
      )}
    </div>
  );
}
