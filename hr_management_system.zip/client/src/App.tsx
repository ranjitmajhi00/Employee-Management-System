import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider } from "@/hooks/use-auth";
import { LanguageProvider } from "@/hooks/use-language";
import { ProtectedRoute } from "@/lib/protected-route";

import NotFound from "@/pages/not-found";
import AuthPage from "@/pages/auth-page";
import Dashboard from "@/pages/dashboard";
import TaskManagement from "@/pages/task-management";
import LeaveManagement from "@/pages/leave-management";
import Attendance from "@/pages/attendance";
import Profile from "@/pages/profile";
import Reports from "@/pages/reports";

// Admin pages
import AdminDashboard from "@/pages/admin/dashboard";
import EmployeeManagement from "@/pages/admin/employee-management";
import AdminTaskManagement from "@/pages/admin/task-management";
import AdminLeaveManagement from "@/pages/admin/leave-management";
import AttendanceManagement from "@/pages/admin/attendance-management";
import AdminReports from "@/pages/admin/reports";

function Router() {
  return (
    <Switch>
      {/* Public routes */}
      <Route path="/auth" component={AuthPage} />
      
      {/* Employee routes */}
      <ProtectedRoute path="/" component={Dashboard} />
      <ProtectedRoute path="/tasks" component={TaskManagement} />
      <ProtectedRoute path="/leave" component={LeaveManagement} />
      <ProtectedRoute path="/attendance" component={Attendance} />
      <ProtectedRoute path="/profile" component={Profile} />
      <ProtectedRoute path="/reports" component={Reports} />
      
      {/* Admin routes */}
      <ProtectedRoute path="/admin" component={AdminDashboard} adminOnly />
      <ProtectedRoute path="/admin/employees" component={EmployeeManagement} adminOnly />
      <ProtectedRoute path="/admin/tasks" component={AdminTaskManagement} adminOnly />
      <ProtectedRoute path="/admin/leave" component={AdminLeaveManagement} adminOnly />
      <ProtectedRoute path="/admin/attendance" component={AttendanceManagement} adminOnly />
      <ProtectedRoute path="/admin/reports" component={AdminReports} adminOnly />
      
      {/* Fallback to 404 */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <LanguageProvider>
          <AuthProvider>
            <Toaster />
            <Router />
          </AuthProvider>
        </LanguageProvider>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
