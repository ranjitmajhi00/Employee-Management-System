import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";
import { useLocation } from "wouter";

// If the user navigates directly to a route that isn't /, 
// ensure routing works correctly in development mode
function AppWithLocationReset() {
  const [, setLocation] = useLocation();
  
  // Reset location if it doesn't start with / in development
  if (typeof window !== "undefined" && 
      process.env.NODE_ENV === "development" && 
      window.location.pathname !== "/" && 
      !window.location.search.includes("_path=")) {
    const path = window.location.pathname;
    setLocation(path);
  }
  
  return <App />;
}

createRoot(document.getElementById("root")!).render(<AppWithLocationReset />);
