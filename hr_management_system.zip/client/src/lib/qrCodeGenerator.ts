import QRCode from 'qrcode';

/**
 * Generate a QR Code image as a data URL from the provided content
 * @param content The content to encode in the QR code
 * @returns A Promise that resolves to a data URL string of the QR code image
 */
export function qrCodeGenerator(content: string): Promise<string> {
  return QRCode.toDataURL(content, {
    width: 300,
    margin: 1,
    color: {
      dark: '#000',
      light: '#fff'
    },
    errorCorrectionLevel: 'H'
  });
}
