import React, { createContext, useContext, ReactNode } from 'react';

type LanguageContextType = {
  t: (key: string) => string;
};

// Create context
const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

// English translations
const translations: Record<string, string> = {
  // Auth
  'login': 'Login',
  'register': 'Register',
  'username': 'Username',
  'password': 'Password',
  'confirm_password': 'Confirm Password',
  'name': 'Full Name',
  'email': 'Email',
  'login_button': 'Sign In',
  'register_button': 'Sign Up',
  'auth_subtitle': 'Login or Register',
  'forgot_password': 'Forgot Password?',
  'logging_in': 'Logging in...',
  'registering': 'Registering...',
  'welcome_title': 'Welcome to HR Management System',
  'welcome_description': 'Manage your employees, tasks, attendance, and performance all in one place.',
  'employee_management_system': 'Employee Management System',
  'no_notifications': 'No notifications',
  
  // Navigation
  'dashboard': 'Dashboard',
  'attendance': 'Attendance',
  'tasks': 'Tasks',
  'leave': 'Leave',
  'reports': 'Reports',
  'profile': 'Profile',
  'admin': 'Admin',
  
  // Dashboard
  'welcome': 'Welcome',
  'attendance_status': 'Attendance Status',
  'check_in': 'Check In',
  'check_out': 'Check Out',
  'scan_qr': 'Scan QR Code',
  'tasks_summary': 'Tasks Summary',
  'completed_tasks': 'Completed Tasks',
  'pending_tasks': 'Pending Tasks',
  'leave_balance': 'Leave Balance',
  'apply_leave': 'Apply for Leave',
  'performance': 'Performance',
  'notifications': 'Notifications',
  'view_all': 'View All',
  
  // Attendance
  'scan_to_record': 'Scan QR Code to Record Attendance',
  'attendance_history': 'Attendance History',
  'date': 'Date',
  'time': 'Time',
  'type': 'Type',
  'location': 'Location',
  'no_attendance': 'No attendance records available',
  
  // Tasks
  'my_tasks': 'My Tasks',
  'task_title': 'Title',
  'task_description': 'Description',
  'task_deadline': 'Deadline',
  'task_priority': 'Priority',
  'task_status': 'Status',
  'add_task': 'Add Task',
  'edit_task': 'Edit Task',
  'delete_task': 'Delete Task',
  'complete_task': 'Complete Task',
  'no_tasks': 'No tasks available',
  'high': 'High',
  'medium': 'Medium',
  'low': 'Low',
  'pending': 'Pending',
  'in_progress': 'In Progress',
  'completed': 'Completed',
  
  // Leave
  'leave_management': 'Leave Management',
  'apply_new_leave': 'Apply for New Leave',
  'leave_type': 'Leave Type',
  'start_date': 'Start Date',
  'end_date': 'End Date',
  'reason': 'Reason',
  'status': 'Status',
  'approved': 'Approved',
  'rejected': 'Rejected',
  'sick_leave': 'Sick Leave',
  'personal_leave': 'Personal Leave',
  'vacation': 'Vacation',
  'no_leave': 'No leave records available',
  
  // Reports
  'performance_analysis': 'Performance Analysis',
  'attendance_analysis': 'Attendance Analysis',
  'leave_analysis': 'Leave Analysis',
  'task_completion': 'Task Completion',
  'timeliness': 'Timeliness',
  'quality': 'Quality',
  'overall_score': 'Overall Score',
  'export': 'Export',
  'no_data': 'No data available',
  
  // Profile
  'profile_info': 'Profile Information',
  'phone': 'Phone',
  'address': 'Address',
  'department': 'Department',
  'position': 'Position',
  'joining_date': 'Joining Date',
  'save_changes': 'Save Changes',
  
  // Admin
  'employee_management': 'Employee Management',
  'add_employee': 'Add Employee',
  'edit_employee': 'Edit Employee',
  'delete_employee': 'Delete Employee',
  'role': 'Role',
  'admin_role': 'Admin',
  'employee_role': 'Employee',
  'search': 'Search',
  
  // Common
  'save': 'Save',
  'cancel': 'Cancel',
  'delete': 'Delete',
  'edit': 'Edit',
  'add': 'Add',
  'view': 'View',
  'search_placeholder': 'Search...',
  'no_results': 'No results found',
  'logout': 'Logout',
  'loading': 'Loading...',
  'language': 'Language',
  'english': 'English',
};

// Language provider component
export const LanguageProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  // Function to translate text
  const t = (key: string): string => {
    return translations[key] || key;
  };

  // Store the context value
  const contextValue = {
    t,
  };

  return (
    <LanguageContext.Provider value={contextValue}>
      {children}
    </LanguageContext.Provider>
  );
};

// Custom hook to use the language context
export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};
