import { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';

type QrCodeType = 'check_in' | 'check_out';

export function useQrCode(type: QrCodeType) {
  const [qrDataUrl, setQrDataUrl] = useState<string | null>(null);
  
  const {
    data,
    isLoading,
    error,
    refetch
  } = useQuery({
    queryKey: [`/api/qrcode/${type}`],
    refetchInterval: 3600000, // Refetch every hour
  });
  
  useEffect(() => {
    if (data?.qrCode) {
      generateQrCode(data.qrCode);
    }
  }, [data]);
  
  const generateQrCode = async (qrCode: string) => {
    try {
      // Dynamically import QRCode.js
      const QRCode = (await import('qrcode')).default;
      
      // Generate QR code as data URL
      const dataUrl = await QRCode.toDataURL(qrCode, {
        errorCorrectionLevel: 'H',
        margin: 1,
        width: 200,
        color: {
          dark: '#000000',
          light: '#ffffff',
        },
      });
      
      setQrDataUrl(dataUrl);
    } catch (error) {
      console.error("Error generating QR code:", error);
    }
  };
  
  const recordAttendance = async (qrCode: string, geoLocation: string) => {
    if (!qrCode) return null;
    
    try {
      const res = await apiRequest("POST", "/api/attendance", {
        type,
        qrCode,
        geoLocation
      });
      
      return await res.json();
    } catch (error) {
      console.error("Error recording attendance:", error);
      throw error;
    }
  };
  
  return {
    qrDataUrl,
    qrCode: data?.qrCode,
    isLoading,
    error,
    refetch,
    recordAttendance
  };
}
