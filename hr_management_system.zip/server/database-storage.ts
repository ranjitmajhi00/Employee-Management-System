import {
  User, InsertUser,
  Task, InsertTask,
  Attendance, InsertAttendance,
  Leave, InsertLeave,
  Evaluation, InsertEvaluation,
  Notification, InsertNotification,
  QrCodeLog, InsertQrCodeLog,
  TaskType,
  users,
  tasks,
  attendance,
  leave,
  evaluations,
  notifications,
  qrCodeLogs
} from "@shared/schema";
import session from "express-session";
import connectPg from "connect-pg-simple";
import { eq, and, gte, desc } from "drizzle-orm";
import { db, pool } from "./db";
import { IStorage } from "./storage";

const PostgresSessionStore = connectPg(session);

export class DatabaseStorage implements IStorage {
  sessionStore: session.SessionStore;

  constructor() {
    this.sessionStore = new PostgresSessionStore({ 
      pool, 
      createTableIfMissing: true 
    });
  }

  // User Management
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  async updateUser(id: number, userData: Partial<User>): Promise<User | undefined> {
    const [user] = await db
      .update(users)
      .set(userData)
      .where(eq(users.id, id))
      .returning();
    return user;
  }

  async getAllUsers(): Promise<User[]> {
    return await db.select().from(users);
  }

  // Task Management
  async createTask(insertTask: InsertTask): Promise<Task> {
    const [task] = await db.insert(tasks).values(insertTask).returning();
    return task;
  }

  async getTaskById(id: number): Promise<Task | undefined> {
    const [task] = await db.select().from(tasks).where(eq(tasks.id, id));
    return task;
  }

  async getTasksByUserId(userId: number): Promise<Task[]> {
    return await db
      .select()
      .from(tasks)
      .where(eq(tasks.assignedTo, userId));
  }

  async getTasksByType(userId: number, type: TaskType): Promise<Task[]> {
    return await db
      .select()
      .from(tasks)
      .where(and(
        eq(tasks.assignedTo, userId),
        eq(tasks.type, type)
      ));
  }

  async updateTask(id: number, taskData: Partial<Task>): Promise<Task | undefined> {
    const [task] = await db
      .update(tasks)
      .set(taskData)
      .where(eq(tasks.id, id))
      .returning();
    return task;
  }

  async getAllTasks(): Promise<Task[]> {
    return await db.select().from(tasks);
  }

  // Attendance Management
  async recordAttendance(insertAttendance: InsertAttendance): Promise<Attendance> {
    const [record] = await db.insert(attendance).values(insertAttendance).returning();
    return record;
  }

  async getAttendanceByUserId(userId: number): Promise<Attendance[]> {
    return await db
      .select()
      .from(attendance)
      .where(eq(attendance.userId, userId));
  }

  async getTodayAttendance(userId: number): Promise<Attendance[]> {
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    return await db
      .select()
      .from(attendance)
      .where(and(
        eq(attendance.userId, userId),
        gte(attendance.timestamp, today)
      ));
  }

  async getAllAttendanceForToday(): Promise<Attendance[]> {
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    return await db
      .select()
      .from(attendance)
      .where(gte(attendance.timestamp, today));
  }

  // Leave Management
  async createLeave(insertLeave: InsertLeave): Promise<Leave> {
    const [leave_record] = await db
      .insert(leave)
      .values({
        ...insertLeave,
        status: 'pending',
        approvedBy: null
      })
      .returning();
    return leave_record;
  }

  async getLeaveById(id: number): Promise<Leave | undefined> {
    const [leave_record] = await db.select().from(leave).where(eq(leave.id, id));
    return leave_record;
  }

  async getLeavesByUserId(userId: number): Promise<Leave[]> {
    return await db
      .select()
      .from(leave)
      .where(eq(leave.userId, userId));
  }

  async updateLeave(id: number, leaveData: Partial<Leave>): Promise<Leave | undefined> {
    const [leave_record] = await db
      .update(leave)
      .set(leaveData)
      .where(eq(leave.id, id))
      .returning();
    return leave_record;
  }

  async getAllLeaves(): Promise<Leave[]> {
    return await db.select().from(leave);
  }

  // Evaluation Management
  async createEvaluation(insertEvaluation: InsertEvaluation): Promise<Evaluation> {
    const [evaluation] = await db.insert(evaluations).values(insertEvaluation).returning();
    return evaluation;
  }

  async getEvaluationsByUserId(userId: number): Promise<Evaluation[]> {
    return await db
      .select()
      .from(evaluations)
      .where(eq(evaluations.userId, userId));
  }

  async getLatestEvaluationByUserId(userId: number): Promise<Evaluation | undefined> {
    const userEvaluations = await this.getEvaluationsByUserId(userId);
    if (userEvaluations.length === 0) return undefined;

    return userEvaluations.reduce((latest, current) =>
      latest.createdAt > current.createdAt ? latest : current
    );
  }

  // Notification Management
  async createNotification(insertNotification: InsertNotification): Promise<Notification> {
    const [notification] = await db
      .insert(notifications)
      .values({
        ...insertNotification,
        isRead: false
      })
      .returning();
    return notification;
  }

  async getNotificationsByUserId(userId: number): Promise<Notification[]> {
    return await db
      .select()
      .from(notifications)
      .where(eq(notifications.userId, userId))
      .orderBy(desc(notifications.createdAt));
  }

  async markNotificationAsRead(id: number): Promise<Notification | undefined> {
    const [notification] = await db
      .update(notifications)
      .set({ isRead: true })
      .where(eq(notifications.id, id))
      .returning();
    return notification;
  }

  // QR Code Management
  async createQrCode(insertQrCode: InsertQrCodeLog): Promise<QrCodeLog> {
    const [qrCode] = await db.insert(qrCodeLogs).values(insertQrCode).returning();
    return qrCode;
  }

  async getActiveQrCodeForToday(type: string): Promise<QrCodeLog | undefined> {
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const todayStr = today.toISOString().split('T')[0];

    const [qrCode] = await db
      .select()
      .from(qrCodeLogs)
      .where(and(
        eq(qrCodeLogs.isActive, true),
        eq(qrCodeLogs.type, type),
        eq(qrCodeLogs.date, todayStr)
      ));

    return qrCode;
  }

  async deactivateQrCode(id: number): Promise<QrCodeLog | undefined> {
    const [qrCode] = await db
      .update(qrCodeLogs)
      .set({ isActive: false })
      .where(eq(qrCodeLogs.id, id))
      .returning();
    return qrCode;
  }
}