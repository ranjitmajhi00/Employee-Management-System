import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth } from "./auth";
import { randomBytes } from "crypto";
import { 
  insertTaskSchema, 
  insertLeaveSchema, 
  insertAttendanceSchema,
  insertEvaluationSchema,
  insertNotificationSchema 
} from "@shared/schema";
import path from "path";
import fs from "fs";

export async function registerRoutes(app: Express): Promise<Server> {
  // Set up authentication routes
  setupAuth(app);

  // User routes
  app.get("/api/users", async (req, res) => {
    if (!req.isAuthenticated() || req.user.role !== "admin") {
      return res.status(403).json({ message: "Forbidden" });
    }
    
    const users = await storage.getAllUsers();
    // Don't send passwords to client
    const usersWithoutPassword = users.map(({ password, ...rest }) => rest);
    res.json(usersWithoutPassword);
  });

  app.patch("/api/users/:id", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    const userId = parseInt(req.params.id);
    
    // Only admins can update other users
    if (req.user.id !== userId && req.user.role !== "admin") {
      return res.status(403).json({ message: "Forbidden" });
    }
    
    // Don't allow updating role unless user is admin
    if (req.body.role && req.user.role !== "admin") {
      delete req.body.role;
    }
    
    // Don't allow updating password through this route
    if (req.body.password) {
      delete req.body.password;
    }
    
    const updatedUser = await storage.updateUser(userId, req.body);
    if (!updatedUser) {
      return res.status(404).json({ message: "User not found" });
    }
    
    // Don't send password to client
    const { password, ...userWithoutPassword } = updatedUser;
    res.json(userWithoutPassword);
  });

  // Task routes
  app.post("/api/tasks", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    // Validate request body
    const validation = insertTaskSchema.safeParse(req.body);
    if (!validation.success) {
      return res.status(400).json({ message: "Invalid task data", errors: validation.error.errors });
    }
    
    // Only admins can create tasks for other users
    if (req.body.assignedBy !== req.user.id && req.user.role !== "admin") {
      return res.status(403).json({ message: "Forbidden" });
    }
    
    const task = await storage.createTask({
      ...req.body,
      assignedBy: req.user.id, // Force assignedBy to be current user
    });
    
    // Create notification for assigned user
    if (task.assignedTo !== req.user.id) {
      await storage.createNotification({
        userId: task.assignedTo,
        title: "New Task Assigned",
        message: `You have been assigned a new ${task.type} task: ${task.title}`
      });
    }
    
    res.status(201).json(task);
  });

  app.get("/api/tasks", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    // Admin gets all tasks, employees get only their tasks
    let tasks;
    if (req.user.role === "admin") {
      tasks = await storage.getAllTasks();
    } else {
      tasks = await storage.getTasksByUserId(req.user.id);
    }
    
    res.json(tasks);
  });

  app.get("/api/tasks/user", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    const tasks = await storage.getTasksByUserId(req.user.id);
    res.json(tasks);
  });

  app.get("/api/tasks/type/:type", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    const type = req.params.type as any;
    if (!['daily', 'monthly', 'emergency'].includes(type)) {
      return res.status(400).json({ message: "Invalid task type" });
    }
    
    const tasks = await storage.getTasksByType(req.user.id, type);
    res.json(tasks);
  });

  app.patch("/api/tasks/:id", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    const taskId = parseInt(req.params.id);
    const task = await storage.getTaskById(taskId);
    
    if (!task) {
      return res.status(404).json({ message: "Task not found" });
    }
    
    // Only assigned employee or admin can update task
    if (task.assignedTo !== req.user.id && req.user.role !== "admin") {
      return res.status(403).json({ message: "Forbidden" });
    }
    
    // Set completedAt if status is being updated to 'completed'
    if (req.body.status === "completed" && task.status !== "completed") {
      req.body.completedAt = new Date();
      
      // Notify task creator
      await storage.createNotification({
        userId: task.assignedBy,
        title: "Task Completed",
        message: `Task "${task.title}" has been completed by ${req.user.name}`
      });
    }
    
    const updatedTask = await storage.updateTask(taskId, req.body);
    res.json(updatedTask);
  });

  // Attendance routes
  app.post("/api/attendance", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    // Validate request body
    const validation = insertAttendanceSchema.safeParse(req.body);
    if (!validation.success) {
      return res.status(400).json({ message: "Invalid attendance data", errors: validation.error.errors });
    }
    
    // Check if QR code is valid for today
    const qrCode = await storage.getActiveQrCodeForToday(req.body.type);
    if (!qrCode || qrCode.qrCode !== req.body.qrCode) {
      return res.status(400).json({ message: "Invalid QR code" });
    }
    
    // Check if user already recorded this type of attendance today
    const todayAttendance = await storage.getTodayAttendance(req.user.id);
    const hasRecordedSameType = todayAttendance.some(a => a.type === req.body.type);
    
    if (hasRecordedSameType) {
      return res.status(400).json({ message: `You have already ${req.body.type === 'check_in' ? 'checked in' : 'checked out'} today` });
    }
    
    const attendance = await storage.recordAttendance({
      userId: req.user.id,
      type: req.body.type,
      geoLocation: req.body.geoLocation,
      qrCode: req.body.qrCode
    });
    
    res.status(201).json(attendance);
  });

  app.get("/api/attendance", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    const attendance = await storage.getAttendanceByUserId(req.user.id);
    res.json(attendance);
  });

  app.get("/api/attendance/today", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    const attendance = await storage.getTodayAttendance(req.user.id);
    res.json(attendance);
  });

  app.get("/api/attendance/all/today", async (req, res) => {
    if (!req.isAuthenticated() || req.user.role !== "admin") {
      return res.status(403).json({ message: "Forbidden" });
    }
    
    const attendance = await storage.getAllAttendanceForToday();
    res.json(attendance);
  });

  // QR Code routes
  app.get("/api/qrcode/:type", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    const type = req.params.type;
    if (!["check_in", "check_out"].includes(type)) {
      return res.status(400).json({ message: "Invalid attendance type" });
    }
    
    // Check if we already have an active QR code for today
    let qrCode = await storage.getActiveQrCodeForToday(type);
    
    if (!qrCode) {
      // Generate a new QR code
      const newQrCode = randomBytes(16).toString('hex');
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      
      qrCode = await storage.createQrCode({
        qrCode: newQrCode,
        type: type as any,
        date: today,
        isActive: true
      });
    }
    
    res.json({ qrCode: qrCode.qrCode });
  });

  // Leave routes
  app.post("/api/leave", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    // Validate request body
    const validation = insertLeaveSchema.safeParse(req.body);
    if (!validation.success) {
      return res.status(400).json({ message: "Invalid leave data", errors: validation.error.errors });
    }
    
    const leave = await storage.createLeave({
      ...req.body,
      userId: req.user.id
    });
    
    // Notify admin about leave request
    const admins = (await storage.getAllUsers()).filter(user => user.role === "admin");
    for (const admin of admins) {
      await storage.createNotification({
        userId: admin.id,
        title: "New Leave Request",
        message: `${req.user.name} has requested leave from ${leave.startDate} to ${leave.endDate}`
      });
    }
    
    res.status(201).json(leave);
  });

  app.get("/api/leave", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    // Admin gets all leaves, employees get only their leaves
    let leaves;
    if (req.user.role === "admin") {
      leaves = await storage.getAllLeaves();
    } else {
      leaves = await storage.getLeavesByUserId(req.user.id);
    }
    
    res.json(leaves);
  });

  app.patch("/api/leave/:id", async (req, res) => {
    if (!req.isAuthenticated() || req.user.role !== "admin") {
      return res.status(403).json({ message: "Forbidden" });
    }
    
    const leaveId = parseInt(req.params.id);
    const leave = await storage.getLeaveById(leaveId);
    
    if (!leave) {
      return res.status(404).json({ message: "Leave not found" });
    }
    
    // If status is being updated, include approvedBy
    if (req.body.status && ["approved", "rejected"].includes(req.body.status)) {
      req.body.approvedBy = req.user.id;
      
      // Notify the employee
      await storage.createNotification({
        userId: leave.userId,
        title: `Leave ${req.body.status === "approved" ? "Approved" : "Rejected"}`,
        message: `Your leave request from ${leave.startDate} to ${leave.endDate} has been ${req.body.status}`
      });
    }
    
    const updatedLeave = await storage.updateLeave(leaveId, req.body);
    res.json(updatedLeave);
  });

  // Evaluation routes
  app.post("/api/evaluation", async (req, res) => {
    if (!req.isAuthenticated() || req.user.role !== "admin") {
      return res.status(403).json({ message: "Forbidden" });
    }
    
    // Validate request body
    const validation = insertEvaluationSchema.safeParse(req.body);
    if (!validation.success) {
      return res.status(400).json({ message: "Invalid evaluation data", errors: validation.error.errors });
    }
    
    const evaluation = await storage.createEvaluation(req.body);
    
    // Notify the employee
    await storage.createNotification({
      userId: evaluation.userId,
      title: "New Performance Evaluation",
      message: `Your performance evaluation for ${evaluation.month}/${evaluation.year} has been submitted`
    });
    
    res.status(201).json(evaluation);
  });

  app.get("/api/evaluation/user/:userId", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    const userId = parseInt(req.params.userId);
    
    // Only allow users to see their own evaluations, unless admin
    if (userId !== req.user.id && req.user.role !== "admin") {
      return res.status(403).json({ message: "Forbidden" });
    }
    
    const evaluations = await storage.getEvaluationsByUserId(userId);
    res.json(evaluations);
  });

  app.get("/api/evaluation/latest/user/:userId", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    const userId = parseInt(req.params.userId);
    
    // Only allow users to see their own evaluations, unless admin
    if (userId !== req.user.id && req.user.role !== "admin") {
      return res.status(403).json({ message: "Forbidden" });
    }
    
    const evaluation = await storage.getLatestEvaluationByUserId(userId);
    
    if (!evaluation) {
      return res.status(404).json({ message: "No evaluation found" });
    }
    
    res.json(evaluation);
  });

  // Notification routes
  app.get("/api/notifications", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    const notifications = await storage.getNotificationsByUserId(req.user.id);
    res.json(notifications);
  });

  app.patch("/api/notifications/:id/read", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    const notificationId = parseInt(req.params.id);
    const updatedNotification = await storage.markNotificationAsRead(notificationId);
    
    if (!updatedNotification) {
      return res.status(404).json({ message: "Notification not found" });
    }
    
    res.json(updatedNotification);
  });

  const httpServer = createServer(app);
  return httpServer;
}
