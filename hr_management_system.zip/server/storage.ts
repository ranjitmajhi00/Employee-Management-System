import { 
  User, InsertUser, 
  Task, InsertTask, 
  Attendance, InsertAttendance, 
  Leave, InsertLeave, 
  Evaluation, InsertEvaluation, 
  Notification, InsertNotification,
  QrCodeLog, InsertQrCodeLog,
  TaskType,
  users,
  tasks,
  attendance,
  leave,
  evaluations,
  notifications,
  qrCodeLogs
} from "@shared/schema";
import session from "express-session";
import createMemoryStore from "memorystore";
import connectPg from "connect-pg-simple";
import { eq, and, gte, desc } from "drizzle-orm";
import { db, pool } from "./db";

// Initialize session stores
const MemoryStore = createMemoryStore(session);
const PostgresSessionStore = connectPg(session);

export interface IStorage {
  // User Management
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, user: Partial<User>): Promise<User | undefined>;
  getAllUsers(): Promise<User[]>;
  
  // Task Management
  createTask(task: InsertTask): Promise<Task>;
  getTaskById(id: number): Promise<Task | undefined>;
  getTasksByUserId(userId: number): Promise<Task[]>;
  getTasksByType(userId: number, type: TaskType): Promise<Task[]>;
  updateTask(id: number, task: Partial<Task>): Promise<Task | undefined>;
  getAllTasks(): Promise<Task[]>;
  
  // Attendance Management
  recordAttendance(attendance: InsertAttendance): Promise<Attendance>;
  getAttendanceByUserId(userId: number): Promise<Attendance[]>;
  getTodayAttendance(userId: number): Promise<Attendance[]>;
  getAllAttendanceForToday(): Promise<Attendance[]>;
  
  // Leave Management
  createLeave(leave: InsertLeave): Promise<Leave>;
  getLeaveById(id: number): Promise<Leave | undefined>;
  getLeavesByUserId(userId: number): Promise<Leave[]>;
  updateLeave(id: number, leave: Partial<Leave>): Promise<Leave | undefined>;
  getAllLeaves(): Promise<Leave[]>;
  
  // Evaluation Management
  createEvaluation(evaluation: InsertEvaluation): Promise<Evaluation>;
  getEvaluationsByUserId(userId: number): Promise<Evaluation[]>;
  getLatestEvaluationByUserId(userId: number): Promise<Evaluation | undefined>;
  
  // Notification Management
  createNotification(notification: InsertNotification): Promise<Notification>;
  getNotificationsByUserId(userId: number): Promise<Notification[]>;
  markNotificationAsRead(id: number): Promise<Notification | undefined>;
  
  // QR Code Management
  createQrCode(qrCode: InsertQrCodeLog): Promise<QrCodeLog>;
  getActiveQrCodeForToday(type: string): Promise<QrCodeLog | undefined>;
  deactivateQrCode(id: number): Promise<QrCodeLog | undefined>;
  
  // Session Store
  sessionStore: session.SessionStore;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private tasks: Map<number, Task>;
  private attendance: Map<number, Attendance>;
  private leaves: Map<number, Leave>;
  private evaluations: Map<number, Evaluation>;
  private notifications: Map<number, Notification>;
  private qrCodes: Map<number, QrCodeLog>;
  sessionStore: session.SessionStore;
  
  private userCurrentId: number;
  private taskCurrentId: number;
  private attendanceCurrentId: number;
  private leaveCurrentId: number;
  private evaluationCurrentId: number;
  private notificationCurrentId: number;
  private qrCodeCurrentId: number;

  constructor() {
    this.users = new Map();
    this.tasks = new Map();
    this.attendance = new Map();
    this.leaves = new Map();
    this.evaluations = new Map();
    this.notifications = new Map();
    this.qrCodes = new Map();
    
    this.userCurrentId = 1;
    this.taskCurrentId = 1;
    this.attendanceCurrentId = 1;
    this.leaveCurrentId = 1;
    this.evaluationCurrentId = 1;
    this.notificationCurrentId = 1;
    this.qrCodeCurrentId = 1;
    
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000, // prune expired entries every 24h
    });
    
    // Create admin user by default
    this.createUser({
      username: "admin",
      password: "adminpassword", // This will be hashed in the auth.ts
      name: "System Admin",
      email: "admin@example.com",
      role: "admin"
    });
  }

  // User Management
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userCurrentId++;
    const createdAt = new Date();
    const user: User = { ...insertUser, id, createdAt };
    this.users.set(id, user);
    return user;
  }
  
  async updateUser(id: number, userData: Partial<User>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...userData };
    this.users.set(id, updatedUser);
    return updatedUser;
  }
  
  async getAllUsers(): Promise<User[]> {
    return Array.from(this.users.values());
  }

  // Task Management
  async createTask(insertTask: InsertTask): Promise<Task> {
    const id = this.taskCurrentId++;
    const createdAt = new Date();
    const task: Task = { ...insertTask, id, createdAt, completedAt: null };
    this.tasks.set(id, task);
    return task;
  }
  
  async getTaskById(id: number): Promise<Task | undefined> {
    return this.tasks.get(id);
  }
  
  async getTasksByUserId(userId: number): Promise<Task[]> {
    return Array.from(this.tasks.values()).filter(
      (task) => task.assignedTo === userId
    );
  }
  
  async getTasksByType(userId: number, type: TaskType): Promise<Task[]> {
    return Array.from(this.tasks.values()).filter(
      (task) => task.assignedTo === userId && task.type === type
    );
  }
  
  async updateTask(id: number, taskData: Partial<Task>): Promise<Task | undefined> {
    const task = this.tasks.get(id);
    if (!task) return undefined;
    
    const updatedTask = { ...task, ...taskData };
    this.tasks.set(id, updatedTask);
    return updatedTask;
  }
  
  async getAllTasks(): Promise<Task[]> {
    return Array.from(this.tasks.values());
  }

  // Attendance Management
  async recordAttendance(insertAttendance: InsertAttendance): Promise<Attendance> {
    const id = this.attendanceCurrentId++;
    const timestamp = new Date();
    const attendance: Attendance = { ...insertAttendance, id, timestamp };
    this.attendance.set(id, attendance);
    return attendance;
  }
  
  async getAttendanceByUserId(userId: number): Promise<Attendance[]> {
    return Array.from(this.attendance.values()).filter(
      (record) => record.userId === userId
    );
  }
  
  async getTodayAttendance(userId: number): Promise<Attendance[]> {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    return Array.from(this.attendance.values()).filter(
      (record) => record.userId === userId && record.timestamp >= today
    );
  }
  
  async getAllAttendanceForToday(): Promise<Attendance[]> {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    return Array.from(this.attendance.values()).filter(
      (record) => record.timestamp >= today
    );
  }

  // Leave Management
  async createLeave(insertLeave: InsertLeave): Promise<Leave> {
    const id = this.leaveCurrentId++;
    const createdAt = new Date();
    const leave: Leave = { 
      ...insertLeave, 
      id, 
      createdAt, 
      status: 'pending',
      approvedBy: null 
    };
    this.leaves.set(id, leave);
    return leave;
  }
  
  async getLeaveById(id: number): Promise<Leave | undefined> {
    return this.leaves.get(id);
  }
  
  async getLeavesByUserId(userId: number): Promise<Leave[]> {
    return Array.from(this.leaves.values()).filter(
      (leave) => leave.userId === userId
    );
  }
  
  async updateLeave(id: number, leaveData: Partial<Leave>): Promise<Leave | undefined> {
    const leave = this.leaves.get(id);
    if (!leave) return undefined;
    
    const updatedLeave = { ...leave, ...leaveData };
    this.leaves.set(id, updatedLeave);
    return updatedLeave;
  }
  
  async getAllLeaves(): Promise<Leave[]> {
    return Array.from(this.leaves.values());
  }

  // Evaluation Management
  async createEvaluation(insertEvaluation: InsertEvaluation): Promise<Evaluation> {
    const id = this.evaluationCurrentId++;
    const createdAt = new Date();
    const evaluation: Evaluation = { ...insertEvaluation, id, createdAt };
    this.evaluations.set(id, evaluation);
    return evaluation;
  }
  
  async getEvaluationsByUserId(userId: number): Promise<Evaluation[]> {
    return Array.from(this.evaluations.values()).filter(
      (evaluation) => evaluation.userId === userId
    );
  }
  
  async getLatestEvaluationByUserId(userId: number): Promise<Evaluation | undefined> {
    const userEvaluations = await this.getEvaluationsByUserId(userId);
    if (userEvaluations.length === 0) return undefined;
    
    return userEvaluations.reduce((latest, current) => 
      latest.createdAt > current.createdAt ? latest : current
    );
  }

  // Notification Management
  async createNotification(insertNotification: InsertNotification): Promise<Notification> {
    const id = this.notificationCurrentId++;
    const createdAt = new Date();
    const notification: Notification = { 
      ...insertNotification, 
      id, 
      createdAt, 
      isRead: false 
    };
    this.notifications.set(id, notification);
    return notification;
  }
  
  async getNotificationsByUserId(userId: number): Promise<Notification[]> {
    return Array.from(this.notifications.values()).filter(
      (notification) => notification.userId === userId
    ).sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }
  
  async markNotificationAsRead(id: number): Promise<Notification | undefined> {
    const notification = this.notifications.get(id);
    if (!notification) return undefined;
    
    const updatedNotification = { ...notification, isRead: true };
    this.notifications.set(id, updatedNotification);
    return updatedNotification;
  }

  // QR Code Management
  async createQrCode(insertQrCode: InsertQrCodeLog): Promise<QrCodeLog> {
    const id = this.qrCodeCurrentId++;
    const createdAt = new Date();
    const qrCode: QrCodeLog = { ...insertQrCode, id, createdAt };
    this.qrCodes.set(id, qrCode);
    return qrCode;
  }
  
  async getActiveQrCodeForToday(type: string): Promise<QrCodeLog | undefined> {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    const todayStr = today.toISOString().split('T')[0];
    
    return Array.from(this.qrCodes.values()).find(
      (qrCode) => {
        const qrDate = new Date(qrCode.date).toISOString().split('T')[0];
        return qrCode.isActive && qrCode.type === type && qrDate === todayStr;
      }
    );
  }
  
  async deactivateQrCode(id: number): Promise<QrCodeLog | undefined> {
    const qrCode = this.qrCodes.get(id);
    if (!qrCode) return undefined;
    
    const updatedQrCode = { ...qrCode, isActive: false };
    this.qrCodes.set(id, updatedQrCode);
    return updatedQrCode;
  }
}

// Import DatabaseStorage
import { DatabaseStorage } from "./database-storage";

// Use DatabaseStorage instead of MemStorage
export const storage = new DatabaseStorage();
