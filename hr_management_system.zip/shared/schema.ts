import { pgTable, text, serial, integer, boolean, date, timestamp, pgEnum } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Enums
export const userRoleEnum = pgEnum('user_role', ['admin', 'employee']);
export const taskStatusEnum = pgEnum('task_status', ['pending', 'completed', 'in_progress']);
export const taskTypeEnum = pgEnum('task_type', ['daily', 'monthly', 'emergency']);
export const leaveStatusEnum = pgEnum('leave_status', ['pending', 'approved', 'rejected']);
export const leaveTypeEnum = pgEnum('leave_type', ['sick', 'personal', 'vacation']);
export const attendanceTypeEnum = pgEnum('attendance_type', ['check_in', 'check_out']);

// Users Table
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  phone: text("phone"),
  address: text("address"),
  role: userRoleEnum("role").notNull().default('employee'),
  profilePhoto: text("profile_photo"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Tasks Table
export const tasks = pgTable("tasks", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description"),
  type: taskTypeEnum("type").notNull(),
  status: taskStatusEnum("status").notNull().default('pending'),
  deadline: timestamp("deadline"),
  assignedTo: integer("assigned_to").notNull(),
  assignedBy: integer("assigned_by").notNull(),
  photo: text("photo"),
  document: text("document"),
  createdAt: timestamp("created_at").defaultNow(),
  completedAt: timestamp("completed_at"),
});

// Attendance Table
export const attendance = pgTable("attendance", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  type: attendanceTypeEnum("type").notNull(),
  timestamp: timestamp("timestamp").defaultNow(),
  geoLocation: text("geo_location"),
  qrCode: text("qr_code"),
});

// Leave Table
export const leave = pgTable("leave", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  type: leaveTypeEnum("type").notNull(),
  reason: text("reason").notNull(),
  startDate: date("start_date").notNull(),
  endDate: date("end_date").notNull(),
  status: leaveStatusEnum("status").notNull().default('pending'),
  approvedBy: integer("approved_by"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Evaluation Table
export const evaluations = pgTable("evaluations", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  taskCompletion: integer("task_completion").notNull(),
  timeliness: integer("timeliness").notNull(),
  quality: integer("quality").notNull(),
  month: integer("month").notNull(),
  year: integer("year").notNull(),
  overallScore: integer("overall_score").notNull(),
  comments: text("comments"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Notification Table
export const notifications = pgTable("notifications", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  title: text("title").notNull(),
  message: text("message").notNull(),
  isRead: boolean("is_read").notNull().default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

// QR Code Log Table
export const qrCodeLogs = pgTable("qr_code_logs", {
  id: serial("id").primaryKey(),
  qrCode: text("qr_code").notNull(),
  type: attendanceTypeEnum("type").notNull(),
  date: date("date").notNull(),
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

// Zod Schemas
export const insertUserSchema = createInsertSchema(users).omit({ id: true, createdAt: true });
export const insertTaskSchema = createInsertSchema(tasks).omit({ id: true, createdAt: true, completedAt: true });
export const insertAttendanceSchema = createInsertSchema(attendance).omit({ id: true, timestamp: true });
export const insertLeaveSchema = createInsertSchema(leave).omit({ id: true, status: true, approvedBy: true, createdAt: true });
export const insertEvaluationSchema = createInsertSchema(evaluations).omit({ id: true, createdAt: true });
export const insertNotificationSchema = createInsertSchema(notifications).omit({ id: true, isRead: true, createdAt: true });
export const insertQrCodeLogSchema = createInsertSchema(qrCodeLogs).omit({ id: true, createdAt: true });

// TypeScript Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Task = typeof tasks.$inferSelect;
export type InsertTask = z.infer<typeof insertTaskSchema>;

export type Attendance = typeof attendance.$inferSelect;
export type InsertAttendance = z.infer<typeof insertAttendanceSchema>;

export type Leave = typeof leave.$inferSelect;
export type InsertLeave = z.infer<typeof insertLeaveSchema>;

export type Evaluation = typeof evaluations.$inferSelect;
export type InsertEvaluation = z.infer<typeof insertEvaluationSchema>;

export type Notification = typeof notifications.$inferSelect;
export type InsertNotification = z.infer<typeof insertNotificationSchema>;

export type QrCodeLog = typeof qrCodeLogs.$inferSelect;
export type InsertQrCodeLog = z.infer<typeof insertQrCodeLogSchema>;

export type TaskType = z.infer<typeof taskTypeEnum.enum>;
export type TaskStatus = z.infer<typeof taskStatusEnum.enum>;
export type LeaveType = z.infer<typeof leaveTypeEnum.enum>;
export type LeaveStatus = z.infer<typeof leaveStatusEnum.enum>;
export type AttendanceType = z.infer<typeof attendanceTypeEnum.enum>;
export type UserRole = z.infer<typeof userRoleEnum.enum>;
