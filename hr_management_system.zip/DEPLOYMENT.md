# Deployment Guide for HR Management System

## Database Setup

### Option 1: Neon PostgreSQL (Recommended for Easy Setup)

1. Go to https://neon.tech and create an account
2. Create a new project
3. Create a new database within your project
4. Get your database connection string from the dashboard
5. Add the connection string to your `.env` file as `DATABASE_URL`

### Option 2: Self-hosted PostgreSQL

1. Install PostgreSQL on your server
2. Create a new database and user
3. Set up your `.env` file with the database credentials
4. Make sure your PostgreSQL server allows connections from your application server

## Application Deployment

### Option 1: Vercel (Frontend) + Railway (Backend)

#### Frontend Deployment to Vercel

1. Create an account on Vercel (https://vercel.com)
2. Install the Vercel CLI: `npm i -g vercel`
3. Run `vercel login` to log in to your account
4. Configure the project for deployment:
   ```
   cd client
   vercel
   ```
5. Follow the prompts to set up your project

#### Backend Deployment to Railway

1. Create an account on Railway (https://railway.app)
2. Install the Railway CLI: `npm i -g @railway/cli`
3. Run `railway login` to log in to your account
4. Initialize your project:
   ```
   railway init
   ```
5. Deploy the project:
   ```
   railway up
   ```
6. Set environment variables through the Railway dashboard

### Option 2: DigitalOcean App Platform

1. Create an account on DigitalOcean
2. Create a new App from the App Platform dashboard
3. Connect your GitHub repository
4. Configure your app settings and environment variables
5. Deploy your application

### Option 3: Docker Deployment

1. Create a `Dockerfile` in your project root:
   ```
   FROM node:16-alpine
   
   WORKDIR /app
   
   COPY package*.json ./
   RUN npm install
   
   COPY . .
   RUN npm run build
   
   EXPOSE 5000
   
   CMD ["npm", "run", "start"]
   ```

2. Build and run your Docker container:
   ```
   docker build -t hr-management-system .
   docker run -p 5000:5000 --env-file .env hr-management-system
   ```

## Database Migration

After deployment, run migrations on your production database:

```
NODE_ENV=production npm run db:push
```

## Environment Variables

Ensure the following environment variables are set in your production environment:

- `DATABASE_URL` - Your PostgreSQL connection string
- `SESSION_SECRET` - A strong random string to secure sessions
- `NODE_ENV` - Set to `production`
- `PORT` - The port your server will run on (default: 5000)

## Security Considerations

1. **SSL/TLS**: Enable HTTPS for your application
2. **Firewall**: Configure firewall rules to only allow necessary traffic
3. **Database Backups**: Set up regular database backups
4. **Session Management**: Configure secure cookie settings
5. **Environment Variables**: Keep your environment variables secure

## Monitoring and Maintenance

1. Set up monitoring with tools like New Relic, Datadog, or Sentry
2. Configure log rotation and aggregation
3. Set up regular database maintenance tasks
4. Implement a CI/CD pipeline for continuous deployment

## Post-Deployment Verification

1. Test user registration and login
2. Verify QR code generation and scanning
3. Test task creation and management
4. Test leave application workflow
5. Verify admin dashboard functionality
