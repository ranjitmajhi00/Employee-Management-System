# Database Management Guide

## PostgreSQL Database Structure

The HR Management System uses PostgreSQL with Drizzle ORM for database operations. The database schema is defined in `shared/schema.ts`.

## Key Tables

- **users**: Employee and admin user information
- **tasks**: Task assignments and status
- **attendance**: Employee check-in/check-out records
- **leave**: Leave requests and approvals
- **evaluations**: Performance evaluation data
- **notifications**: System notifications
- **qrCodeLogs**: QR code generation logs for attendance

## Database Initialization

To initialize the database:

```
npm run db:push
```

This command will create the necessary tables based on the schema defined in `shared/schema.ts`.

## Database Migrations

The system uses Drizzle ORM for schema management. When you make changes to the schema, you need to push those changes to the database:

```
npm run db:push
```

## Backup and Restore

### Creating Backups

To create a backup of your PostgreSQL database:

```bash
pg_dump -h hostname -U username -d database_name -F c -f backup_file.dump
```

### Restoring from Backup

To restore a database from a backup:

```bash
pg_restore -h hostname -U username -d database_name -F c backup_file.dump
```

## Database Hosting Options

### 1. Neon - Serverless PostgreSQL

**Pros:**
- Serverless architecture
- Generous free tier
- Built-in branching capability
- Automatic scaling

**Setup:**
1. Create an account at https://neon.tech
2. Create a new project
3. Get your connection string
4. Update your environment variables

### 2. Supabase - PostgreSQL with API Layer

**Pros:**
- Built-in authentication
- Real-time capabilities
- API generation
- Free tier available

**Setup:**
1. Create an account at https://supabase.com
2. Create a new project
3. Get your PostgreSQL connection string
4. Update your environment variables

### 3. AWS RDS - Managed PostgreSQL

**Pros:**
- High reliability
- Scalable
- Automated backups
- Integrated with AWS ecosystem

**Setup:**
1. Set up an AWS account
2. Create an RDS PostgreSQL instance
3. Configure security groups
4. Connect using the provided endpoint

### 4. DigitalOcean Managed Databases

**Pros:**
- Simple setup
- Reasonable pricing
- Automatic updates and backups
- Good performance

**Setup:**
1. Create a DigitalOcean account
2. Set up a managed PostgreSQL database
3. Get your connection details
4. Update your application configuration

## Database Maintenance

### Regular Maintenance Tasks

1. **Vacuum the Database**: Regular vacuuming helps reclaim storage and update statistics

```sql
VACUUM ANALYZE;
```

2. **Check for Long-running Queries**:

```sql
SELECT * FROM pg_stat_activity WHERE state = 'active' ORDER BY query_start;
```

3. **Monitor Database Size**:

```sql
SELECT pg_size_pretty(pg_database_size('your_database_name'));
```

4. **Set Up Regular Backups**:
   - Daily backups for critical data
   - Weekly full database backups
   - Store backups in multiple locations

## Connection Pooling

For production environments, consider using connection pooling to efficiently manage database connections:

1. **PgBouncer**: Lightweight connection pooler for PostgreSQL
2. **Built-in Pooling**: The application uses the built-in connection pool from `@neondatabase/serverless`

To adjust pool settings, modify the pool configuration in `server/db.ts`.
