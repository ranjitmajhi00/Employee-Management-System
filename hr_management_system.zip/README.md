# HR Management System

A comprehensive employee management system designed to streamline workforce operations through integrated modules for attendance tracking, task management, leave administration, and performance evaluation.

## Features

- **Authentication System**: Secure login and registration with role-based access control
- **QR Code Attendance**: QR code-based check-in/check-out system
- **Task Management**: Assign, track, and manage tasks
- **Leave Management**: Apply for leaves and track leave balances
- **Performance Evaluation**: Track employee performance metrics
- **Admin Dashboard**: Comprehensive admin controls

## Technology Stack

- **Frontend**: React with TypeScript
- **Backend**: Node.js with Express
- **Database**: PostgreSQL
- **ORM**: Drizzle ORM
- **UI Framework**: Tailwind CSS with shadcn/ui components

## Installation

### Prerequisites

- Node.js (v16 or higher)
- PostgreSQL database

### Setup

1. Clone the repository
2. Install dependencies:
   ```
   npm install
   ```
3. Create a `.env` file based on `.env.example`
4. Initialize the database:
   ```
   npm run db:push
   ```
5. Start the development server:
   ```
   npm run dev
   ```

## Database Setup

The application uses PostgreSQL for data storage. You need to set up a PostgreSQL database and provide the connection details in the `.env` file.

## Deployment

### Backend Deployment

1. Set up a server (AWS EC2, DigitalOcean, Heroku, etc.)
2. Install Node.js and PostgreSQL
3. Set up environment variables
4. Build the application:
   ```
   npm run build
   ```
5. Start the production server:
   ```
   npm run start
   ```

### PostgreSQL Database Hosting Options

1. **Self-hosted**: Install PostgreSQL on your server
2. **Managed services**:
   - **Neon** - Serverless PostgreSQL with generous free tier
   - **Supabase** - PostgreSQL with API layer and authentication
   - **AWS RDS** - Managed PostgreSQL service by Amazon
   - **DigitalOcean Managed Databases** - Simple PostgreSQL hosting
   - **Heroku Postgres** - Easy setup with Heroku applications
   - **Render** - PostgreSQL database with free tier

## Configuration

The application requires the following environment variables:

- `DATABASE_URL` - PostgreSQL connection string
- `SESSION_SECRET` - Secret for encrypting sessions
- `PORT` - Port to run the server on (default: 5000)

## License

This project is licensed under the MIT License - see the LICENSE file for details.
